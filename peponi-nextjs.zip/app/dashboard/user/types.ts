export interface User {
    id: number
    name: string
    email: string
    phone: string
    status: 1 | 2 | 0
  }
  

  