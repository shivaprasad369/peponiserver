"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { DataTable } from "./data-tabel"
import { columns } from "./columns"
import { QueryClient, useQuery, useQueryClient } from "@tanstack/react-query"
import axios from "axios"
import { toast } from "sonner"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface FAQ {
  id: number
  question: string
  answer: string
}

export default function FAQPage() {
  const queryClient = useQueryClient()
  const [faqs, setFaqs] = useState<FAQ[]>([])
  const [question, setQuestion] = useState("")
  const [answer, setAnswer] = useState("")
  const [isEdit, setIsEdit] = useState(false)
  const [id, setId] = useState(0)
  const [open, setOpen] = useState(false)

  const { data, isLoading } = useQuery({
    queryKey: ["faqs"],
    queryFn: async () => {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/faq`);
      return response.data.result;
    }
  });

  useEffect(() => {
    if (data && data.length > 0 && !isLoading) {
      setFaqs(data)
    }
  }, [data, isLoading])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/faq`, {
        question: question,
        answer: answer
      });
      if (response.status === 200) {
        toast.success("FAQ Added Successfully");
        queryClient.invalidateQueries({ queryKey: ["faqs"] });
        resetForm();
      }
    } catch (error) {
      toast.error("Failed to add FAQ");
    }
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await axios.put(`${process.env.NEXT_PUBLIC_API_URL}/faq/${id}`, {
        question: question,
        answer: answer
      });
      if (response.status === 200) {
        toast.success("FAQ Updated Successfully")
        queryClient.invalidateQueries({ queryKey: ["faqs"] })
        resetForm();
      }
    } catch (error) {
      toast.error("Failed to update FAQ");
    }
  }

  const resetForm = () => {
    setQuestion("")
    setAnswer("")
    setIsEdit(false)
    setId(0)
    setOpen(false)
  }

  const handleEdit = (faq: any) => {
    setIsEdit(true)
    setQuestion(faq.question)
    setAnswer(faq.answer) 
    setId(faq.id)
    setOpen(true)
  }

  const handleDelete = async(id: any) => {
  
    try {
     
      const response = await axios.delete(`${process.env.NEXT_PUBLIC_API_URL}/faq/${id.id}`);
      if (response.status === 200) {
        toast.success("FAQ Deleted Successfully")
        queryClient.invalidateQueries({ queryKey: ["faqs"] })
      }
    } catch (error) {
      toast.error("Failed to delete FAQ");
    }
    // setFaqs(faqs.filter((faq) => !idsToDelete.includes(faq.id)))
  }

  const handleDeleteEach = async (id: any) => {
    try {
      const confirm=window.confirm("Are you sure you want to delete this FAQ?");
      if(!confirm){
        return;
      }
      const response = await axios.delete(`${process.env.NEXT_PUBLIC_API_URL}/faq/${id.id}`);
      if (response.status === 200) {
        toast.success("FAQ Deleted Successfully")
        queryClient.invalidateQueries({ queryKey: ["faqs"] })
      }
    } catch (error) {
      toast.error("Failed to delete FAQ");
    }
  }

  return (
    <div className="space-y-6 bg-white">
      <div className="flex justify-between items-center">
        {/* <h2 className="text-3xl font-bold tracking-tight">Manage FAQs</h2> */}
        <div className='flex mt-0 justify-start px-4  gap-2 w-[100%] items-center'>
            <h1 className='text-4xl font-normal'>Manage FAQs</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setIsEdit(false); resetForm(); }}>
              Create New FAQ
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isEdit ? "Edit FAQ" : "Create New FAQ"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={isEdit ? handleSave : handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Question</label>
                <Input placeholder="Enter FAQ question" value={question} onChange={(e) => setQuestion(e.target.value)} />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Answer</label>
                <Textarea
                  placeholder="Enter FAQ answer"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={4}
                />
              </div>
              <Button type="submit" className="w-full">
                {isEdit ? "Save Changes" : "Create FAQ"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>FAQ List</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable 
            columns={columns} 
            data={faqs} 
            faq={true}
            onDelete={handleDelete} 
            onEdit={handleEdit} 
            edit={true}
            onDeleteEach={handleDeleteEach} 
          />
        </CardContent>
      </Card>
    </div>
  )
}

