"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Category {
  CategoryID: number;
  CategoryName: string;
}

export default function NewSubCategoryPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [categoryId, setCategoryId] = useState<number>(0);
  const [image, setImage] = useState<File | null>(null);
  const [previewImage, setPreviewImage] = useState("");

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category`);
      return response.data.result;
    }
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
      setPreviewImage(URL.createObjectURL(e.target.files[0]));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("CategoryName", name);
      formData.append("ParentCategoryID", categoryId.toString());
      formData.append("SubCategoryLevel", "2");
      if (image) {
        formData.append("Image", image);
      }

      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/category`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      toast.success("Subcategory created successfully");
      queryClient.invalidateQueries({ queryKey: ["subcategories"] });
      router.push("/dashboard/sub-category");
    } catch (error) {
      toast.error("Error creating subcategory");
    }
  };

  return (
    <div className="container mx-auto">
      <div className='flex mt-2 justify-start pb-4  gap-2 w-[100%] items-center'>
            <h1 className='text-4xl font-normal'>Create New Subcategory</h1>
        </div>
      <Card className="py-6">
        {/* <CardHeader>
          <CardTitle>Create New Subcategory</CardTitle>
        </CardHeader> */}
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Name</label>
              <Input
                placeholder="Enter subcategory name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Select 
                value={categoryId.toString()} 
                onValueChange={(value: string) => setCategoryId(Number(value))}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem 
                      key={category.CategoryID} 
                      value={category.CategoryID.toString()}
                    >
                      {category.CategoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Image</label>
              <Input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                required
              />
              {previewImage && (
                <img
                  src={previewImage}
                  alt="Preview"
                  className="mt-2 w-32 h-32 object-cover rounded"
                />
              )}
            </div>

            <div className="flex gap-4">
              <Button type="submit">Create Subcategory</Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/dashboard/sub-category")}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
