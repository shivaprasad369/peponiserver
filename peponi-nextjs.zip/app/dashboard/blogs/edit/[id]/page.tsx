"use client";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useRouter, useParams } from "next/navigation";
import { useEffect, useState } from "react";
import axios from "axios";
import TextEditor from "@/components/ui/Editor";
import toast, { Toaster } from "react-hot-toast";

interface Blog {
  id: number;
  title: string;
  shortDesc: string;
  content: string;
  author: string;
  image: string;
}

export default function EditBlogPage() {
  const router = useRouter();
  const params = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [blog, setBlog] = useState<Blog | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    shortDesc: "",
    content: "",
    author: "",
    image: null as File | null,
  });
  const [oldImage, setOldImage] = useState<File | null>(null);

  useEffect(() => {
    const fetchBlog = async () => {
      try {
        const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/blog/${params.id}`);
        const blogData = response.data.result;
        setBlog(blogData);
        setFormData({
          title: blogData[0].title || "",
          shortDesc: blogData[0].shortdesc || "",
          content: blogData[0].description || "",
          author: blogData[0].author || "",
          image: null,
        });
        setImage(blogData[0].image);
        console.log(blogData);
      } catch (error) {
        toast.error("Failed to fetch blog");
        // router.push("/dashboard/blogs");
      }
    };

    if (params.id) {
      fetchBlog();
    }
  }, [params.id, router]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({
        ...prev,
        image: e.target.files![0]
      }));
      setOldImage(e.target.files![0]);
    }
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const formDataToSend = new FormData();
      formDataToSend.append("title", formData.title);
      formDataToSend.append("shortdesc", formData.shortDesc);
      formDataToSend.append("description", formData.content);
      formDataToSend.append("author", formData.author);
      if (oldImage) {
        formDataToSend.append("Image", oldImage);
      }
      

      await axios.put(`${process.env.NEXT_PUBLIC_API_URL}/blog/${params.id}`, formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      toast.success("Blog updated successfully");
      router.push("/dashboard/blogs");
    } catch (error) {
      toast.error("Failed to update blog");
    } finally {
      setIsLoading(false);
    }
  };

  if (!blog) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <Toaster/>
      <h2 className="text-3xl font-bold tracking-tight">Update Blog</h2>
      <Card>
        <CardHeader>
          <CardTitle>Blog Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Blog Title</Label>
              <Input
                id="title"
                placeholder="Enter blog title"
                required
                disabled={isLoading}
                value={formData.title}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="shortDesc">Short Description</Label>
              <Textarea
                id="shortDesc"
                placeholder="Enter short description"
                required
                disabled={isLoading}
                value={formData.shortDesc}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2 border-[1px]   border-gray-300 p-2 rounded-md w-fit">
              <Label htmlFor="image">Old Image</Label>
              <img 
                src={`${process.env.NEXT_PUBLIC_API_URL}/${image}`} 
                alt={formData.title} 
                width={150} 
                height={100}
                className="rounded-md object-cover" 
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="image">New Image</Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                disabled={isLoading}
                onChange={handleImageChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Blog Content</Label>
              <TextEditor value={formData.content} onChange={(value) => setFormData({ ...formData, content: value })} />
            
            </div>

            <div className="space-y-2">
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                placeholder="Enter author name"
                required
                disabled={isLoading}
                value={formData.author}
                onChange={handleChange}
              />
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={isLoading}>
                Update Blog
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                disabled={isLoading}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
