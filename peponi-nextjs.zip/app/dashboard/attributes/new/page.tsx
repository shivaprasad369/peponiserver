"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Minus } from "lucide-react";

import { useRouter } from "next/navigation";
import toast,{ Toaster } from "react-hot-toast";

interface Category {
  CategoryID: number;
  CategoryName: string;
}

interface SubCategory {
  SubCategoryID: number;
  CategoryName: string;
  CategoryID: number;
}

interface AttributeValue {
  value: string;
}

interface Attribute {
  attributeName: string;
  value: string[];
}

export default function AttributesPage() {
  const [selectedCategory, setSelectedCategory] = useState<number>(0);
  const [selectedSubCategory, setSelectedSubCategory] = useState<number>(0);
  const [attributes, setAttributes] = useState<Attribute[]>([{ attributeName: "", value: [''] }]);
  const router = useRouter();
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category`);
      return response.data.result;
    }
  });

  const { data: subCategories } = useQuery<SubCategory[]>({
    queryKey: ["subcategories", selectedCategory],
    queryFn: async () => {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category/update/get?id=${selectedCategory}`);
      return response.data.result;
    },
    enabled: !!selectedCategory
  });

  const handleAddAttribute = () => {
    setAttributes([...attributes, { attributeName: "", value: [''] }]);
  };

  const handleSubmit = async () => {
    console.log(attributes,selectedCategory,selectedSubCategory);
    const Attributes = Object.values(attributes).map((item) => ({
        attributeName: item.attributeName,
        values: item.value,
      }));
      try {
        {
          const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/attribute`,
              {Attributes});
          if (response.status === 200) {
            setAttributes([{ attributeName: "", value: [''] }]);
            setSelectedCategory(0)
            setSelectedSubCategory(0)
            toast.success("Attributes added successfully");
            router.push("/dashboard/attributes");
          }
        }
      } catch (error:any) {
        if (error.response) {
          toast.error(error.response.data.message || 'Something went wrong!');
        } else {
          toast.error('An unexpected error occurred. Please try again later.');
        }
      }
  };

  const handleRemoveAttribute = (attributeIndex: number) => {
    const newAttributes = attributes.filter((_, index) => index !== attributeIndex);
    setAttributes(newAttributes);
  };

  const handleAddValue = (attributeIndex: number) => {
    const newAttributes = [...attributes];
    newAttributes[attributeIndex].value.push("");
    setAttributes(newAttributes);
  };

  const handleRemoveValue = (attributeIndex: number, valueIndex: number) => {
    const newAttributes = [...attributes];
    newAttributes[attributeIndex].value = newAttributes[attributeIndex].value.filter(
      (_, index) => index !== valueIndex
    );
    setAttributes(newAttributes);
  };

  const handleAttributeNameChange = (attributeIndex: number, name: string) => {
    const newAttributes = [...attributes];
    newAttributes[attributeIndex].attributeName = name;
    setAttributes(newAttributes);
  };

  const handleValueChange = (attributeIndex: number, valueIndex: number, value: string) => {
    const newAttributes = [...attributes];
    newAttributes[attributeIndex].value[valueIndex] = value;
    setAttributes(newAttributes);
  };

  return (
    <div className="container mx-auto ">
      <div className='flex mt-2 justify-start  pb-4  gap-2 w-[100%] items-center'>
            <h1 className='text-4xl font-normal'>Add New Attributes</h1>
        </div>
      <Toaster/>
      <Card>
        {/* <CardHeader>
          <CardTitle>Attributes</CardTitle>
        </CardHeader> */}
        <CardContent className="space-y-6 pt-4">
          {/* <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Category</label>
              <Select value={selectedCategory.toString()} onValueChange={(value) => {
                setSelectedCategory(Number(value));
                setSelectedSubCategory(0);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Select Category</SelectItem>
                  {categories?.map((category) => (
                    <SelectItem key={category.CategoryID} value={category.CategoryID.toString()}>
                      {category.CategoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Subcategory</label>
              <Select 
                value={selectedSubCategory.toString()} 
                onValueChange={(value) => {
                  setSelectedSubCategory(Number(value));
                }}
                disabled={!selectedCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a subcategory" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Select Subcategory</SelectItem>
                  { subCategories?.map((subCategory) => (
                      <SelectItem key={subCategory.CategoryID} value={subCategory.CategoryID.toString()}>
                        {subCategory?.CategoryName}
                      </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div> */}

          <div className="space-y-4">
            {attributes.map((attribute, attributeIndex) => (
              <Card key={attributeIndex}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Input
                      placeholder="Attribute Name"
                      value={attribute.attributeName}
                      onChange={(e) => handleAttributeNameChange(attributeIndex, e.target.value)}
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleRemoveAttribute(attributeIndex)}
                    >
                      Remove Attribute
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {attribute.value.map((value, valueIndex) => (
                      <div key={valueIndex} className="flex items-center gap-2">
                        <Input
                          placeholder="Value"
                          value={value}
                          onChange={(e) =>
                            handleValueChange(attributeIndex, valueIndex, e.target.value)
                          }
                        />
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => handleAddValue(attributeIndex)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                        {valueIndex > 0 && (
                          <Button
                            size="icon"
                            variant="outline"
                            onClick={() => handleRemoveValue(attributeIndex, valueIndex)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex gap-4">
            <Button onClick={handleAddAttribute}>Add Attribute</Button>
            <Button onClick={handleSubmit}>Submit</Button>
            <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push("/dashboard/attributes")}
                >
                  Cancel
                </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}