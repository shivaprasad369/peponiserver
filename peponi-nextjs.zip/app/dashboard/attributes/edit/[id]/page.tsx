"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

interface AttributeValue {
  id: number;
  value: string;
}

interface Category {
  CategoryID: number;
  CategoryName: string;
}

interface SubCategory {
  CategoryID: number;
  CategoryName: string;
}

interface AttributeResponse {
  result: Array<{
    CategoryID: number;
    subcategory: number;
    subcategorytwo: number | null;
    CategoryName: string;
    subcategoryName: string;
    subcategorytwoName: string | null;
    attributes: Array<{
      attribute_id: number;
      attributeName: string;
      values: AttributeValue[];
    }>;
  }>;
}

const formSchema = z.object({
  attributeName: z.string().min(1, "Attribute name is required"),
  categoryId: z.number(),
  subcategoryId: z.number(),
  values: z.array(z.object({ value: z.string(), id: z.number() })).min(1, "At least one value is required"),
});

type FormValues = z.infer<typeof formSchema>;

export default function EditAttributePage() {
  const params = useParams();
  const router = useRouter();
  const [id, setId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<SubCategory[]>([]);

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [CategoryId, setCategoryId] = useState<number | null>(null);
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      attributeName: "",
      categoryId: 0,
      subcategoryId: 0,
      values: [{ value: "", id: 0 }],
    },
  });
  const {data: categoryData, isLoading: categoriesLoading, error: categoriesError} = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category`);
      return response.data.result;
    },
  })
  
  // useEffect(() => {
  //   const fetchCategories = async () => {
  //     try {
  //       const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category`);
  //       setCategories(response.data.result);
  //     } catch (error) {
  //       toast.error("Error fetching categories");
  //     }
  //   };

  //   fetchCategories();
  // }, []);

  useEffect(() => {
    const generateId = async () => {
      const res= await axios.post(`/api/generate-id`,{
        id: decodeURIComponent(params.id),
        action: "unmask",
      });
      setId(Number(res.data.unmaskedID));             
    }
    generateId();
  }, [params.id]);
  // useEffect(() => {
  //   const categoryId = form.watch("categoryId");
  //   if (categoryId) {
  //     const fetchSubcategories = async () => {
  //       try {
  //         const response = await axios.get(
  //           `${process.env.NEXT_PUBLIC_API_URL}/category/update/get?id=${categoryId}`
  //         );
  //         setSubcategories(response.data.result);
  //       } catch (error) {
  //         toast.error("Error fetching subcategories");
  //       }
  //     };

  //     fetchSubcategories();
  //   }
  // }, [form.watch("categoryId")]);

  useEffect(() => {
    const fetchAttribute = async () => {
      if (!id) return;
      try {
        const response = await axios.get<AttributeResponse>(
          `${process.env.NEXT_PUBLIC_API_URL}/attribute/${id}`
        );
        const attribute = response?.data[0].attributes[0];
        console.log(attribute);
        // Set form values individually to ensure they update
        form.setValue("attributeName", attribute.attributeName);
      
        form.setValue("values", attribute.values.map((v:any) => ({id: v.id, value: v.value })));
      } catch (error) {
        toast.error("Error fetching attribute");
      } finally {
        setLoading(false);
      }
    };

    fetchAttribute();
  }, [id, form]);
  console.log(form.getValues());
  const onSubmit = async (values: FormValues) => {
    try {
      const data = [{
        ...values,
        attributeName: values.attributeName,
        attributeId: Number(id),
      }];

      await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/attribute`,
        {
          Attributes: data
        }
      );
      
      toast.success("Attribute updated successfully");
      router.push("/dashboard/attributes");
    } catch (error) {
      toast.error("Error updating attribute");
    }
  };

  const addValue = () => {
    const currentValues = form.getValues("values");
    form.setValue("values", [...currentValues, { value: "", id: 0 }]);
  };

  const removeValue = (index: number,id:number) => {
    const currentValues = form.getValues("values");
    console.log(index)
    if (currentValues.length > 1) {
      const newValues = currentValues.filter((_, i) => i !== index);
      form.setValue("values", newValues);
    } else {
      toast.error("At least one value is required");
    }
  };
 console.log(form.getValues("values"));
  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Edit Attribute</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(Number(value))} 
                      value={CategoryId } 
                      disabled={CategoryId !== null}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categoryData?.map((category: Category) => (
                          <SelectItem 
                            key={category.CategoryID} 
                            value={category.CategoryID}
                          >
                            {category.CategoryName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subcategoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subcategory</FormLabel>
                    <FormControl>
                      <Input {...field} value={selectedCategory || ''} disabled/>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              /> */}

              <FormField
                control={form.control}
                name="attributeName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Attribute Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {form.watch("values").map((_, index) => (
                <FormField
                  key={index}
                  control={form.control}
                  name={`values.${index}.value`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Value {index + 1}</FormLabel>
                      <div className="flex gap-2">
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <Button
                          type="button"
                          variant="destructive"
                          onClick={() => removeValue(id,form.getValues("values")[index].id)}
                        >
                          Remove
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}

              <Button type="button" variant="outline" onClick={addValue}>
                Add Value
              </Button>

              <div className="flex gap-2">
                <Button type="submit">Save Changes</Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push("/dashboard/attributes")}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
