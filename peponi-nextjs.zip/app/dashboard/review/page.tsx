import ReviewsTable from "./reviews-table"

export default function Page() {
  return <ReviewsTable />
}