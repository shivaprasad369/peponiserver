import Choice from "@/components/about-us/Choice";
import Choose from "@/components/about-us/Choose";
import Gallery from "@/components/about-us/Gallery";
import Second from "@/components/about-us/Second";
import Banner from "@/components/about-us/Banner";

export default function Page() {
    return (
        <div>  
        <Gallery/>
        <Choice/>
        <Choose/>
        <Second/>
        </div>
    );
}