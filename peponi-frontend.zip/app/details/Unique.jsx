import React from 'react'
import img from '@assets/images/art-gallery.png'
import Image from 'next/image'

function Unique() {
  return (
    <section className="unique-collection-sec">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap items-center">   
          <div className="md:w-7/12">
            <Image src={img} alt="art-gallery" className="w-full h-auto" />
          </div>
          <div className="md:w-5/12 mt-6 md:mt-0">
            <div className="collec-content">
              <h3 className="text-2xl font-semibold">UNIQUE COLLECTION OF LOCAL ARTIST PAINTINGS</h3>
              <p className="text-lg mt-4">Our hand-painted wall arts are stretched on wood and come with an outer frame ready to hang.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Unique
