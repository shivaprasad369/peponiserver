
import About from "../About"
import Description from "../Description"
import Unique from "../Unique"
import Related from "../Related"

// Function to fetch product data
async function getProductData(name: string) {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL
  if (!apiUrl) {
    throw new Error("API URL is not defined")
  }

  const res = await fetch(`${apiUrl}/product-details/${name}`, {
    cache: "no-store", // Ensures fresh data on each request
  })

  if (!res.ok) {
    if (res.status === 404) {
      return  <div className="flex items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold">404 - Product Not Found</h1>
    </div>
    }
    throw new Error(`Failed to fetch product data: ${res.status}`)
  }

  return res.json()
}

type DetailParams = Promise<{ name: string }>;

export default async function DetailPage({ params }: { params: DetailParams }) {

  const {name}  = await params;
  if (!name) {
    <div className="flex items-center justify-center min-h-screen">
        <h1 className="text-2xl font-bold">404 - Product Not Found</h1>
      </div>
  }

  const data = await getProductData(name)
console.log(data)
  return (
    <main>
      <About data={data} />
      <Description  data={data} />
      <Unique  />
      <Related id={data?.subCat}/>
    </main>
  )
}

