"use client"
import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Navigation, Thumbs } from "swiper/modules";
import type { Swiper as SwiperType } from "swiper";
import 'swiper/css';
import 'swiper/css/free-mode';
import 'swiper/css/navigation';
import 'swiper/css/thumbs';
import './styles.css'
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import Cookies from 'js-cookie';
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { isEmpty } from "lodash";
import { useQueryClient } from "@tanstack/react-query";

export default function About({ data }: any) {
  const [thumbsSwiper, setThumbsSwiper] = useState<SwiperType | null>(null);
  const [quantity,setQuantity]= useState(1)
 const [total,setTotal]=useState(1)
 const queryClient = useQueryClient()
 const [number, setNumber] = useState({
  qty:1,
  action:'increment'
});
  let quntity=data.Stock;
  useEffect(() => {
    setTotal(quntity-1)
  }, [quntity]);

const handleDecrement=()=>{
  setTotal((pre)=>pre+1)
  setQuantity((prev)=>prev-1)
}
const handleIncremane=()=>{
  setTotal((pre)=>pre-1)
  setQuantity((prev)=>prev+1)
}
const [userEmail, setUserEmail] = useState("");  
const auth = getAuth();


useEffect(() => {
  const unsubscribe = onAuthStateChanged(auth, (user) => {
    setUserEmail(user?.email || "");
  });

  return () => unsubscribe();
}, []); // ✅ Removed userEmail from dependency array

const handleAddToCart = async () => {
  let userId: any = Cookies.get("userId");

  if (!userId) {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/cart/generate-id`);
      userId = response.data.id;
      Cookies.set("userId", userId, { expires: 7, path: "/" });
      
    } catch (error) {
      toast.error("Failed to generate user ID");
      return;
    }
  }

  try {
    const cartItem = {
      ProductAttributeID: Number(data.ProductAttributeID),
      ProductID: data.ProductID,
      UserID: 1,
      Price: data.SellingPrice,
      Qty: quantity,
      ItemTotal: Number(data.SellingPrice) * quantity,
      CartDate: new Date(),
      TranxRef: `TRX-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      WebsiteType: 1,
      Voucherprice: data.Voucherprice,
      CartNumber: userId,
    };

    const insertResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/cart/store-cart?id=${userEmail ? 2 : 1}`,
      {
        cartItems: cartItem,
        email: userEmail || null,
        userId: userEmail ? 2 : 1,
      }
    );

    if (insertResponse) {
      toast.success("Item added to cart");
      queryClient.invalidateQueries({
        queryKey:['Qty']
      })
      return insertResponse.data;
    }
  } catch (error) {
    toast.error("Insufficient Quantity or Internal server error");
  }
};
  return (
    <div className="mt-[150px]">
      <Toaster/>
      <section className="">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 w-[100%] md:grid-cols-2 gap-8">
            <div className="w-[100%]">
              {/* Main Swiper */}
              <Swiper
                spaceBetween={10}
                navigation={true}
                thumbs={{ swiper: thumbsSwiper }}
                modules={[FreeMode, Navigation, Thumbs]}
                className="rounded-lg overflow-hidden"
              >
                {!isEmpty(data.ProductImages)? data.ProductImages.map((img: string, index: number) => (
                  <SwiperSlide key={index}>
                    <img
                      src={`${process.env.NEXT_PUBLIC_API_URL}/${img}`}
                      alt={data.ProductName}
                    
                      className="w-full object-cover"
                    />
                  </SwiperSlide>
                )):<SwiperSlide >
                <img
                  src={`${process.env.NEXT_PUBLIC_API_URL}/${data?.Image}`}
                  alt={data.ProductName}
                  
                  className="w-full object-cover"
                />
              </SwiperSlide>}
              </Swiper>

              {/* Thumbnail Gallery */}
               <Swiper
                onSwiper={setThumbsSwiper}
                loop={true}
                spaceBetween={10}
                slidesPerView={3}
                freeMode={true}
                watchSlidesProgress={true}
                modules={[FreeMode, Navigation, Thumbs]}
                className="mt-3 md:h-[10rem] rounded-md"
              >
                {!isEmpty(data.ProductImages) ? data.ProductImages.map((img: string, index: number) => (
                  <SwiperSlide key={`thumb-${index}`} className="h-[100%] s1">
                    <img
                      src={`${process.env.NEXT_PUBLIC_API_URL}/${img}`}
                      alt={`${data.ProductName}`}
                      width={100} height={100}
                      className="cursor-pointer"
                    />
                  </SwiperSlide>
                )):
                <SwiperSlide key={`thumb}`} className="h-[100%] s1">
                <img
                  src={`${process.env.NEXT_PUBLIC_API_URL}/${data?.Image}`}
                  alt={`${data.ProductName}`}
                  width={100} height={100}
                  className="cursor-pointer"
                />
              </SwiperSlide>
                }
              </Swiper>
            </div>

            {/* Product Details */}
            <div className="flex flex-col gap-4 w-[100%]">
              <div className="product-content w-[100%]">
                <div className="cate-wrapper">
                  <h2>{data.ProductName}</h2>
                  <i className="fa-solid fa-share-nodes"></i>
                </div>
                <span>Art Prints</span>
                <p>Size - {data.Attributes?.find((attr: any) => attr.attribute_name === "Size")?.value || "N/A"}</p>
                <p>By : {data.MetaTitle || "Unknown"}</p>

                <div className="price-wrapper">
                  <span className="regular-price">${data.ProductPrice}</span>
                  <span className="sell-price">${data.SellingPrice}</span>
                </div>

                <div className="add-product">
                  <div className="number-count">
                    <button className="minus"
                     onClick={handleDecrement}
                     disabled={quantity===1 || data.Stock===null}
                     >-</button>
                    <input type="text" value={quantity} readOnly />
                    <button  className="plus"
                     onClick={handleIncremane} 
                     disabled={quantity===data.Stock || data.Stock<1}
                     >+</button>
                  </div>
                  
                  <button disabled={data.Stock<1} onClick={handleAddToCart} className="primary-btn flex items-center justify-center font-medium">
                    Add to Cart
                  </button>
                </div>
                <div>
               {data.Stock < 1  ? <p className="text-sm text-red-500">There Is No Stock</p>:<p> total Quantities {data.Stock} -{total}</p> }

                </div>
                <div className="delivery-details">
                  <p>Secure delivery : France + $52</p>
                  <p>Shipping : One to two weeks</p>
                  <h6>Have a question? Ask a specialist</h6>
                  <p>Free returns within 14 days</p>
                  <p>Authenticity guaranteed</p>
                  <p>Secure payment</p>
                  <p>Verified Reviews</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
