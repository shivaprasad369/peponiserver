"use client";
import { useState, useEffect } from "react";

export default function Description({ data }: any) {
  const [description, setDescription] = useState("");

  useEffect(() => {
    setDescription(data?.Description || ""); // Ensure content is only set on client
  }, [data?.Description]);

  return (
    <section className="about-artwork-sec">
      <div className="container">
        <h2>About the {data?.ProductName}</h2>
        <h6>Description</h6>
        <p dangerouslySetInnerHTML={{ __html: description }}></p>
      </div>
    </section>
  );
}
