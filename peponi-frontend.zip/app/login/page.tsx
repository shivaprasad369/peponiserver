'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { auth } from '@/lib/firebase/firebase-config';
import { signInWithEmailAndPassword, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup } from 'firebase/auth';
import logo from "@/assets/images/site-logo.png"
import google from "@/assets/images/google.png"
import facebook from "@/assets/images/facebook-logo.png"
import Image from "next/image"
import Link from "next/link"    

import { toast, Toaster } from "react-hot-toast"
import { Eye, EyeOff } from 'lucide-react';

const getAuthErrorMessage = (error: any) => {
    switch (error?.code) {
        case 'auth/invalid-credential':
            return 'Inavlid Email or Password. Please try again';
        case 'auth/wrong-password':
            return 'Invalid password';
        case 'auth/invalid-email':
            return 'Please enter a valid email address';
        case 'auth/too-many-requests':
            return 'Too many failed attempts. Please try again later';
        default:
            return 'Something went wrong. Please try again';
    }
};

const registerUserInDatabase = async (fullName: string, emailId: string, phoneNo: string, isVerified: number) => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/user/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                fullName,
                emailId,
                phoneNo,
                isVerified
            })
        });
        
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message);
        }
        return data;
    } catch (error) {
        console.error('Database registration error:', error);
        throw error;
    }
}

export default function Login() {
    const router = useRouter();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleEmailLogin = async (e: React.FormEvent) => {
        e.preventDefault();



        setLoading(true);
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            if (userCredential.user.emailVerified) {
                console.log(userCredential.user)
                toast.success('Login successful!');
                setTimeout(() => {
                    router.push('/dashboard');
                }, 0);
            } else {
                router.push('/verify');
            }
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err))
            console.log(err);
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleLogin = async () => {
        try {
            const result = await signInWithPopup(auth, new GoogleAuthProvider());
            if (result.user.emailVerified) {
                // Add MySQL database registration for Google sign-in
                try {
                    await registerUserInDatabase(
                        result.user.displayName || 'Google User',
                        result.user.email || '',
                        result.user.phoneNumber || '',
                        1
                    );
                } catch (dbError) {
                    console.error('Failed to register Google user in database:', dbError);
                }

                toast.success('Login successful!');
                setTimeout(() => {
                    router.push('/dashboard');
                }, 0);
            } else {
                router.push('/verify');
            }
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err));
        }
    };

    const handleFacebookLogin = async () => {
        try {
            const result = await signInWithPopup(auth, new FacebookAuthProvider());
            if (result.user.emailVerified) {
                // Add MySQL database registration for Facebook sign-in
                try {
                    await registerUserInDatabase(
                        result.user.displayName || 'Facebook User',
                        result.user.email || '',
                        result.user.phoneNumber || '',
                        1
                    );
                } catch (dbError) {
                    console.error('Failed to register Facebook user in database:', dbError);
                }

                toast.success('Login successful!');
                setTimeout(() => {
                    router.push('/dashboard');
                }, 0);
            } else {
                router.push('/auth/verify');
            }
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err));
        }
    };

    return (
        <section className="register-sec mt-[150px]">
            <Toaster position="top-center" />
            <div className="register-content">
                <div className="flex form-site-logo justify-center align-center">
                    <Image src={logo} alt="site-logo" />
                </div>
                <h2>Log in</h2>
                <form onSubmit={handleEmailLogin}>
                    <div className="form-group">
                        <label htmlFor="email">Email Address</label>
                        <input 
                            type="email" 
                            id="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Enter Your Email Address *" 
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <div className="relative">
                            <input 
                                type={showPassword ? "text" : "password"}
                                id="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Your Password *" 
                                required
                            />
                            <button
                                type="button"
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                onClick={() => setShowPassword(!showPassword)}
                            >
                                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                            </button>
                        </div>
                        <Link href="forgot-password" className="forget">Forgot your password?</Link>
                    </div>
                    
                    <button className="submit-btn relative" disabled={loading}>
                        {loading ? (
                            <>
                                <span className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                                <span>Logging in...</span>
                            </>
                        ) : (
                            'Log in'
                        )}
                    </button>
                </form>
                <div className="form-cont">
                    <p className="register-al">New customer? <Link href="/register">Register</Link></p>
                    <span className="or">
                        <span className="arrow-border"></span>
                        <span className="arrow-text">OR</span>
                    </span>
                    <div className="singup-btn">
                        <a href="#" onClick={(e) => { e.preventDefault(); handleGoogleLogin(); }}>
                            <Image src={google} alt="google" /><span>Sign in with Google</span>
                        </a>
                        <a href="#" onClick={(e) => { e.preventDefault(); handleFacebookLogin(); }}>
                            <Image src={facebook} alt="facebook" /><span>Sign in with Facebook</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
}


