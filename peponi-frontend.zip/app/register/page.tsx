'use client'
import { useState } from "react"
import { createUserWithEmailAndPassword, sendEmailVerification, updateProfile, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup } from "firebase/auth"
import { auth } from "@/lib/firebase/firebase-config"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import logo from "@/assets/images/site-logo.png"
import google from "@/assets/images/google.png"
import facebook from "@/assets/images/facebook-logo.png"
import { toast, Toaster } from "react-hot-toast"
import { Eye, EyeOff } from 'lucide-react'
import PhoneInput from 'react-phone-number-input'
import 'react-phone-number-input/style.css'

const getAuthErrorMessage = (error: any) => {
    switch (error?.code) {
        case 'auth/email-already-in-use':
            return 'An account with this email already exists';
        case 'auth/invalid-email':
            return 'Please enter a valid email address';
        case 'auth/weak-password':
            return 'Password should be at least 6 characters';
        case 'auth/wrong-password':
            return 'Incorrect password';
        case 'auth/user-not-found':
            return 'No account exists with this email';
        default:
            return 'Something went wrong. Please try again';
    }
};

const registerUserInDatabase = async (fullName: string, emailId: string, phoneNo: string, isVerified: number) => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/user/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                fullName,
                emailId,
                phoneNo,
                isVerified
            })
        });
        
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message);
        }
        return data;
    } catch (error) {
        console.error('Database registration error:', error);
        throw error;
    }
}

export default function Register() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [name, setName] = useState('')
    const [phone, setPhone] = useState<string>('')
    const [loading, setLoading] = useState(false)
    const [showPassword, setShowPassword] = useState(false)
    const router = useRouter()

    const validatePassword = (pass: string) => {
        const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.{8,})/
        return regex.test(pass)
    }

    const validateEmail = (email: string) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return regex.test(email)
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        if (!name) {
            toast.error('Please enter your full name')
            setLoading(false)
            return
        }

        if (!email) {
            toast.error('Please enter your email address')
            setLoading(false)
            return
        }

        if (!phone) {
            toast.error('Please enter your phone number')
            setLoading(false)
            return
        }

        if (!validateEmail(email)) {
            toast.error('Please enter a valid email address')
            setLoading(false)
            return
        }

        if (!password) {
            toast.error('Please enter your password')
            setLoading(false)
            return
        }

        if (!confirmPassword) {
            toast.error('Please confirm your password')
            setLoading(false)
            return
        }

        if (!validatePassword(password)) {
            toast.error('Password must contain at least 8 characters, one uppercase, one lowercase, and one special character')
            setLoading(false)
            return
        }

        if (password !== confirmPassword) {
            toast.error('Passwords do not match')
            setLoading(false)
            return
        }

        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password)
            await sendEmailVerification(userCredential.user)
            
            await updateProfile(userCredential.user, {
                displayName: name,
                photoURL: phone 
            })

            // Add MySQL database registration
            try {
                // Email registration - isVerified = 0
                await registerUserInDatabase(name, email, phone, 0);
            } catch (dbError) {
                console.error('Failed to register in database:', dbError);
                // Continue with the flow even if database registration fails
                // You might want to log this error or handle it differently
            }
           
            toast.success('Registration successful! Please verify your email.')
            setTimeout(() => {
                router.push('/auth/verify')
            }, 0)
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err))
        } finally {
            setLoading(false)
        }
    }

    const handleGoogleLogin = async () => {
        try {
            const result = await signInWithPopup(auth, new GoogleAuthProvider());
            if (result.user.emailVerified) {
                // Add MySQL database registration for Google sign-up
                try {
                    // Google login - isVerified = 1
                    await registerUserInDatabase(
                        result.user.displayName || 'Google User',
                        result.user.email || '',
                        result.user.phoneNumber || '',
                        1
                    );
                } catch (dbError) {
                    console.error('Failed to register Google user in database:', dbError);
                }

                console.log(result.user)
                toast.success('Registration successful!')
                setTimeout(() => {
                    router.push('/dashboard')
                }, 1000)
            } else {
                router.push('/verify')
            }
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err))
        }
    }

    const handleFacebookLogin = async () => {
        try {
            const result = await signInWithPopup(auth, new FacebookAuthProvider());
            if (result.user.emailVerified) {
                // Add MySQL database registration for Facebook sign-up
                try {
                    // Facebook login - isVerified = 1
                    await registerUserInDatabase(
                        result.user.displayName || 'Facebook User',
                        result.user.email || '',
                        result.user.phoneNumber || '',
                        1
                    );
                } catch (dbError) {
                    console.error('Failed to register Facebook user in database:', dbError);
                }

                toast.success('Registration successful!')
                setTimeout(() => {
                    router.push('/dashboard')
                }, 1000)
            } else {
                router.push('/auth/verify')
            }
        } catch (err: any) {
            toast.error(getAuthErrorMessage(err))
        }
    }

    return (
        <section className="register-sec mt-[150px]">
            <Toaster position="top-center" />
            <div className="register-content">
                <div className="flex form-site-logo justify-center align-center">
                    <Image src={logo} alt="site-logo" />
                </div>
                <h2>Register</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="name">Full Name</label>
                        <input 
                            type="text" 
                            id="name" 
                            placeholder="Enter Your Full Name *"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="email">Email Address</label>
                        <input 
                            type="email" 
                            id="email" 
                            placeholder="Enter Your Email Address *"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="phone">Phone Number</label>
                        <PhoneInput
                            international
                            defaultCountry="US"
                            value={phone}
                            onChange={(value: string | undefined) => setPhone(value || '')}
                            placeholder="Enter phone number"
                            className="phone-input-container"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <div className="relative">
                            <input 
                                type={showPassword ? "text" : "password"}
                                id="password" 
                                placeholder="Your Password *"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                            <button
                                type="button"
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                onClick={() => setShowPassword(!showPassword)}
                            >
                                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                            </button>
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="confirmPassword">Confirm Password</label>
                        <input 
                            type="password" 
                            id="confirmPassword" 
                            placeholder="Confirm Your Password *"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                        />
                    </div>
                    <button 
                        className="submit-btn relative" 
                        disabled={loading}
                    >
                        {loading ? (
                            <>
                                <span className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                                <span>Registering...</span>
                            </>
                        ) : (
                            'Register'
                        )}
                    </button>
                </form>
                <div className="form-cont">
                    <p className="register-al">Already customer? <Link href="/login">Login</Link></p>
                    <span className="or"><span className="arrow-border"></span>
                    <span className="arrow-text">OR</span>
                </span>
                    <div className="singup-btn">
                        <a href="#" onClick={(e) => { e.preventDefault(); handleGoogleLogin(); }}>
                            <Image src={google} alt="google" /><span>Sign up with Google</span>
                        </a>
                        <a href="#" onClick={(e) => { e.preventDefault(); handleFacebookLogin(); }}>
                            <Image src={facebook} alt="facebook" /><span>Sign up with Facebook</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    )
}