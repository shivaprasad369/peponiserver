export default function PrivacyPolicy() {
  return (
    <main className="py-16 md:py-24 mt-[100px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="prose prose-slate max-w-none">
          <h1 className="text-3xl font-bold mb-8">Privacy Policy</h1>
          
          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">1. Information We Collect</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in 
              dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. 
              Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">2. How We Use Your Data</h2>
            <p>
              Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem 
              ipsum dolor sit amet, consectetur adipiscing elit.
            </p>
            <ul className="list-disc pl-6 mt-4">
              <li>To provide and maintain our service</li>
              <li>To notify you about changes to our service</li>
              <li>To provide customer support</li>
              <li>To detect, prevent and address technical issues</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">3. Data Protection</h2>
            <p>
              Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit 
              amet, ante. Donec eu libero sit amet quam egestas semper. Aenean 
              ultricies mi vitae est.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">4. Your Rights</h2>
            <p>
              Mauris placerat eleifend leo. Quisque sit amet est et sapien 
              ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">5. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact 
              us at: example@domain.com
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
