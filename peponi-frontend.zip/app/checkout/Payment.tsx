import React, { useState, useEffect } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import CheckoutForm from "./CheckoutForm";
const stripePromise = loadStripe("pk_test_51QsVSHQu5uBZTcwUYVeHJ88nZW9LisYxAay5wqSc3auS6iZRVjuLgVDaeViaNNWUOxrAnHWwhIKPnOLkqlhsNV2200VbOjVLD2");

interface payment{
  order:any
  email:string
}
export default function Payment({order,email}:payment) {
  const [clientSecret, setClientSecret] = useState("");
  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/create-payment-intent`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: [{ id: "xl-tshirt", amount: 1000 }] }),
    })
      .then((res) => res.json())
      .then((data) => setClientSecret(data.clientSecret));
  }, []);
  // const appearance:any = {
  //   theme: 'stripe',
  // };  
  const loader = 'auto';
  return (
      <div className="App">
        {clientSecret && (
          <Elements options={{clientSecret, loader}} stripe={stripePromise}>          
              <CheckoutForm  email={email}/>
          </Elements>
        )}
      </div>
  );
}