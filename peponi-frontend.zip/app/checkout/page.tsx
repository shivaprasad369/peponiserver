"use client"
import React, { useEffect, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from "react-hook-form";
import Cookies from 'js-cookie';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/lib/firebase/firebase-config';
import useCheckout from '../hooks/useCheckout';
import Link from 'next/link';
import { isEmpty } from 'lodash';
import SavedAddresses from "./SavedAddresses"

export default function page() {
    const queryClient = useQueryClient();
    const cartNumber = Cookies.get("userId");
    const orderId = Cookies.get("orderId");
    const [load, setLoad] = useState(true)
    const router = useRouter();
    const [userEmail, setUserEmail] = useState("");
    const [total, setTotal] = useState(0)
    const [grand, setGrand] = useState(0)
    const [addressId,setAddressId]=useState(0)
    const { register, handleSubmit, watch, formState: { errors },reset,setValue } = useForm();
    const [sameAsBilling, setSameAsBilling] = useState(false); // Default to true
    const [newOne, setNewOne]=useState(0)
    const { checkout, data: data1, setData } = useCheckout();
    const { isLoading, error, data:datas } = useQuery({
        queryKey: ["carts", cartNumber, userEmail], // Dependencies
        queryFn: async () => {
            if (!userEmail) return [];

            try {
                const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/cart/get-cart-by-number`, {
                    params: {
                        cartNumber,
                        email: userEmail || null,
                        user: userEmail ? 2 : 1
                    },
                });
                return response.data.data || [];
            } catch (err) {
                // console.error("Error fetching cart details:", err);
                return [];
            }
        },
        enabled: !!userEmail, // Ensures the query only runs if cartNumber exists
    });
    useEffect(() => {
        if (datas && datas.length > 0) {
            setLoad(false);

            let total = 0;
            let grand = 0;

            datas.forEach((item:any) => {
                total += item.Qty * Number(item.SellingPrice);
                grand += item.Qty * Number(item.SellingPrice) * (1 + (Number(item.Voucherprice) / 100));
            });

            setTotal(total);
            setGrand(grand);
        }
    }, [datas]); // Only depend on `data`

    const onSubmit = (data: any) => {
       
            const shippingInfo =sameAsBilling
              ? {
                  ShippingFirstname: data.billingFirstName,
                  ShippingLastname: data.billingLastName,
                  ShippingAddress: data.billingAddress,
                  ShippingAddressLine2: data.billingAddressLine2 || null,
                  ShippingCity: data.billingCity,
                  ShippingPostalcode: data.billingPostalCode,
                  ShippingCountry: data.billingCountry,
                  ShippingEmailID: data.billingEmail,
                  ShippingPhone: data.billingPhone,
                }
              : {
                  ShippingFirstname: data.shippingFirstName,
                  ShippingLastname: data.shippingLastName,
                  ShippingAddress: data.shippingAddress,
                  ShippingAddressLine2: data.shippingAddressLine2 || null,
                  ShippingCity: data.shippingCity,
                  ShippingPostalcode: data.shippingPostalCode,
                  ShippingCountry: data.shippingCountry,
                  ShippingEmailID: data.shippingEmail,
                  ShippingPhone: data.shippingPhone,
                };
            const orderNumber = "ORD" + Math.floor(Math.random() * 9000) + 1000;
            
            const grandItemTotal = datas
              ?.reduce((acc:any, item:any) => acc + item.SellingPrice * item.Qty, 0)
              .toFixed(1);
            const grandTotal = (parseFloat(grandItemTotal) + 10).toFixed(1);
            checkout({
                addressId:addressId,
              UserEmail: userEmail,
              OrderNumber: orderNumber,
              BillingFirstname: data.billingFirstName,
              BillingLastname: data.billingLastName,
              BillingAddress: data.billingAddress,
              BillingAddressLine2: data.billingAddressLine2 || null,
              BillingCity: data.billingCity,
              BillingPostalcode: data.billingPostalCode,
              BillingCountry: data.billingCountry,
              BillingEmailID: data.billingEmail,
              BillingPhone: data.billingPhone,
              ...shippingInfo,
              GrandItemTotal: grandItemTotal,
              GrandTotal: grandTotal,
              ShippingPrice: 10,
              items: datas.map((item:any) => ({
                productID:item.ProductID,
                productAttributeID: item.ProductAttributeID,
                quantity: item.Qty,
                OrderNumber: orderNumber,
              })),
            });
          
            reset();
        
    };
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                setUserEmail(user.email || "");
            } else {
                setUserEmail("");
                router.replace('/login')
            }
            // setUserEmail(user ? user.email || "" : "");
        });

        return () => unsubscribe();
    }, []);
    useEffect(()=>{ 
        if(addressId && newOne!==1 ){
        const fetchData=async()=>{
           
            const res=await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/checkout/address/${addressId}`
            
            );
            if(res.status===200){
               
                // setData(res.data.data)
                setValue("billingFirstName", res.data.data?.BillingFirstname);
    setValue("billingLastName", res.data.data?.BillingLastname);
    setValue("billingAddress", res.data.data?.BillingAddress);
    setValue("billingAddressLine2", res.data.data?.BillingAddressLine2);
    setValue("billingCity", res.data.data?.BillingCity);
    setValue("billingPostalCode", res.data.data?.BillingPostalcode);
    setValue("billingCountry", res.data.data?.BillingCountry);
    setValue("billingEmail", res.data.data?.BillingEmailID);
    setValue("billingPhone", res.data.data?.BillingPhone);
    setValue("shippingFirstName", res.data.data?.ShippingFirstname);
    setValue("shippingLastName", res.data.data?.ShippingLastname);
    setValue("shippingAddress", res.data.data?.ShippingAddress);
    setValue("shippingAddressLine2", res.data.data?.ShippingAddressLine2);
    setValue("shippingCity", res.data.data?.ShippingCity);
    setValue("shippingPostalCode", res.data.data?.ShippingPostalcode);
    setValue("shippingCountry", res.data.data?.ShippingCountry);
    setValue("shippingEmail", res.data.data?.ShippingEmailID);
    setValue("shippingPhone", res.data.data?.ShippingPhone);
            }
            else{
              
                console.log("error")
            }
        }
        fetchData()
    }else{
        reset()
        setAddressId(0)
    }
      },[addressId,newOne])
   if(!isLoading ){
    if(isEmpty(datas)){
    return <div className="flex flex-col items-center   justify-center h-screen">
        <h1 className="text-xl font-bold">Cart is empty</h1>
        <Link href="/">
            <span className="text-blue-600 hover:text-blue-800">Go to Home</span>
        </Link>
    </div>
    }
   }
   const handleUpdate=(id:number)=>{
    console.log(id)
   }
   
    const shadow =
        <div className='flex flex-col gap-2 border-[1px] border-black rounded-lg p-4'>
            {[1, 2, 3].map((_, index: any) => <div key={index} className="checkout-wrapper flex gap-4 p-4 border rounded-lg shadow-md animate-pulse">
               
                <div className="bg-gray-300 rounded-md w-[100px] h-[100px]"></div>

                <div className="title-wrapper flex flex-col flex-1 gap-2">
                  
                    <div className="bg-gray-300 h-4 w-3/4 rounded-md"></div>

                   
                    <div className="bg-gray-200 h-3 w-1/2 rounded-md"></div>

                 
                    <div className="flex gap-2 items-center">
                        <div className="bg-gray-200 h-3 w-16 rounded-md"></div>
                        <div className="bg-gray-400 h-4 w-12 rounded-md"></div>
                    </div>
                </div>

                <div className="flex flex-col items-end">
                   
                    <div className="bg-gray-400 h-4 w-16 rounded-md"></div>

                
                    <div className="bg-gray-300 h-3 w-20 rounded-md mt-1"></div>
                </div>
            </div>)}
        </div>
        
    return (
        <section className="checkout-sec mt-[150px] w-[100%]">
            <form className="container w-[100%]" onSubmit={handleSubmit(onSubmit)}>
                <h2>Checkout</h2>
                <div className=''>

                </div>  
                <SavedAddresses email={userEmail} reset={reset} setNewOne={setNewOne} setAddress={setAddressId} onUpdate={handleUpdate}/>
                <div className={` lg:flex max-lg:flex max-lg:flex-col gap-5 w-[100%]`}>
                    <div className={`lg:w-[70%] ${newOne===1  ? "border-[#FFA216]"
                  : "border-gray-200"} `}>
                        <div className="contact-form checkout-form">
                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your First Name*"
                                            {...register("billingFirstName", { required: "First name is required" })}
                                        />
                                        {errors.billingFirstName && <p className="text-red-500 text-sm">{String(errors.billingFirstName.message)}</p>}
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your Last Name*"
                                            {...register("billingLastName", { required: "Last name is required" })}
                                        />
                                        {errors.billingLastName && <p className="text-red-500 text-sm">{String(errors.billingLastName.message)}</p>}
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <textarea
                                            placeholder="Enter Your Address*"
                                            {...register("billingAddress", { required: "Address is required" })}
                                        ></textarea>
                                        {errors.billingAddress && <p className="text-red-500 text-sm">{String(errors.billingAddress.message)}</p>}
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <textarea
                                            placeholder="Apartment, suite, etc.*"
                                            {...register("billingAddressLine2")}
                                        ></textarea>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your City*"
                                            {...register("billingCity", { required: "City is required" })}
                                        />
                                        {errors.billingCity && <p className="text-red-500 text-sm">{String(errors.billingCity.message)}</p>}
                                    </div>
                                </div>

                                {/* Billing Postal Code */}
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your Postal Code*"
                                            {...register("billingPostalCode", { required: "Postal code is required" })}
                                        />
                                        {errors.billingPostalCode && <p className="text-red-500 text-sm">{String(errors.billingPostalCode.message)}</p>}
                                    </div>
                                </div>

                                {/* Billing Country */}
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your Country*"
                                            {...register("billingCountry", { required: "Country is required" })}
                                        />
                                        {errors.billingCountry && <p className="text-red-500 text-sm">{String(errors.billingCountry.message)}</p>}
                                    </div>
                                </div>

                                {/* Billing Email */}
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="email"
                                            placeholder="Enter Your Email Address*"
                                            {...register("billingEmail", {
                                                required: "Email is required",
                                                pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" }
                                            })}
                                        />
                                        {errors.billingEmail && <p className="text-red-500 text-sm">{String(errors.billingEmail.message)}</p>}
                                    </div>
                                </div>

                                {/* Billing Phone */}
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <input
                                            type="text"
                                            placeholder="Enter Your Phone*"
                                            {...register("billingPhone", { required: "Phone number is required" })}
                                        />
                                        {errors.billingPhone?.message && (
                                            <p className="text-red-500 text-sm">{String(errors.billingPhone.message)}</p>
                                        )}
                                    </div>
                                </div>
                                <div className="billing-address">
                                    <input type="checkbox"
                                        onChange={() => setSameAsBilling((pre) => !pre)}
                                        checked={sameAsBilling}
                                        id="btncheck1" />
                                    <label htmlFor="btncheck1">Shipping address same as billing address</label>
                                </div>
                                {!sameAsBilling &&<>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your First Name*"
                                                {...register("shippingFirstName", { required: "First name is required" })}
                                            />
                                            {errors.shippingFirstName && <p className="text-red-500 text-sm">{String(errors.shippingFirstName.message)}</p>}
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your Last Name*"
                                                {...register("shippingLastName", { required: "Last name is required" })}
                                            />
                                            {errors.shippingLastName && <p className="text-red-500 text-sm">{String(errors.shippingLastName.message)}</p>}
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <textarea
                                                placeholder="Enter Your Address*"
                                                {...register("shippingAddress", {
                                                    required: "Address is required"

                                                })}
                                            ></textarea>
                                            {errors.shippingAddress && <p className="text-red-500 text-sm">{String(errors.shippingAddress.message)}</p>}
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your City*"
                                                {...register("shippingCity", {
                                                    required: "City is required"
                                                })}
                                            />
                                            {errors.shippingCity && <p className="text-red-500 text-sm">{String(errors.shippingCity.message)}</p>}
                                        </div>
                                    </div>

                                    {/* Shipping Postal Code */}
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your Postal Code*"
                                                {...register("shippingPostalCode", {
                                                    required: "Postal code is required"

                                                })}
                                            />
                                            {errors.shippingPostalCode && <p className="text-red-500 text-sm">{String(errors.shippingPostalCode.message)}</p>}
                                        </div>
                                    </div>

                                    {/* Shipping Country */}
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your Country*"
                                                {...register("shippingCountry", {
                                                    required: "Country is required"
                                                })}
                                            />
                                            {errors.shippingCountry && <p className="text-red-500 text-sm">{String(errors.shippingCountry.message)}</p>}
                                        </div>
                                    </div>
                                    {/* Billing Email */}
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="email"
                                                placeholder="Enter Your Email Address*"
                                                {...register("shippingEmail", {
                                                    required: "Email is required",
                                                    pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" }
                                                })}
                                            />
                                            {errors.shippingEmail && <p className="text-red-500 text-sm">{String(errors.shippingEmail.message)}</p>}
                                        </div>
                                    </div>

                                    {/* Billing Phone */}
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <input
                                                type="text"
                                                placeholder="Enter Your Phone*"
                                                {...register("shippingPhone", { required: "Phone number is required" })}
                                            />
                                            {errors.shippingPhone && <p className="text-red-500 text-sm">{String(errors.shippingPhone.message)}</p>}
                                        </div>
                                    </div></>}
                            </div>

                        </div>
                    </div>
                    <div className="lg:w-[30%]">
                        {!isLoading ? <div className="checkout-sidebar flex flex-col gap-3 lg:sticky lg:top-[30px]">
                            {datas?.map((product: any, index: number) =>
                                <div key={product.ProductID} className="checkout-wrapper ">
                                    <img src={`${process.env.NEXT_PUBLIC_API_URL}/${product.Image}`} alt={product.ProductName} width={100} height={100} />
                                    <div className="title-wrapper">
                                        <h6>{product.ProductName}</h6>
                                        <p>{product.CategoryName}</p>
                                        <div className="flex gap-2 items-center">
                                            <span className="regular-price text-xs line-through ">${product?.ProductPrice}</span>
                                            <span className="sell-price text-sm font-bold">${product?.SellingPrice}</span>
                                        </div>
                                    </div>
                                    <div className=" flex flex-col">
                                        <span className="sell-price font-bold">${Number(product?.SellingPrice) * product.Qty}</span>
                                        <p className='text-[10px]'>({`${product.Qty} Quantities`}) </p>
                                    </div>
                                </div>)}
                            <div className="grand-total">
                                <div className="grand-total-inn">
                                    <h6>Grandtotal:</h6>
                                    <p>All transactions are secure and encrypted.</p>
                                </div>
                                <span>${total !== 0 && Math.ceil(total)}</span>
                            </div>
                            <div className="final-amount">
                                <p>Final amount (Tax Included)</p>
                                <span>${grand !== 0 && Math.ceil(grand)}</span>
                            </div>
                          
                            <button className="primary-btn flex items-center justify-center ">Continue</button>
                            <a href="#" className="shopping-btn"><i className="fa-solid fa-arrow-left"></i>Continue Shopping</a>
                        </div> : shadow}
                    </div>
                </div>
            </form>
            {/* <Checkout/> */}
        </section>
    )
}
