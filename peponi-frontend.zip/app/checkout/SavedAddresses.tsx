import axios from "axios";
import { isEmpty } from "lodash";
import { use, useEffect, useState } from "react";
import { MdDeleteOutline } from "react-icons/md";
interface Address {
  AddressID: number;
  BillingFirstname: string;
  BillingAddress: string;
  UserEmail: string;
}

interface Ids {
  setNewOne:(id:number)=>void,
  setAddress: (id: number) => void;
  onUpdate: (id:number) => void;
  email: string;
  reset:()=>void
}

export default function SavedAddresses({setNewOne, email, setAddress, onUpdate,reset }: Ids) {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<Address[]>([]);
  const id= localStorage.getItem('addressId')
  const fetchAddresses = async (email: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/checkout/address`, {
        params: { email },
      });

      setData(response.data.data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {

    fetchAddresses(email);
  }, [email]);


  const handleSelectAddress = (id: number) => {
    setSelectedId(id);
    setAddress(id);
    setNewOne(0)
  };

  if (loading) return <p>Loading...</p>;
  // if (error) return <p className="text-red-500">{error}</p>;
  const handleNew=()=>{
    setSelectedId(0)
    setNewOne(1)
  }
  const handleDelete = async (id: number) => {
    const confirmTo=window.confirm("Are You Sure, you want to delete this address")
   if(!confirmTo)return
    if (!id) {
        console.error("ID is required for deletion");
        return;
    }

    try {
        const response = await axios.delete(`${process.env.NEXT_PUBLIC_API_URL}/checkout/address/${id}`);
        console.log(response.data.message); // Log success message

        alert("Address deleted successfully!");
        localStorage.removeItem('addressId')
        reset()
        fetchAddresses(email);
    } catch (error) {
        console.error("Error deleting address:", error);
        alert("Failed to delete address. Please try again.");
    }
};
  return (
    <div className="w-full mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Saved Addresses</h3>
        {!isEmpty(data) &&<div onClick={handleNew} className="text-sm cursor-pointer px-3 py-2 font-medium rounded-md bg-[#FFA216] text-black">
          + Add New Address
        </div>}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {!isEmpty(data) &&
          data.map((addr) => (
            <div
              key={addr.AddressID}
              className={`group relative rounded-lg border-2 p-4 transition-all duration-200 hover:shadow-md cursor-pointer ${
                selectedId === addr.AddressID
                  ? "border-[#FFA216] bg-[#FFA216]/5"
                  : "border-gray-200 hover:border-gray-300 bg-white"
              }`}
              onClick={() => onUpdate(addr.AddressID)}
            >
              <div onClick={()=>handleDelete(addr.AddressID)} className="absolute hover:text-red-500 duration-300 top-[10px] text-xl right-[15px]">
              <MdDeleteOutline />
              </div>
              <div className="flex items-start space-x-4">
                <input
                  type="radio"
                  name="savedAddress"
                  value={addr.AddressID}
                  checked={selectedId === addr.AddressID}
                  onChange={() => handleSelectAddress(addr.AddressID)}
                  className="mt-1 h-4 w-4 text-[#FFA216] border-gray-300 focus:ring-[#FFA216]"
                />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-gray-900">{addr.BillingFirstname}</h4>
                  <p className="mt-1 text-sm text-gray-600">{addr.BillingAddress}</p>
                  <p className="mt-1 text-sm text-gray-500">{addr.UserEmail}</p>
                  <span
                    className={`mt-2 inline-block px-2 py-1 text-xs rounded-full ${
                      selectedId === addr.AddressID
                        ? "bg-[#FFA216]/20 text-[#FFA216]"
                        : "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {selectedId === addr.AddressID ? "Selected" : "Select"}
                  </span>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}
