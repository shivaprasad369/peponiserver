"use client"
import React, { useState } from "react";
import {
  PaymentElement,
  useStripe,
  useElements
} from "@stripe/react-stripe-js";

import Cookies from 'js-cookie';

export default function CheckoutForm({email}) {
  const stripe = useStripe();
  const elements = useElements();

  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }
  
    setIsLoading(true);
  
    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        // Make sure to change this to your payment completion page
        return_url: "http://localhost:3000/complete",
      },
    });
  
    if (error) {
      if (error.type === "card_error" || error.type === "validation_error") {
        setMessage(error.message);
      } else {
        setMessage("An unexpected error occurred.");
      }
      setIsLoading(false);
      return;
    }
  
    if (paymentIntent && paymentIntent.status === "succeeded") {
      console.log("Payment succeeded!");
    
      // Debugging before removal
      console.log("Before removal:", localStorage.getItem("orderId"));
    
      localStorage.removeItem("orderId");
    
      // Debugging after removal
      console.log("After removal:", localStorage.getItem("orderId")); // Should log null
    
      setTimeout(() => {
        window.location.href = "/order-success/" + orderId;
      }, 100);
    } else {
      setMessage("An unexpected error occurred.");
      setIsLoading(false);
    }
  };
  

  const paymentElementOptions = {
    layout: "accordion"
  }

  return (
    <form id="payment-form" onSubmit={handleSubmit}>

      <PaymentElement id="payment-element" className="mb-[1rem]" />
      <button disabled={isLoading || !stripe || !elements} id="submit" className="primary-btn flex items-center justify-center mt-[1rem]">
      <span id="button-text">
          {isLoading ? 'Wait' : "Pay now"}
        </span>
      </button>
      {/* Show any error or success messages */}
      {message && <div id="payment-message">{message}</div>}
    </form>
  );
}