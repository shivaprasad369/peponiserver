"use client";

import axios from "axios";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast, { Toaster } from "react-hot-toast";
import { VscLoading } from "react-icons/vsc";
export default function Page() {
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm();
    const [loading,setLoading]=useState(false)
    const onSubmit =async(data:any) => {
        setLoading(true)
        console.log("Form Data Submitted:", data);
        const res=await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/contact`,{
            name: data.name,
            email: data.email,
            message: data.message
            
        })
        if(res.status===200){
            setLoading(false)
            toast.success("Your message has been sent successfully")
            reset()
        }
        else{
            setLoading(false)
            toast.error("Failed to send message")
        }
        reset();
    };

    return (
        <section className="banner-contact-sec mt-[150px]">
            <Toaster/>
            <div className="container mx-auto px-4 max-w-7xl">
                <div className="flex flex-wrap -mx-4">
                    <div className="w-full md:w-1/2 lg:w-7/12 px-4">
                        <div className="contact-form">
                            <h2>Contact Us</h2>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <div className="form-group">
                                    <label htmlFor="name">Enter Full Name</label>
                                    <input
                                        type="text"
                                        id="name"
                                        placeholder="Enter Your Full Name*"
                                        {...register("name", { required: "Full name is required" })}
                                    />
                                    {errors.name && <p className="text-red-500">{String(errors.name.message)}</p>}
                                </div>

                                <div className="form-group">
                                    <label htmlFor="email">Enter Email Address</label>
                                    <input
                                        type="email"
                                        id="email"
                                        placeholder="Enter Your Email Address*"
                                        {...register("email", { 
                                            required: "Email is required", 
                                            pattern: { 
                                                value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 
                                                message: "Invalid email address"
                                            }
                                        })}
                                    />
                                    {errors.email && <p className="text-red-500">{String(errors.email.message)}</p>}
                                </div>

                                <div className="form-group">
                                    <label htmlFor="message">Enter Message</label>
                                    <textarea
                                        id="message"
                                        placeholder="Enter Your Message *"
                                        {...register("message", { required: "Message is required" })}
                                    ></textarea>
                                    {errors.message && <p className="text-red-500">{String(errors.message.message)}</p>}
                                </div>

                                <button className="submit-btn w-[100%] flex text-center items-center justify-center" disabled={loading} type="submit">
                                    {loading ? <VscLoading className="animate-spin ml-[45%]  text-center transition-all spin-in-90 duration-500"/> : 'Send'}
                                </button>
                            </form>
                        </div>
                    </div>

                    <div className="w-full md:w-1/2 lg:w-5/12 px-4 my-auto">
                        <div className="form-content">
                            <ul>
                                <li>
                                    <h5>Peponi Gallery Store</h5>
                                    <p>Discover our curated selection of artworks in person. [Gallery Address]</p>
                                </li>
                                <li>
                                    <h5>Call us:</h5>
                                    <a href="tel:0256 026 6552">+81 0256 026 6552</a>
                                </li>
                                <li>
                                    <h5>Email Us:</h5>
                                    <a href="mailto:peponigallery@gmail.com">peponigallery@gmail.com</a>
                                </li>
                            </ul>
                            <span>Thank You for Visiting Our Website!</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
