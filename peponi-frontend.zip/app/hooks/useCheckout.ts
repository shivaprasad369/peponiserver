import axios from 'axios';
import { useRouter } from 'next/navigation';
import React, { useState } from 'react';
const useCheckout = () => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
 const router= useRouter()
  const checkout = async (orderData:any) => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/checkout`, orderData);
      
      setData(await response.data); 
      localStorage.setItem('addressId',orderData?.addressId)
      router.replace('/checkout-summary')
    } catch (err:any) {
      alert(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return {
    checkout, 
    loading,
    setData,
    data,
    error,
    success,
  };
};

export default useCheckout;
