"use client";
import ProductFilter from "@/components/products/SubFilter";
import SortDropdown from "../../../components/products/SortDropdown";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function Products() {
  const [category, setCategory] = useState(0);
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [attributes, setAttributes] = useState({ all: [], result: [] });
  const [attr, setAttr] = useState([]);
  const params = useParams();
  const name = params?.name;

  const categoryName = Array.isArray(name) ? decodeURIComponent(name.join("")) : decodeURIComponent(name || "");
  const fieldName = "CashPrice";
  const action = "asc";

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [productsRes, categoryRes, attributeRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/category-products/all-collection?categoryName=all`, {
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            cache: "no-store",
          }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/attribute-category`, {
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            cache: "no-store",
          }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/attribute`, {
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            cache: "no-store",
          })
        ]);

        if (!productsRes.ok || !categoryRes.ok || !attributeRes.ok) {
          throw new Error("Failed to fetch data");
        }

        const [productsData, categoryData, attributeData] = await Promise.all([
          productsRes.json(),
          categoryRes.json(),
          attributeRes.json(),
        ]);

        setProducts(productsData);
        setAttributes(categoryData);
        setAttr(attributeData);

        const categoryResponse = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/category-products/collection?categoryName=${categoryName}`,
          {
            method: "GET",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
          }
        );

        if (!categoryResponse.ok) {
          throw new Error("Network response was not ok");
        }

        const categoryResult = await categoryResponse.json();
        setCategory(categoryResult.CategoryID[0]);
        window.scrollTo(0, 0);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [categoryName]);
console.log(category)
  return (
    <section className="mt-[150px]">
      <div className="container mx-auto px-4 py-8">
        <div>
          <ProductFilter
            allAttributes={attributes.all}
            attr={attr}
            category={category ? category :0}
            initialProducts={products}
            categoriesData={attributes?.result}
            fieldName={fieldName}
            action={action}
          />
        </div>
        <ul className="pagination-sec w-full flex justify-center items-center gap-2 mt-8">
          {[1, 2, 3, 4, 5].map((page) => (
            <li key={page}>
              <a href="#" className="px-3 py-1 border rounded hover:bg-gray-200">
                {page}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}