import SortDropdown from "../../components/products/SortDropdown"
import ProductFilter from "../../components/products/Filter"

async function getProducts() {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/category-products/all-collection?categoryName='all'`,
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        cache: 'no-store'
      }
    );
  
    if (!res.ok) {
      throw new Error('Failed to fetch products');
    }
  
    return res.json();
}

async function getCategory() {
    const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/home/attribute-category`,
        {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          cache: 'no-store'
        }
      );
    
      if (!res.ok) {
        throw new Error('Failed to fetch attributes');
      }
    
      return res.json();
}
async function getAttribute() {
  const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/attribute`,
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        cache: 'no-store'
      }
    );
  
    if (!res.ok) {
      throw new Error('Failed to fetch attributes');
    }
  
    return res.json();
}
export default async function Products() {
  const products = await getProducts()
    const attributes= await getCategory()
    const attr= await getAttribute();
    console.log(attr)
    var fieldName='CashPrice';
    var action ='asc'
  return (
    <section className="mt-[150px]">
      <div className="container mx-auto px-4 py-8">
        <div className="">
          <ProductFilter allAttributes ={attributes.all} attr={attr} initialProducts={products} categoriesData={attributes?.result} 
          fieldName={fieldName} 
          action={action}
          />
        </div>

        <ul className="pagination-sec w-full flex justify-center items-center gap-2 mt-8">
          {[1, 2, 3, 4, 5].map((page) => (
            <li key={page}>
              <a href="#" className="px-3 py-1 border rounded hover:bg-gray-200">
                {page}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

