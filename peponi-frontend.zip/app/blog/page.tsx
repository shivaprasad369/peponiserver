import Link from 'next/link';
import { slugify } from '@/lib/slugify';

interface Blog {
  id: number;
  title: string;
  slug:string,
  shortdesc: string;
  description: string;
  image: string;
  author: string;
  created_at: string;
  Status: number;
}

async function getBlogs(): Promise<Blog[]> {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/frontend-blog`, {
      cache: 'no-store' // or revalidate with: next: { revalidate: 60 }
    });
    const data = await response.json();
    console.log(data)
    // Filter out blogs with Status "0" before returning
    interface BlogsAPIResponse {
        result?: Blog[];
    }

    return ((data as BlogsAPIResponse).result || []).filter((blog: Blog) => blog.Status !== 0);
   
  } catch (error) {
    console.error('Failed to fetch blogs:', error);
    return [];
  }
}

export default async function BlogPage() {
  const blogs = await getBlogs();
  
  if (!blogs.length) {
    return <div className="min-h-screen mt-[120px] flex items-center justify-center">No blogs found</div>;
  }

  const featuredBlog = blogs[0];
  const secondaryBlogs = blogs.slice(1, 3);
  const previousBlogs = blogs.slice(3);

  return (
    <main className="min-h-screen mt-[120px] pb-10 bg-white">
      {/* Hero Section */}
      <section className="bg-[#FFA216] py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-semi-bold text-gray-900 mb-12 text-center">
            Our Latest Posts
          </h1>
          <div className="grid md:grid-cols-2 gap-8 min-h-[600px]">
            {/* Featured Post */}
            {featuredBlog && (
              <Link href={`/blog/${featuredBlog.slug}`} className="block h-full">
                <div className="bg-white  rounded-md border-gray-400 overflow-hidden hover:border-[#FFA216] transition-colors h-[550px] flex flex-col">
                  <div className="h-[300px] overflow-hidden">
                    <img
                      src={featuredBlog.image ? `${process.env.NEXT_PUBLIC_API_URL}/${featuredBlog.image}` : "https://picsum.photos/800/400"}
                      alt={featuredBlog.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6 pb-10 flex-1 flex flex-col">
                    <span className="text-sm text-gray-500 block mb-2">
                      {new Date(featuredBlog.created_at).toLocaleDateString("en-US", {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                      })}
                    </span>
                    <h2 className="text-2xl font-bold mb-3">
                      {featuredBlog.title}
                    </h2>
                    <p className="text-gray-600  flex-1">
                      {featuredBlog.shortdesc}
                    </p>
                  </div>
                </div>
              </Link>
            )}
            
            <div className="grid grid-rows-2 ">
              {secondaryBlogs.map((blog) => (
                <Link key={blog.id} href={`/blog/${blog.slug}`} className="block">
                  <div className="bg-white  rounded-md  overflow-hidden flex hover:border-[#FFA216] transition-colors h-[250px]">
                    <div className="w-1/3 overflow-hidden">
                      <img
                        src={blog.image ? `${process.env.NEXT_PUBLIC_API_URL}/${blog.image}` : `https://picsum.photos/400/300?random=${blog.id}`}
                        alt={blog.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <span className="text-sm text-gray-500 block mb-2">
                        {new Date(blog.created_at).toLocaleDateString("en-US", {
                          day: "numeric",
                          month: "long",
                          year: "numeric"
                        })}
                      </span>
                      <h3 className="text-xl font-bold mb-2">
                        {blog.title}
                      </h3>
                      <p className="text-gray-600 text-sm line-clamp-3 flex-1">
                        {blog.shortdesc}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Previous Posts Grid */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-semi-bold mb-8 mt-8 text-gray-900">Previous Posts</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {previousBlogs.length > 0 ? (
            previousBlogs.map((blog) => (
              <Link key={blog.id} href={`/blog/${slugify(blog.title)}-${blog.id}`} className="blog-card border overflow-hidden hover:border-[#FFA216] transition-colors">
                <img
                  alt={blog.title}
                  className="w-full h-72 object-cover"
                  src={`${process.env.NEXT_PUBLIC_API_URL}/${blog.image}`}
                />
                <div className="blog-content p-6">
                  <span className="text-sm text-gray-500 block mb-2">
                    {new Date(blog.created_at).toLocaleDateString("en-US", {
                      day: "numeric",
                      month: "long",
                      year: "numeric"
                    })}
                  </span>
                  <h3 className="font-semibold text-xl mb-3 group-hover:text-[#FFA216] transition-colors">
                    {blog.title}
                  </h3>
                  <p className="text-gray-700 text-base line-clamp-3">{blog.shortdesc}</p>
                </div>
              </Link>
            ))
          ) : (
            [1, 2, 3].map((_, index) => (
              <div key={index} className="blog-card border overflow-hidden animate-pulse">
                <div className="w-full h-56 bg-gray-300" />
                <div className="blog-content p-6">

                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </main>
  );
}
