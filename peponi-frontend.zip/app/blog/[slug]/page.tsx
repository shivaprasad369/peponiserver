import { Metadata } from 'next';
import Link from "next/link";
import React from 'react';
import ProductSidebar from "@/components/blog/ProductSidebar";
import ShareButtons from '@/components/blog/ShareButtons';

interface BlogPostData {
  id: number;
  slug:string,
  title: string;
  shortdesc: string;
  description: string;
  image: string;
  author: string;
  created_at: string;
  Status: number;
}

async function getBlogs(): Promise<BlogPostData[]> {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/frontend-blog`, {
      cache: 'no-store'
    });
    const data = await response.json();
    return data.result || [];
  } catch (error) {
    console.error('Failed to fetch blogs:', error);
    return [];
  }
}

async function getBlogPost(slug: string): Promise<BlogPostData | null> {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/frontend-blog/${slug}`, {
      cache: 'no-store'
    });
    
    if (!response.ok) {
      console.error('Blog post not found, status:', response.status);
      return null;
    }

    const data = await response.json();
    if (!data || !data.result) {
      console.error('Invalid API response:', data);
      return null;
    }

    const blog = Array.isArray(data.result) ? data.result[0] : data.result;
    return blog || null;
  } catch (error) {
    console.error('Failed to fetch blog post:', error);
    return null;
  }
}

async function getInitialCollectionData() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/collection?collection=1`, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      next: { revalidate: 3600 },
    });
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch collection data:", error);
    return [];
  }
}

type BlogParams = Promise <{ slug: string }>;

export default async function BlogPost({
  params,
}: {
  params: BlogParams;
}){

    const { slug } = await params;

  if (!slug) {
    return <div className="min-h-screen mt-[120px] flex items-center justify-center">Invalid blog URL</div>;
  }

  const [blog, allBlogs, products] = await Promise.all([
    getBlogPost(slug),
    getBlogs(),
    getInitialCollectionData()
  ]);

  if (!blog) {
    return <div className="min-h-screen mt-[120px] flex items-center justify-center">Blog post not found</div>;
  }
  const relatedPosts = allBlogs
    .filter(post => post.id !== blog.id)
    .slice(0, 3);
  return (
    <main className="min-h-screen mt-[150px] bg-white">
      {/* Hero Section */}
      <div className="py-10">
        <div className="container mx-auto px-4 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold max-w-4xl mb-4">
            {blog.title}
          </h1>
          <p className="text-gray-600 text-lg max-w-4xl">
            {blog.shortdesc}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content Column */}
          <div className="w-full lg:w-2/3">
            {/* Featured Image */}
            <div className="mb-8">
              <img
                src={`${process.env.NEXT_PUBLIC_API_URL}/${blog.image}`}
                alt={blog.title}
                className="w-full max-h-[600px] object-cover rounded-lg"
              />
            </div>

            {/* Article Content */}
            <div className="prose prose-lg max-w-none">
              {blog.description && (
                <div
                  dangerouslySetInnerHTML={{
                    __html: blog.description.toString()
                  }}
                />
              )}
            </div>

            {/* Author and Share Section */}
            <div className="mt-12 pt-8 border-t">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                {/* Author Info */}
                <div className="flex items-center gap-4">
                  <img
                    src="https://picsum.photos/50/50"
                    alt={blog.author}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <div className="font-medium">{blog.author}</div>
                    <div className="text-sm text-gray-500">
                      {new Date(blog.created_at).toLocaleDateString("en-US", {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                      })}
                    </div>
                  </div>
                </div>

                {/* Share Buttons */}
                <ShareButtons 
                  title={blog.title}
                  description={blog.shortdesc}
                />
              </div>
            </div>
          </div>

          {/* Product Sidebar */}
          <ProductSidebar products={products} />
        </div>

        {/* Related Posts section */}
        <section className="mt-16 mb-24">
          <h2 className="text-3xl font-bold mb-12">More Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {relatedPosts.map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`} className="blog-card border overflow-hidden hover:border-[#FFA216] transition-colors">
                <img
                  src={`${process.env.NEXT_PUBLIC_API_URL}/${post.image}`}
                  alt={post.title}
                  className="w-full h-72 object-cover"
                />
                <div className="blog-content p-6">
                  <span className="text-sm text-gray-500 block mb-2">
                    {new Date(post.created_at).toLocaleDateString("en-US", {
                      day: "numeric",
                      month: "long",
                      year: "numeric"
                    })}
                  </span>
                  <h3 className="font-semibold text-xl mb-3 group-hover:text-[#FFA216] transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-gray-700 text-base line-clamp-3">
                    {post.shortdesc}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
