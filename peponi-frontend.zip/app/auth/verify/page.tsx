'use client'

import { Suspense, useEffect, useState } from 'react'
import { auth } from '@/lib/firebase/firebase-config'
import { onAuthStateChanged, sendEmailVerification } from 'firebase/auth'
import { useRouter } from 'next/navigation'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

// Separate client component for the verification UI
function VerificationUI({ 
  user, 
  handleResendEmail, 
  countdown,
  isResendDisabled 
}: {
  user: any;
  handleResendEmail: () => Promise<void>;
  countdown: number;
  isResendDisabled: boolean;
}) {
  return (
    <section className="verify-sec mt-[150px]">
      <div className="max-w-md mx-auto p-6 bg-white rounded-lg">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Verify Your Email</h2>
          <p className="mb-4">
            We've sent a verification email to:
            <br />
            <span className="font-semibold">{user?.email}</span>
          </p>
          <p className="text-gray-600 mb-6">
            Please check your email and click the verification link to continue.
          </p>
          <button
            onClick={handleResendEmail}
            disabled={isResendDisabled}
            className={`bg-[#FFA216] text-black px-6 py-2 rounded transition-colors ${
              isResendDisabled ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {isResendDisabled 
              ? `Resend available in ${countdown}s` 
              : 'Resend Verification Email'}
          </button>
        </div>
      </div>
    </section>
  )
}

export default function Verify() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [countdown, setCountdown] = useState(60)
  const [isResendDisabled, setIsResendDisabled] = useState(true)
  const router = useRouter()

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else {
      setIsResendDisabled(false);
    }
    return () => clearInterval(timer);
  }, [countdown]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user)
        setLoading(false)
        setCountdown(60)
        setIsResendDisabled(true)
      } else {
        router.push('/login')
      }
    })

    return () => unsubscribe()
  }, [router])

  const handleResendEmail = async () => {
    if (user && !user.emailVerified) {
      try {
        await sendEmailVerification(user)
        setIsResendDisabled(true)
        setCountdown(60)
        alert('Verification email sent!')
      } catch (error) {
        alert('Error sending verification email')
      }
    }
  }

  if (loading) {
    return <LoadingSpinner />
  }

  return (
    <Suspense fallback={<LoadingSpinner />}>
      <VerificationUI
        user={user}
        handleResendEmail={handleResendEmail}
        countdown={countdown}
        isResendDisabled={isResendDisabled}
      />
    </Suspense>
  )
}