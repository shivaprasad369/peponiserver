'use client'

import { useEffect, useState } from 'react'
import { auth } from '@/lib/firebase/firebase-config'
import { applyActionCode } from 'firebase/auth'
import { useRouter } from 'next/navigation'
import CheckmarkAnimation from '@/components/ui/CheckmarkAnimation'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

export default function VerifiedPage() {
    const [verificationStatus, setVerificationStatus] = useState<'loading' | 'success' | 'error'>('loading')
    const router = useRouter()

    useEffect(() => {
        const handleVerificationCode = async () => {
            const params = new URLSearchParams(window.location.search)
            const oobCode = params.get("oobCode")

            if (!oobCode) {
                setVerificationStatus('error')
                return
            }

            try {
                await applyActionCode(auth, oobCode)
                if (auth.currentUser) {
                    await auth.currentUser.reload()
                    if (auth.currentUser.emailVerified) {
                        // Update verification status in database
                        try {
                            const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/user/verify`, {
                                method: 'PUT',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({
                                    emailId: auth.currentUser.email,
                                    isVerified: 1
                                }),
                            });

                            if (!response.ok) {
                                console.error('Failed to update verification status in database');
                            }
                        } catch (error) {
                            console.error('Error updating database:', error);
                        }

                        setVerificationStatus('success')
                    } else {
                        setVerificationStatus('error')
                    }
                }
            } catch (error) {
                setVerificationStatus('error')
            }
        }

        handleVerificationCode()
    }, [])

    if (verificationStatus === 'loading') {
        return <LoadingSpinner />
    }

    const handleLogin = async () => {
        await auth.signOut()
        router.push('/login')
    }

    return (
        <section className="mt-[150px]">
            <div className="max-w-md mx-auto pb-[75px] p-6 bg-white rounded-lg">
                <div className="flex justify-center mb-6">
                    {verificationStatus === 'success' && <CheckmarkAnimation />}
                </div>
                <div className="text-center">
                    {verificationStatus === 'success' ? (
                        <>
                            <h2 className="text-2xl font-medium mb-4 text-green-600">
                                Account Verified Successfully!
                            </h2>
                            <button
                                onClick={handleLogin}
                                className="bg-[#FFA216] text-black px-6 py-2 rounded transition-colors"
                            >
                               Login
                            </button>
                        </>
                    ) : (
                        <>
                            <h2 className="text-2xl font-medium mb-4 text-red-600">
                                Verification Failed
                            </h2>
                            <p className="mb-4 text-gray-600">
                                The verification link is invalid or has expired.
                            </p>
                         
                        </>
                    )}
                </div>
            </div>
        </section>
    )
}
