'use client';

import { useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Suspense } from 'react';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

export default function AuthAction() {
    const searchParams = useSearchParams();
    const router = useRouter();

    useEffect(() => {
        const mode = searchParams.get('mode');
        const oobCode = searchParams.get('oobCode');

        if (!mode || !oobCode) {
            router.push('/');
            return;
        }

        switch (mode) {
            case 'verifyEmail':
                router.push(`/auth/verified?oobCode=${oobCode}`);
                break;
            case 'resetPassword':
                router.push(`/auth/reset-password?oobCode=${oobCode}`);
                break;
            default:
                router.push('/');
        }
    }, [searchParams, router]);

    return (
        <Suspense fallback={<LoadingSpinner />}>
             <LoadingSpinner />
        </Suspense>
    );
}

