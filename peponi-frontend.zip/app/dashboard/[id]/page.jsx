"use client";
import { useParams, useRouter } from "next/navigation";
import React, { useState, useEffect } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase/firebase-config";

const SkeletonLoader = () => (
  <div className="w-full mt-[150px] flex items-center justify-center overflow-hidden py-6">
    <div className="w-full max-w-7xl flex flex-col items-center justify-center px-4">
      <div className="w-full flex flex-col gap-5">
        {/* Skeleton Header */}
        <div className="w-full h-8 bg-gray-300 rounded-md mb-4 animate-pulse"></div>
        
        {/* Skeleton Table */}
        <table className="table-auto w-full mt-4">
          <thead className="border-b-[1px] border-gray-300">
            <tr>
              <th></th>
              <th>Product</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Total(£)</th>
            </tr>
          </thead>
          <tbody className="text-center">
            {[...Array(3)].map((_, index) => (
              <tr key={index} className="border-b-[1px] border-gray-300">
                <td className="w-fit mt-2">
                  <div className="w-[2rem] h-[2rem] bg-gray-300 rounded-md animate-pulse"></div>
                </td>
                <td><div className="w-[120px] h-5 bg-gray-300 rounded-md animate-pulse"></div></td>
                <td><div className="w-[60px] h-5 bg-gray-300 rounded-md animate-pulse"></div></td>
                <td><div className="w-[60px] h-5 bg-gray-300 rounded-md animate-pulse"></div></td>
                <td><div className="w-[80px] h-5 bg-gray-300 rounded-md animate-pulse"></div></td>
              </tr>
            ))}
            {/* Skeleton Total */}
            <tr className="border-b-[1px] border-gray-300">
              <td></td>
              <td></td>
              <td></td>
              <td>
                <div className="w-[120px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              </td>
              <td><div className="w-[80px] h-5 bg-gray-300 rounded-md animate-pulse"></div></td>
            </tr>
          </tbody>
        </table>

        {/* Skeleton Order Summary */}
        <div className="mt-3 flex flex-col gap-5">
          <h1 className="w-[200px] h-8 bg-gray-300 rounded-md animate-pulse"></h1>
          <div className="w-full border-[1px] border-gray-300 p-4 rounded-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col gap-3">
                <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              </div>
              <div className="flex flex-col items-end gap-3">
                <div className="w-[120px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[80px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[80px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
                <div className="w-[80px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Skeleton Billing and Shipping Address */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
          <div className="flex flex-col gap-3">
            <h1 className="w-[150px] h-8 bg-gray-300 rounded-md animate-pulse"></h1>
            <div className="border-[1px] flex flex-col gap-1 border-gray-300 rounded-sm p-4">
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[150px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <h1 className="w-[150px] h-8 bg-gray-300 rounded-md animate-pulse"></h1>
            <div className="border-[1px] flex flex-col gap-1 border-gray-300 rounded-sm p-4">
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[200px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[100px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
              <div className="w-[150px] h-5 bg-gray-300 rounded-md animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const NotFound = () => (
  <div className="w-full mt-[150px] flex items-center justify-center py-6">
    <div className="w-full max-w-7xl flex flex-col items-center justify-center px-4">
      <div className="text-3xl font-bold text-gray-600">Order Not Found</div>
      <p className="mt-2 text-lg text-gray-500">
        We could not find an order with that ID. Please check the order number or contact support.
      </p>
      <div className="mt-5">
        <button
          onClick={() => window.history.back()}
          className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700"
        >
          Go Back
        </button>
      </div>
    </div>
  </div>
);

export default function Details() {
  const [load, setLoad] = useState(true);
  const { id } = useParams();
  const [orders, setOrders] = useState([]);
  const [authenticated, setAuthenticated] = useState(false);

  const [userEmail, setUserEmail] = useState("");
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  // Handle authentication state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (!user) {
        router.replace("/login");
      } else {
        setAuthenticated(true);
        setUserEmail(user ? user.email || "" : "");
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [router]);

  // Fetch order data when user email is set
  useEffect(() => {
    const fetchOrders = async () => {
      if (userEmail) {
        try {
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_API_URL}/home/dashboard/product?id=${id}&email=${userEmail}`
          );
          const data = await response.json();
          setOrders(data.result);
          setLoading(false);
        } catch (error) {
          console.error("Error fetching orders:", error);
          setLoading(false);
        }
      }
    };

    fetchOrders();
  }, [userEmail]);

  // Find order details matching the id
  const details = orders?.find(order => order.OrderNumber === id);

  useEffect(() => {
    setLoad(false);
  }, []);

  if (load || loading) {
    return <SkeletonLoader />;
  }

  if (!details) {
    return <NotFound />;
  }

  // Ensure details.Products exists before trying to map over it
  const products = details.Products || [];

  // Calculate total item cost
  const totalItemCost = products?.reduce(
    (total, product) => total + Number(product.ItemTotal),
    0
  );

  return (
    <div className="w-full mt-[150px] flex items-center justify-center overflow-hidden py-6">
      <div className="w-full max-w-7xl flex flex-col items-center justify-center px-4">
        <div className="w-full flex flex-col gap-5">
          <div className="text-2xl md:text-3xl flex items-center gap-2 tracking-wide font-bold">
            Order Detail #{details.OrderNumber}
            <span className="text-base md:text-lg text-[#926a2f] bg-[#ebdba7] px-3 py-1 rounded-md">
              {details.OrderStatus === 0 ? "Order Placed" : "Order Delivered"}
            </span>
          </div>

          <table className="table-auto w-full mt-4">
            <thead className="border-b-[1px] border-gray-300">
              <tr>
                <th></th>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Total(£)</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {products?.map((product, index) => (
                <tr key={product.ProductID * index} className="border-b-[1px] border-gray-300">
                  <td className="w-fit mt-2">
                    <img
                        src={`${process.env.NEXT_PUBLIC_API_URL}/${product?.ProductImages}`}
                      alt={product.ProductName}
                      className="w-[2rem] my-2 object-cover"
                    />
                  </td>
                  <td>{product.ProductName}</td>
                  <td>£{product.Price}</td>
                  <td>{product.Quantities}</td>
                  <td>£{product.ItemTotal}</td>
                </tr>
              ))}
              <tr className="border-b-[1px] border-gray-300">
                <td></td>
                <td></td>
                <td></td>
                <td>
                  <div className="font-bold my-2">Item Total :</div>
                </td>
                <td>£{totalItemCost}</td>
              </tr>
            </tbody>
          </table>

          <div className="mt-3 flex flex-col gap-5">
            <h1 className="text-2xl md:text-3xl font-bold">Order Summary</h1>
            <div className="w-full border-[1px] border-gray-300 p-4 rounded-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-3">
                  <h1 className="font-bold">
                    Order No : <span className="font-normal">{details.OrderNumber}</span>
                  </h1>
                  <span>Item(s) total</span>
                  <span>Shipping</span>
                  <span>Sub total</span>
                  <span className="font-bold">Final Payment</span>
                </div>
                <div className="flex flex-col items-end gap-3">
                  <h1 className="font-bold">
                    Order Date :{" "}
                    <span className="font-normal">{new Date(details.OrderDate).toLocaleDateString()}</span>
                  </h1>
                  <span>£{totalItemCost}</span>
                  <span>£{details.ShippingPrice || "FREE"}</span>
                  <span>£{totalItemCost}</span>
                  <span className="font-bold">£{details.GrandTotal}</span>
                </div>
              </div>

              <div className="mt-8 border-b-[1px] border-gray-300" />
              <h1 className="py-4 font-bold">Payment Details</h1>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-3">
                  <h1>Payment Date</h1>
                  <span>Payment Transaction Ref.</span>
                </div>
                <div className="flex flex-col items-end gap-3">
                  <h1>{new Date(details.OrderDate).toLocaleDateString()}</h1>
                  <span>{details.stripeid}</span>
                </div>
              </div>
            </div>

            <div className="mt-8 border-b-[1px] border-gray-300" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
              <div className="flex flex-col gap-3">
                <h1 className="font-bold text-lg">Billing Address</h1>
                <div className="border-[1px] flex flex-col gap-1 border-gray-300 rounded-sm p-4">
                  <span>{`${details.BillingFirstname} ${details.BillingLastname}`}</span>
                  <span>{details.BillingAddress}</span>
                  <span>{`${details.BillingCity}, ${details.BillingCountry} - ${details.BillingPostalcode}`}</span>
                  <div className="flex items-center gap-2">
                    <h4>Tel :</h4>
                    <span className="font-bold">{details.BillingPhone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <h4>Email :</h4>
                    <span className="font-bold">{details.BillingEmailID}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-3">
                <h1 className="font-bold text-lg">Shipping Address</h1>
                <div className="border-[1px] flex flex-col gap-1 border-gray-300 rounded-sm p-4">
                  <span>{`${details.ShippingFirstname} ${details.ShippingLastname}`}</span>
                  <span>{details.ShippingAddress}</span>
                  <span>{`${details.ShippingCity}, ${details.ShippingCountry} - ${details.ShippingPostalcode}`}</span>
                  <div className="flex items-center gap-2">
                    <h4>Tel :</h4>
                    <span className="font-bold">{details.ShippingPhone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <h4>Email :</h4>
                    <span className="font-bold">{details.ShippingEmailID}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
