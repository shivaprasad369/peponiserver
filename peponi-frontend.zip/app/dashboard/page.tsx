'use client'
import { useState, useEffect } from "react";
import Image from "next/image";
import img1 from "@/assets/images/dashboard.svg";
import img2 from "@/assets/images/profile.svg";
import img3 from "@/assets/images/order.svg";
import img4 from "@/assets/images/change-pass.svg";
import img5 from "@/assets/images/logout.svg";
import img6 from "@/assets/images/review.svg";
import img7 from "@/assets/images/dashboard-img.png";
import img8 from "@/assets/images/gettyimages.png";
import img9 from "@/assets/images/view.png";
import img10 from "@/assets/images/bin.png";
import img11 from "@/assets/images/cloud-computing.png";
import MyProfile from "@/components/dashboard/Myprofile";
import OrderTable from "@/components/dashboard/OrderTable";
import ChangePassword from "@/components/dashboard/ChangePassword";
import { signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from '@/lib/firebase/firebase-config'
import LogoutDialog from "@/components/dashboard/LogoutDialog";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Cookies from 'js-cookie';
import axios from "axios";
export default function Main() {
    const [loading, setLoading] = useState(true);
    const [authenticated, setAuthenticated] = useState(false);
    const [activeTab, setActiveTab] = useState('profile');
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
    const [userEmail, setUserEmail] = useState("");  
    const router = useRouter();
    
  const queryClient = useQueryClient();
  const cartNumber = Cookies.get("userId");
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {

            if (!user) {
                
                router.replace('/login');
            } else {
                setAuthenticated(true);
                setUserEmail(user ? user.email || "" : "");
                console.log(user);
            }
            setLoading(false);
        });

        return () => unsubscribe();
    }, [router]);
   
    useEffect(() => {
        const updateCartUser = async () => {
          if (userEmail!=='' && cartNumber) {
            try {
              await axios.put(`${process.env.NEXT_PUBLIC_API_URL}/cart/update-cart-user`, {
                cartNumber,
                email: userEmail,
                user: userEmail? 2 : 1, 
              }).then((res)=>{
                queryClient.invalidateQueries({queryKey:['carts',cartNumber,userEmail]})
              });
            } catch (error) {
              console.error("Error updating cart user:", error);
            }
          }
        };
    
        updateCartUser();
      }, [userEmail, cartNumber]);
    // Show loading state or nothing while checking auth
    if (loading) {
        return <div className="flex justify-center items-center min-h-screen">
            Loading...
        </div>;
    }

    // Only render dashboard if authenticated
    if (!authenticated) {
        return null;
    }

    const handleTabClick = (tab: string) => {
        setActiveTab(tab);
    };

    const handleLogout = async () => {
        setShowLogoutConfirm(true);
    };

    const confirmLogout = async () => {
        try {
            await signOut(auth);
            router.push('/');
        } catch (error) {
            console.error('Error logging out:', error);
        }
        setShowLogoutConfirm(false);
    };

    const closeLogoutDialog = () => {
        setShowLogoutConfirm(false);
    };

  

    return (
        <section className="dashboard-sec mt-[150px]">
            <div className="container mx-auto px-4">
                <h2>Dashboard</h2>
                <div className="flex flex-wrap -mx-4">
                    <div className="w-full md:w-1/3 lg:w-1/4 px-4">
                        <div className="left-sidebar">
                            <Image src={img7} alt="Dashboard" width={200} height={200} />
                            <h5 className="name">Joel</h5>
                            <div className="arrow-border"></div>
                            <ul>
                                <li>
                                    <a 
                                        onClick={() => handleTabClick('profile')} 
                                        className={`flex items-center cursor-pointer ${activeTab === 'profile' ? 'text-black font-semibold' : 'text-gray-600'}`}
                                    >
                                        <Image src={img2} alt="Profile" width={20} height={20} />My Profile
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        onClick={() => handleTabClick('orders')} 
                                        className={`flex items-center cursor-pointer ${activeTab === 'orders' ? 'text-black font-semibold' : 'text-gray-600'}`}
                                    >
                                        <Image src={img3} alt="Order" width={20} height={20} />My Orders
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        onClick={() => handleTabClick('reviews')} 
                                        className={`flex items-center cursor-pointer ${activeTab === 'reviews' ? 'text-black font-semibold' : 'text-gray-600'}`}
                                    >
                                        <Image src={img6} alt="Reviews" width={20} height={20} />My Reviews
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        onClick={() => handleTabClick('password')} 
                                        className={`flex items-center cursor-pointer ${activeTab === 'password' ? 'text-black font-semibold' : 'text-gray-600'}`}
                                    >
                                        <Image src={img4} alt="Password" width={20} height={20} />Change Password
                                    </a>
                                </li>
                                <li>
                                    <a onClick={handleLogout} className="flex items-center text-gray-600 cursor-pointer">
                                        <Image src={img5} alt="Logout" width={20} height={20} />Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="w-full md:w-2/3 lg:w-3/4 px-4">
                        <div className="flex flex-wrap -mx-4">
                            <div 
                                className="w-full md:w-1/3 lg:w-1/4 px-4 mb-4 cursor-pointer" 
                                onClick={() => handleTabClick('profile')}
                            >
                                <div className={`card-box flex flex-col content-center items-center ${activeTab === 'profile' ? ' ring-1 ring-black' : ''}`}>
                                    <Image className="" src={img2} alt="Profile" width={40} height={40} />
                                    <span>My Profile</span>
                                    <p>Lorem ipsum dolor amet eiusmod tempor.</p>
                                </div>
                            </div>
    
                            <div 
                                className="w-full md:w-1/3 lg:w-1/4 px-4 mb-4 cursor-pointer"
                                onClick={() => handleTabClick('orders')}
                            >
                                <div className={`card-box flex flex-col content-center items-center ${activeTab === 'orders' ? ' ring-1 ring-black' : ''}`}>
                                    <Image src={img3} alt="Orders" width={40} height={40} />
                                    <span>My Orders</span>
                                    <p>View the progress of your orders</p>
                                </div>
                            </div>
                            <div 
                                className="w-full md:w-1/3 lg:w-1/4 px-4 mb-4 cursor-pointer"
                                onClick={() => handleTabClick('reviews')}
                            >
                                <div className={`card-box flex flex-col content-center items-center ${activeTab === 'reviews' ? ' ring-1 ring-black' : ''}`}>
                                    <Image src={img6} alt="Reviews" width={40} height={40} />
                                    <span>My Reviews</span>
                                    <p>Lorem ipsum dolor amet eiusmod tempor.</p>
                                </div>
                            </div>
                            <div 
                                className="w-full md:w-1/3 lg:w-1/4 px-4 mb-4 cursor-pointer"
                                onClick={() => handleTabClick('password')}
                            >
                                <div className={`card-box flex flex-col content-center items-center ${activeTab === 'password' ? ' ring-1 ring-black' : ''}`}>
                                    <Image src={img4} alt="Password" width={40} height={40} />
                                    <span>Change Password</span>
                                    <p>Require a new password.</p>
                                </div>
                            </div>
                            {activeTab === 'profile' && <MyProfile />}
                            {activeTab === 'orders' && <OrderTable email={userEmail} />}
                            {activeTab === 'password' && <ChangePassword />}
                        </div>
                    </div>
                </div>
            </div>
            <LogoutDialog 
                isOpen={showLogoutConfirm}
                onClose={closeLogoutDialog}
                onConfirm={confirmLogout}
            />
        </section>
    )
}