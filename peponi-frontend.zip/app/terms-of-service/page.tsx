export default function TermsOfService() {
  return (
    <main className="py-16 md:py-24 mt-[100px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="prose prose-slate max-w-none">
          <h1 className="text-3xl font-bold mb-8">Terms of Service</h1>
          
          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">1. Agreement to Terms</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in 
              dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. 
              Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">2. Use License</h2>
            <p>
              Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem 
              ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut 
              gravida lorem.
            </p>
            <ul className="list-disc pl-6 mt-4">
              <li>Consectetur adipiscing elit</li>
              <li>Sed do eiusmod tempor incididunt</li>
              <li>Ut labore et dolore magna aliqua</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-4">3. Disclaimer</h2>
            <p>
              Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit 
              amet, ante. Donec eu libero sit amet quam egestas semper. Aenean 
              ultricies mi vitae est.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">4. Limitations</h2>
            <p>
              Mauris placerat eleifend leo. Quisque sit amet est et sapien 
              ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, 
              commodo vitae, ornare sit amet, wisi.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
