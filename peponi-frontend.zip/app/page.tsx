import About from "@/components/homepage/About";
import dynamic from "next/dynamic";

// Lazy load components
const Banner = dynamic(() => import("@/components/homepage/Banner"));

const Collection = dynamic(() => import("@/components/homepage/Collection"));
const Contact = dynamic(() => import("@/components/homepage/Contact"));
const Blogs = dynamic(() => import("@/components/homepage/Blogs"));
const Success = dynamic(() => import("@/components/homepage/Success"));
const Trending = dynamic(() => import("@/components/homepage/Trending"));
const Faq = dynamic(() => import("@/components/homepage/Faq"));
const Footer = dynamic(() => import("@/components/homepage/Footer"));

export default function Home() {
  return (
    <div>
      <Banner />
      <About />
      <Collection />
      <Contact />
      <Blogs />
      <Success />
      <Trending />
      <Faq />
      {/* <Footer /> */}
    </div>
  );
}
