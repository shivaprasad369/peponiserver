"use client"
import { auth } from '@/lib/firebase/firebase-config';
import axios from 'axios';
import { onAuthStateChanged } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react'
import { FaRegEdit } from "react-icons/fa";
export default function Summery() {
    const [userEmail, setUserEmail] = useState("");
    const [data,setData]=useState<any>([])
    const [loading, setLoading]=useState(true)
    const router=useRouter()
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
          setUserEmail(user?.email || "");
        });
        return () => unsubscribe();
      }, []);
     
   
      useEffect(()=>{
        if(userEmail){
        const fetchData=async()=>{
            setLoading(true)
            const res=await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/checkout`,
                {
                    params:{
                        user:userEmail
                    }
                }
            );
            if(res.status===200){
                setLoading(false)
                setData(res.data.data)
            }
            else{
                setLoading(false)
                console.log("error")
            }
        }
        fetchData()
    }
      },[userEmail])

  
    if(!loading &&!data){
        <p>Loading</p>
      }
      const handleMove=()=>{
        router.push('/checkout')
      }
  return (
    <div className="lg:w-[70%] flex flex-col gap-5" >
   
            <div className="border-[1px] rounded-xl border-[#252525] mt-3 p-5 flex flex-col gap-5">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Name :</span> <span>{data?.BillingFirstname} {data?.BillingLastname}</span></div>
                <FaRegEdit className='text-xl text-yellow-600 cursor-pointer' onClick={handleMove}/>
            </div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Email :</span> <span>{data?.BillingEmailID}</span></div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Country :</span> <span>{data?.BillingCountry}</span></div>
            <div className=" gap-2 "><span className="font-semibold text-md mr-2 ">Address :</span> <span>{data?.BillingAddress} , {data?.BillingAddressLine2}</span></div>
            <div className='md:flex md:items-center max-md:flex max-md:flex-col gap-5 md:gap-10'>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">City :</span> <span>{data?.BillingCity}</span></div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">PostalCode :</span> <span>{data?.BillingPostalcode}</span></div>

            </div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Phone Number :</span> <span>{data?.BillingPhone}</span></div>

                

            </div>
            <h2 className='mt-[2rem]'>Shipping Address</h2>
            <div className="border-[1px] rounded-xl border-[#252525] mt-3 p-5 flex flex-col gap-5">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Name :</span> <span>{data?.ShippingFirstname} {data?.ShippingLastname}</span></div>
                <FaRegEdit className='text-xl text-yellow-600 cursor-pointer' onClick={handleMove} />
            </div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Email :</span> <span>{data?.ShippingEmailID}</span></div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Country :</span> <span>{data?.ShippingCountry}</span></div>
            <div className=" gap-2 "><span className="font-semibold text-md mr-2 ">Address :</span> <span>{data?.ShippingAddress} , {data?.ShippingAddressLine2}</span></div>
            <div className='md:flex md:items-center max-md:flex max-md:flex-col gap-5 md:gap-10'>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">City :</span> <span>{data?.ShippingCity}</span></div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">PostalCode :</span> <span>{data?.ShippingPostalcode}</span></div>

            </div>
            <div className="flex items-center gap-2 "><span className="font-semibold text-md ">Phone Number :</span> <span>{data?.ShippingPhone}</span></div>

                

            </div>
        </div>
  )
}
