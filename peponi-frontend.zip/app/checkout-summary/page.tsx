"use client"
import { auth } from "@/lib/firebase/firebase-config";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { onAuthStateChanged } from "firebase/auth";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Cookies from 'js-cookie';
import Summery from "./Summery";
import { stripe } from "@/lib/stripe";
import Payment from "../checkout/Payment";
const CheckoutSummaryPage=()=>{
    const [userEmail, setUserEmail] = useState("");
    const router=useRouter()
    const [key,setKey]=useState<string | null>('')
    const cartNumber = Cookies.get("userId");
    const [data,setData]=useState<any>()
    const orderId = Cookies.get("orderId");
      const [total, setTotal] = useState(0)
        const [grand, setGrand] = useState(0)
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                setUserEmail(user.email || "");
            } else {
                setUserEmail("");
                router.replace('/login')
            }
            // setUserEmail(user ? user.email || "" : "");
        });

        return () => unsubscribe();
    }, []);

    const { isLoading, error, data:datas } = useQuery({
        queryKey: ["carts-checkout", cartNumber, userEmail], // Dependencies
        queryFn: async () => {
            if (!userEmail) return [];

            try {
                const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/cart/get-cart-by-number`, {
                    params: {
                        cartNumber,
                        email: userEmail || null,
                        user: userEmail ? 2 : 1
                    },
                });
                return response.data.data || [];
            } catch (err) {
                // console.error("Error fetching cart details:", err);
                return [];
            }
        },
        enabled:!!userEmail, // Ensures the query only runs if cartNumber exists
    });
     useEffect(() => {
            if (datas && datas.length > 0) {
              
    
                let total = 0;
                let grand = 0;
    
                datas.forEach((item:any) => {
                    total += item.Qty * Number(item.SellingPrice);
                    grand += item.Qty * Number(item.SellingPrice) * (1 + (Number(item.Voucherprice) / 100));
                });
    
                setTotal(total);
                setGrand(grand);
            }
        }, [datas]); 
        useEffect(()=>{
            if(userEmail){
            const fetchData=async()=>{
                
                const res=await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/checkout`,
                    {
                        params:{
                            user:userEmail
                        }
                    }
                );
                if(res.status===200){
                  
                    setData(res.data.data.OrderNumber)
                }
                else{
                    
                    console.log("error")
                }
            }
            fetchData()
        }
          },[userEmail])
    
  // Create PaymentIntent as soon as the page loads
const handleSubmit=()=>{
    console.log('submited')
}
console.log(data)
    const shadow =
    <div className='flex flex-col gap-2 border-[1px] border-black rounded-lg p-4'>
        {[1, 2, 3].map((_, index: any) => <div key={index} className="checkout-wrapper flex gap-4 p-4 border rounded-lg shadow-md animate-pulse">
            {/* Image Placeholder */}
            <div className="bg-gray-300 rounded-md w-[100px] h-[100px]"></div>

            <div className="title-wrapper flex flex-col flex-1 gap-2">
                {/* Product Name Placeholder */}
                <div className="bg-gray-300 h-4 w-3/4 rounded-md"></div>

                {/* Category Name Placeholder */}
                <div className="bg-gray-200 h-3 w-1/2 rounded-md"></div>

                {/* Pricing Placeholder */}
                <div className="flex gap-2 items-center">
                    <div className="bg-gray-200 h-3 w-16 rounded-md"></div>
                    <div className="bg-gray-400 h-4 w-12 rounded-md"></div>
                </div>
            </div>

            <div className="flex flex-col items-end">
                {/* Total Price Placeholder */}
                <div className="bg-gray-400 h-4 w-16 rounded-md"></div>

                {/* Quantity Placeholder */}
                <div className="bg-gray-300 h-3 w-20 rounded-md mt-1"></div>
            </div>
        </div>)}
    </div>
    return (
        <section className="checkout-sec mt-[150px] w-[100%]">
        <div className="container w-[100%]" >
            <h2>Billing Address</h2>

            <div className="lg:flex max-lg:flex max-lg:flex-col gap-5 w-[100%]">
             <Summery/>
                <div className="lg:w-[30%]">
                    {!isLoading ? <div className="checkout-sidebar flex flex-col gap-3">
                        {datas?.map((product: any, index: number) =>
                            <div key={product.ProductID} className="checkout-wrapper ">
                                <img src={`${process.env.NEXT_PUBLIC_API_URL}/${product.Image}`} alt={product.ProductName} width={100} height={100} />
                                <div className="title-wrapper">
                                    <h6>{product.ProductName}</h6>
                                    <p>{product.CategoryName}</p>
                                    <div className="flex gap-2 items-center">
                                        <span className="regular-price text-xs line-through ">${product?.ProductPrice}</span>
                                        <span className="sell-price text-sm font-bold">${product?.SellingPrice}</span>
                                    </div>
                                </div>
                                <div className=" flex flex-col">
                                    {/* <span className="regular-price">${product?.ProductPrice}</span> */}
                                    <span className="sell-price font-bold">${Number(product?.SellingPrice) * product.Qty}</span>
                                    <p className='text-[10px]'>({`${product.Qty} Quantities`}) </p>
                                </div>
                            </div>)}
                        <div className="grand-total">
                            <div className="grand-total-inn">
                                <h6>Grandtotal:</h6>
                                <p>All transactions are secure and encrypted.</p>
                            </div>
                            <span>${total !== 0 && Math.ceil(total)}</span>
                        </div>
                        <div className="final-amount">
                            <p>Final amount (Tax Included)</p>
                            <span>${grand !== 0 && Math.ceil(grand)}</span>
                        </div>
                        <Payment order={data} email={userEmail}/>
                      
                        <a href="#" className="shopping-btn"><i className="fa-solid fa-arrow-left"></i>Continue Shopping</a>
                    </div> : shadow}
                </div>
            </div>
        </div>
       
    </section>
    );
}
export default CheckoutSummaryPage