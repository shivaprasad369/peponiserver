"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import ProductItem from "@/components/cart/ProductItem";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import Cookies from "js-cookie";
import { auth } from "@/lib/firebase/firebase-config";
import { onAuthStateChanged } from "firebase/auth";
import { useRouter } from "next/navigation";
import { CartSkeleton } from "@/components/cart/CartSkeleton";
import { MobileCartSkeleton } from "@/components/cart/MobileCartSkeleton";

export default function Checkout() {
  const queryClient = useQueryClient();
  const router = useRouter();
  const cartNumber = Cookies.get("userId");
  const [userEmail, setUserEmail] = useState("");
  const [showEmptyMessage, setShowEmptyMessage] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUserEmail(user?.email || "");
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!userEmail || !cartNumber) return;

    const updateCartUser = async () => {
      try {
        await axios.put(`${process.env.NEXT_PUBLIC_API_URL}/cart/update-cart-user`, {
           cartNumber,
          email: userEmail,
          user: userEmail ? 2 : 1,
        });

        queryClient.invalidateQueries({ queryKey: ["carts", cartNumber, userEmail] });
      } catch (error) {
        console.log("Error updating cart user:", error);
      }
    };

    updateCartUser();
  }, [userEmail, cartNumber, queryClient]);

  const { isLoading, data: cartItems = [] } = useQuery({
    queryKey: ["carts", cartNumber, userEmail],
    queryFn: async () => {
      try {
        const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/cart/get-cart-by-number`, {
          params: { cartNumber:!userEmail && cartNumber, email: userEmail || null, user: userEmail ? 2 : 1 },
        });

        return response.data.data || [];
      } catch (err) {
        console.log("Error fetching cart details:", err);
        return [];
      }
    },
   
  });

  useEffect(() => {
    if (!isLoading && cartItems.length === 0) {
      const timer = setTimeout(() => {
        setShowEmptyMessage(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isLoading, cartItems]);

  const handleQuantityChange = useCallback((id: number, quantity: number) => {
    queryClient.setQueryData(["carts", cartNumber, userEmail], (oldData: any) =>
      oldData?.map((p: any) => (p.ProductID === id ? { ...p, Qty: quantity } : p))
    );
  }, [cartNumber, userEmail, queryClient]);

  const handleDelete = useCallback((id: number) => {
    queryClient.setQueryData(["carts", cartNumber, userEmail], (oldData: any) =>
      oldData?.filter((p: any) => p.ProductID !== id)
    );
  }, [cartNumber, userEmail, queryClient]);

  const total = useMemo(() => cartItems?.reduce((sum: number, p: any) => sum + p.SellingPrice * p.Qty, 0) || 0, [cartItems]);

  const handleMove = () => {
    router.replace(userEmail ? "/checkout" : "/login");
  };

  return (
    <section className="checkout-sec mt-[160px]">
      <div className="container">
        <h2>Cart</h2>
        <div className="max-lg:flex max-lg:flex-col lg:flex gap-5">
          {/* Desktop View */}
          <div className="product-details lg:w-[70%]">
            {/* Desktop Table */}
            <div className="hidden md:block">
              <table className="table w-full">
                <thead className="md:table-header-group">
                  <tr>
                    <th className="w-[20%]"></th>
                    <th className="w-[20%]">Items</th>
                    <th className="w-[15%]">Amount</th>
                    <th className="w-[15%]">Qty</th>
                    <th className="w-[15%]">Total</th>
                    <th className="w-[15%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <CartSkeleton />
                  ) : cartItems.length > 0 ? (
                    cartItems.map((product: any) => (
                      <ProductItem
                        key={product.ProductID}
                        mode="desktop"
                        {...product}
                        onQuantityChange={(quantity) => handleQuantityChange(product.ProductID, quantity)}
                        onDelete={() => handleDelete(product.ProductID)}
                      />
                    ))
                  ) : showEmptyMessage ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8">
                        <div className="flex flex-col items-center justify-center gap-4">
                          <h3 className="text-xl font-semibold">Your cart is empty</h3>
                          <a href="/products" className="text-[#FFA216] hover:text-[#ff8c00]">
                            Continue Shopping
                          </a>
                        </div>
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>

            {/* Mobile View */}
            <div className="md:hidden">
              {isLoading ? (
                <MobileCartSkeleton />
              ) : cartItems.length > 0 ? (
                cartItems.map((product: any) => (
                  <ProductItem
                    key={product.ProductID}
                    mode="mobile"
                    {...product}
                    onQuantityChange={(quantity) => handleQuantityChange(product.ProductID, quantity)}
                    onDelete={() => handleDelete(product.ProductID)}
                  />
                ))
              ) : showEmptyMessage ? (
                <div className="text-center py-8">
                  <h3 className="text-xl font-semibold">Your cart is empty</h3>
                  <a href="/products" className="text-[#FFA216] hover:text-[#ff8c00]">
                    Continue Shopping
                  </a>
                </div>
              ) : null}
            </div>
          </div>

          {/* Checkout Sidebar */}
          <aside className="relative lg:mt-14">
            <div className="checkout-sidebar sticky top-[100px]">
              <div className="sub-total">
                <div className="grand-total-inn">
                  <h6>Subtotal:</h6>
                  <p>All transactions are secure and encrypted.</p>
                </div>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="final-amount">
                <p>Final amount (Tax Included)</p>
                <span>${total.toFixed(2)}</span>
              </div>
              <button onClick={handleMove} disabled={cartItems.length === 0} className="primary-btn flex items-center justify-center">
                Go To Checkout
              </button>
              <a href="/products" className="shopping-btn text-[#FFA216] hover:text-[#ff8c00]">
                <i className="fa-solid fa-arrow-left"></i> Continue Shopping
              </a>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
