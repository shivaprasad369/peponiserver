'use client';
import { useState } from 'react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '@/lib/firebase/firebase-config';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Poppins } from 'next/font/google';
import toast, { Toaster } from 'react-hot-toast';

const poppins = Poppins({
    weight: ['400', '500', '600', '700'],
    subsets: ['latin'],
});

export default function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    const handleResetPassword = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            await sendPasswordResetEmail(auth, email,);
            toast.success('Password reset link sent! Check your email');
            setTimeout(() => {
            router.push('/login');
            }, 3000);
        } catch (err: any) {
            toast.error(err.message || 'Failed to reset password');
        } finally {
            setLoading(false);
        }
        };

    return (
        <div className={`min-h-screen pt-20 flex items-center justify-center bg-gray-50 ${poppins.className}`}>
            <Toaster position="top-center" />
            <div className="max-w-md w-full space-y-8 p-6 bg-white rounded-xl">
                <div>
                    <h2 className="mt-6 text-center text-2xl font-extrabold text-gray-900">
                        Reset Password
                    </h2>
                    <p className="mt-2 text-center text-sm text-gray-600">
                        Enter your registered email address
                    </p>
                </div>
                <form className="mt-8 space-y-6" onSubmit={handleResetPassword}>
                    <div>
                        <label htmlFor="email" className="sr-only">
                            Email address
                        </label>
                        <input
                            id="email"
                            name="email"
                            type="email"
                            required
                            className="appearance-none rounded-lg relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-black focus:border-gray-500 focus:z-10 sm:text-sm"
                            placeholder="Email address"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div>
                        <button
                            type="submit"
                            disabled={loading}
                            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-s font-regular rounded-md text-black bg-[#FFA216] hover:bg-[#E89214] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#FFA216] disabled:opacity-50"
                        >
                            {loading ? 'Sending...' : 'Reset Password'}
                        </button>
                    </div>

                    <div className="text-center">
                        <Link
                            href="/login"
                            className="font-medium text-[#FFA216] hover:text-[#E89214]"
                        >
                            Back to Login
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    );
}