// jQuery(document).ready(function($) {
// // Hamburger menu toggle functionality
// const clickBtn = document.getElementById('navbar-btn');
// clickBtn.addEventListener('click', myFunction);

// function myFunction() {
//   const headerSec = document.getElementById("header-sec");
//   headerSec.classList.toggle("active");
// }

// // Header submenu toggle functionality
// const menuItems = document.querySelectorAll('.nav-menu > ul > li');
// menuItems.forEach(item => {
//   item.addEventListener('click', () => {
//     item.classList.toggle('active');
//   });
// });

// // Product quantity increase/decrease
// $(document).ready(function() {
//   $('.minus').click(function() {
//     var $input = $(this).parent().find('input');
//         var count = Math.max(parseInt($input.val()) - 1, 1); // Ensure count is at least 1
//         $input.val(count).change();
//         return false;
//       });

//   $('.plus').click(function() {
//     var $input = $(this).parent().find('input');
//     var count = parseInt($input.val()) + 1;
//     $input.val(count).change();
//     return false;
//   });
// });



// // Range input functionality for price range slider
// const rangeInput = document.querySelectorAll(".range-input input"),
// priceInput = document.querySelectorAll(".price-input input"),
// range = document.querySelector(".slider .progress");
// let priceGap = 20;
// priceInput.forEach((input) => {
//   input.addEventListener("input", (e) => {
//     const minPrice = parseInt(priceInput[0].value),
//     maxPrice = parseInt(priceInput[1].value);
//         if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
//           if (e.target.classList.contains("input-min")) {
//             rangeInput[0].value = minPrice;
//             range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
//           } else {
//             rangeInput[1].value = maxPrice;
//             range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
//           }
//         }
//       });
// });
// function RangeSlider(minVal,maxVal,e){
//     if (maxVal - minVal < priceGap) {
//         if (e.target.classList.contains("range-min")) {
//           rangeInput[0].value = maxVal - priceGap;
//         } else {
//           rangeInput[1].value = minVal + priceGap;
//         }
//       } else {
//         priceInput[0].value = minVal;
//         priceInput[1].value = maxVal;
//         range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
//         range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
//       }
// }
// rangeInput.forEach((input) => {
//   input.addEventListener("input", (e) => {
//     const minVal = parseInt(rangeInput[0].value),
//     maxVal = parseInt(rangeInput[1].value);
//         RangeSlider(minVal,maxVal,e);
//       });
// });
//     const minVal = parseInt(rangeInput[0].value),
//     maxVal = parseInt(rangeInput[1].value);
// RangeSlider(minVal,maxVal);




// // Filter sidebar toggle functionality
// const filterBtn = document.getElementById('filter-toggle');
// const filterBar = document.getElementById('filter-sec');
// const body = document.body; 
// if (filterBtn) {
// filterBtn.addEventListener('click', (event) => {
//   body.classList.toggle("open-filterbar");
//   event.stopPropagation();
// });
// body.addEventListener('click', (event) => {
//   if (!filterBar.contains(event.target) && !filterBtn.contains(event.target)) {
//     body.classList.remove('open-filterbar');
//   }
// });
// }
// // Initialize Swiper for image carousel
// var swiper = new Swiper(".mySwiper", {
//   spaceBetween: 20,
//   slidesPerView: "auto",
//   watchSlidesProgress: true,
//   pagination: {
//     el: ".swiper-pagination",
//     clickable: true,
//   },
// });

// var swiper2 = new Swiper(".mySwiper2", {
//   spaceBetween: 20,
//   loop: true,
//   navigation: {
//     nextEl: ".swiper-button-next",
//     prevEl: ".swiper-button-prev",
//   },
//   thumbs: {
//     swiper: swiper,
//   },
//   pagination: {
//     el: ".swiper-pagination",
//     clickable: true,
//   }
// });


// // document.getElementById('search-bar, i').addEventListener('click', function() {
// //     this.classList.add('slide-bottom');
// // });

// const search_btn = document.getElementById('search-btn');
// search_btn.addEventListener('click', myFunction2);

// function myFunction2() {
//   const searchBar = document.getElementsByClassName("search-bar")[0];
//   searchBar.classList.toggle("open");
// }

// });