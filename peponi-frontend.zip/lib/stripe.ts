
import 'server-only';
import Stripe from 'stripe';

export const stripe = new Stripe(`sk_test_51QsVSHQu5uBZTcwUCeOMn1zzJPKgMTVvCYPlM0FTmY1vuttEFNqdAwio4Nr6ZiMrNbG8hjKGCWx9nTTEZSjtWA2500SJ9hthjk`);