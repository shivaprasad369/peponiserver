import img from '@/assets/images/arrow-right.png'
import Image from 'next/image'
import Link from 'next/link'
export default function Gallery() {
    return (
        <>
        <section className="gallery-sec mt-[150px]">
        <div className="container ">
            <div className="gallery-content ">
                <h2>Peponi Gallery</h2>
                <Link href="/products" className="primary-btn  flex justify-center items-center gap-2">See all artworks
                    <Image  src={img} alt="arrow-right"/></Link>
            </div>
        </div>
    </section>
    <section className="making-art-sec">
        <div className="container">
            <h2>Making Art Accessible to Everyone</h2>
            <p>Founded in 2013 by passionate entrepreneurs Hugo Mulliez and François-Xavier Trancart, Peponi Gallery is a revolutionary art marketplace. Their vision was born from a simple observation: while art enthusiasts are growing in number and curiosity, the traditional art world remains bound by outdated principles.</p>
            <p>With state-of-the-art technology and personalized recommendations, Peponi Gallery enables anyone to discover art that aligns with their unique taste and budget. In just a few clicks, you can explore collections from 1,800 prestigious professional galleries worldwide, including renowned names like Perrotin, Templon, and Lelong.</p>
        </div>
    </section>
    </>
    )
}