export default function Second() {
    return (
        <>
        <section className="our-code-sec">
    </section>
    <section className="our-code-content">
        <h3>Discover Our Code of Ethics</h3>
        <p>At Peponi Gallery, we are committed to transparency, quality, and customer satisfaction. Contact our dedicated art consultants today to find your next masterpiece!</p>
    </section>
    <section className="our-promise-sec">
            <div className="container">
            <h2>Our Promise</h2>
            <div className="flex flex-wrap -mx-4">
                <div className="w-full lg:w-4/12 md:w-6/12 px-4 mb-6">
                    <div className="two-btn">
                        <a href="#" className="active">Get in touch</a>
                        <a href="#">Enter your phone number</a>
                    </div>
                </div>
                <div className="w-full lg:w-3/12 md:w-6/12 px-4 mb-6">
                    <h5>Expert Curation</h5>
                    <p>Artworks are authenticated by partner galleries and expert committees.</p>
                </div>
                <div className="w-full lg:w-3/12 md:w-6/12 px-4 mb-6">
                    <h5>Secure Shopping</h5>
                    <p>Secure payments and free 14-day returns with a full refund guarantee</p>
                </div>
                <div className="w-full lg:w-2/12 md:w-6/12 px-4 mb-6">
                    <h5>Resale Options</h5>
                    <p>Resell purchased art in excellent condition anytime</p>
                </div>
            </div>
        </div>
    </section>
        </>
    )
}