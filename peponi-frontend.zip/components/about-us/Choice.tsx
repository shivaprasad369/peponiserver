import img from '@/assets/images/young-man.png'
import Image from 'next/image'

export default function Choice() {
    return (
        <section className="art-choice-sec">
            <div className="container">
                <div className="flex flex-col md:flex-row gap-8">
                    <div className="w-full md:w-1/2">
                        <Image src={img} alt="young-man"/>
                    </div>
                    <div className="w-full md:w-1/2 my-auto"> 
                        <div className="choice-content max-h-[500px] text-sm">
                            <h2>The Art of Choice</h2>
                            <h3>A Vast Collection:</h3>
                            <p>Discover the largest catalog of contemporary art with over 200,000 works. From globally celebrated artists like Banksy, Andy Warhol, and Niki de Saint Phalle to emerging creative talents, there’s something for everyone.</p>
                            <h3>Art for Every Budget:</h3>
                            <p>With prices starting at just €100, our artworks cater to every financial plan. Whether you're buying a spontaneous gift, making a thoughtful investment, or simply indulging in your love for art, our experts will help you find the perfect piece.</p>
                            <h3>All Styles and Mediums:</h3>
                            <p>Browse a diverse range of categories, including painting, sculpture, photography, prints, drawings, and design. No matter your preference—be it minimalism, abstract art, or street art—Peponi Gallery offers styles to suit every taste.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
