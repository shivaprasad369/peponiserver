import img from '@/assets/images/evening-new.png'
import Image from 'next/image'

export default function Choose() {
    return (
        <section className="choose-sec">
            <div className="container">
                <div className="flex flex-col lg:flex-row">
                    <div className="lg:w-5/12">
                        <h2>Why Choose Peponi Gallery?</h2>
                        <span>Trusted by Art Professionals and Collectors</span>
                    </div>
                    <div className="lg:w-7/12">
                        <Image src={img} alt="evening-new"/>
                    </div>
                </div>
                <div className="peponi-feature mr-1">
                    <div className="feature-text">
                        <div className="feature-text-inn">
                            <h5>1,800</h5>
                            <span> Partner Galleries</span>
                        </div>
                        <p>Collaborating with top galleries from Paris, New York, Seoul, and beyond.</p>
                    </div>
                    <div className="feature-text">
                        <div className="feature-text-inn">
                            <h5>1 Million</h5>
                            <span>Visitors Each Month</span>
                        </div>
                        <p>Inspiring art lovers and collectors worldwide.</p>
                    </div>
                    <div className="feature-text">
                        <div className="feature-text-inn">
                            <h5>25,000</h5>
                            <span>Artists</span>
                        </div>
                        <p>Featuring iconic creators and fresh new talent.</p>
                    </div>
                </div>
            </div>
        </section>
    )
}