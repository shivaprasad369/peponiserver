export default function Banner() {
    return (
        <section className="banner-contact-sec mt-[150px]">
            <div className="container mx-auto px-4 max-w-7xl">
                <div className="flex flex-wrap -mx-4">
                    <div className="w-full md:w-1/2 lg:w-7/12 px-4">
                        <div className="contact-form">
                            <h2>Contact Us</h2>
                            <form action="">
                                <div className="form-group">
                                    <label form="name">Enter Full Name</label>
                                    <input type="email" id="name" placeholder="Enter Your Full Name*"/>
                                </div>
                                <div className="form-group">
                                    <label form="email">Enter Email Address</label>
                                    <input type="email" id="name" placeholder="Enter Your Email Address*"/>
                                </div>
                                <div className="form-group">
                                    <label form="name">Enter Full Name</label>
                                    <textarea placeholder="Enter Your Message *"></textarea>
                                </div>
                                <button className="submit-btn">Send</button>
                            </form>
                        </div>
                    </div>
                    <div className="w-full md:w-1/2 lg:w-5/12 px-4 my-auto">
                        <div className="form-content">
                            <ul>
                                <li>
                                    <h5>Peponi gallery Store</h5>
                                    <p>Discover our curated selection of artworks in person. [Gallery Address]</p>
                                </li>
                                <li>
                                    <h5>Call us:</h5>
                                    <a href="tel:0256 026 6552">+81 0256 026 6552</a>
                                </li>
                                <li>
                                    <h5>Peponi gallery Store</h5>
                                    <a href="mailto:peponigallery@gmail.com">peponigallery@gmail.com</a>
                                </li>
                            </ul>
                            <span>Thank You for Visiting Our Website!</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}