"use client"
import { useEffect, useState } from "react"
import axios from "axios"
import { useQueryClient } from "@tanstack/react-query"
import Cookies from "js-cookie";
import toast from "react-hot-toast"
import { onAuthStateChanged } from "firebase/auth"
import { auth } from "@/lib/firebase/firebase-config"
import { Trash } from "lucide-react";
interface ProductItemProps {
 
  ProductName: string
  type: string
  size: string
  regularPrice: number,
  ProductID:number,
  Image:string,
  SellingPrice: number,
  ProductAttributeID:number,
  CategoryName:string,
  ProductPrice:number,
  TempCartID:number,
  Stock:number,
  FinalCartID:number,
  ItemTotal:number,
  Qty:number,
  mode?: "desktop" | "mobile";
  onQuantityChange: (quantity: number) => void
  onDelete: () => void
}

// Split into Desktop and Mobile components
function DesktopView({ 
  ProductName, Image, CategoryName, Stock, ProductPrice, SellingPrice, 
  quantity, FinalCartID, TempCartID, userEmail, handleDelete, handleUpdateQuantity 
}: any) {
  return (
    <tr className="hidden md:table-row">
      <td>
        <div className="user-img">
          <img src={`${process.env.NEXT_PUBLIC_API_URL}/${Image}`} alt={ProductName} width={100} height={100} />
        </div>
      </td>
      <td>
        <div className="product-content font-medium">
          <h2>{ProductName}</h2>
          <span>{CategoryName}</span>
          <p className={`text-xl ${Stock > 9 ? 'text-gray-900' : 'text-red-500'} font-medium`}>
            {Stock > 9 ? 'In Stock' : `Only ${Stock} items left`}
          </p>
          <div className="price-wrapper">
            <span className="regular-price">${ProductPrice}</span>
            <span className="sell-price">${SellingPrice}</span>
          </div>
        </div>
      </td>
      <td>
        <p>${Number(SellingPrice) * quantity}</p>
      </td>
      <td>
        <div className="number-count">
          <button className="minus" disabled={quantity===1} 
            onClick={() => handleUpdateQuantity(userEmail ? FinalCartID: TempCartID,"decrement")}>
            -
          </button>
          <input type="text" value={quantity} readOnly />
          <button className="plus" disabled={quantity===Stock} 
            onClick={() => handleUpdateQuantity(userEmail ? FinalCartID: TempCartID,'increment')}>
            +
          </button>
        </div>
      </td>
      <td>
        <p>${Number(SellingPrice) * quantity}</p>
      </td>
      <td>
        <button className="delete-img" onClick={() => handleDelete(userEmail ? FinalCartID: TempCartID)}>
          <span>Delete</span>
        </button>
      </td>
    </tr>
  );
}

function MobileView({
  ProductName, Image, CategoryName, Stock, ProductPrice, SellingPrice,
  quantity, FinalCartID, TempCartID, userEmail, handleDelete, handleUpdateQuantity
}: any) {
  return (
    <div className="md:hidden relative w-full bg-white rounded-lg shadow-sm p-4 mt-4 border border-black mx-auto">
      {/* Delete Icon on Top Right */}
      <div className="absolute top-2 right-2">
        <Trash
          color="gray"
          size={20}
          className="cursor-pointer"
          onClick={() =>
            handleDelete(userEmail ? FinalCartID : TempCartID)
          }
        />
      </div>
      {/* Header - Product Info */}
      <div className="flex gap-4 mb-4">
        {/* Image */}
        <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
          <img
            src={`${process.env.NEXT_PUBLIC_API_URL}/${Image}`}
            alt={ProductName}
            className="w-full h-full object-cover"
          />
        </div>
        {/* Product Details */}
        <div className="flex flex-col flex-1">
          <h2 className="font-semi text-gray-900 text-xl mb-1">
            {ProductName}
          </h2>
          <span className="text-sm text-gray-500 mb-1">{CategoryName}</span>
          {/* Price Section */}
          <div className="flex items-center gap-2 mt-auto">
            <span className="text-gray-400 line-through text-sm">
              ${ProductPrice}
            </span>
            <span className="text-primary font-semibold">
              ${SellingPrice}
            </span>
          </div>
        </div>
      </div>
      {/* Stock Info */}
      <div className="mb-4">
        <p
          className={`text-sm  ${
            Stock > 9 ? "text-green-600" : "text-red-500"
          }`}
        >
          {Stock > 9 ? "In Stock" : `Only ${Stock} items left`}
        </p>
      </div>
      {/* Updated Quantity Controls to match desktop */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-font-medium text-gray-900">Quantity:</span>
        <div className="number-count">
          <button 
            className="minus" 
            disabled={quantity===1} 
            onClick={() => handleUpdateQuantity(userEmail ? FinalCartID: TempCartID,"decrement")}
          >
            -
          </button>
          <input type="text" value={quantity} readOnly />
          <button 
            className="plus" 
            disabled={quantity===Stock} 
            onClick={() => handleUpdateQuantity(userEmail ? FinalCartID: TempCartID,'increment')}
          >
            +
          </button>
        </div>
      </div>
      {/* Total - label LHS and price RHS */}
      <div className="flex justify-between">
        <span className="text font-medium text-gray-900">Total:</span>
        <span className="font-semibold text-gray-900">
          ${(Number(SellingPrice) * quantity).toFixed(2)}
        </span>
      </div>
    </div>
  );
}

export default function ProductItem({
  ProductName,
  type,
  size,
  Image,
  ProductID,
  FinalCartID,
  ProductAttributeID,
  regularPrice,
  TempCartID,
  CategoryName,
  Stock,
  Qty,
  ItemTotal,
  SellingPrice,
  ProductPrice,
  mode = "desktop",
  onQuantityChange,
  onDelete,
}: ProductItemProps) {
  const [quantity, setQuantity] = useState(Qty)
  const queryClient = useQueryClient();
  const [userEmail, setUserEmail] = useState("");  
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUserEmail(user ? user.email || "" : "");
    });

    return () => unsubscribe();
  }, []);
  const handleDelete = async (tempID:number ) => {
   
    try {
      const url = `${process.env.NEXT_PUBLIC_API_URL}/cart/delete-cart-item`;
  
      const res = await axios.delete(
        url,{
          params:{
            id:tempID,
            email: userEmail!==''? userEmail : null,
           
          }
        }
      );
  
      if (res.status === 200) {
        queryClient.invalidateQueries({queryKey:["carts"]});
        queryClient.invalidateQueries({queryKey:["Qty"]});
        toast.success("Item deleted");
      } else {
        toast.error("Failed to delete the item");
      }
    } catch (error) {
      console.error("Error deleting the cart item:", error);
      toast.error("An error occurred while deleting the item");
    }
  };
  
  const handleUpdateQuantity = async ( TempCartID:number,action:string) => {
    try {
      const response = await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/cart/update-quantity`,
        {
          id: ProductAttributeID,
          userId: TempCartID,
          email:userEmail!=='' ? userEmail : null,
          number: { action: action, qty: 1 },
        }
      );
      queryClient.invalidateQueries({ queryKey: ["carts"] });

      if (response.status === 200) {
        // toast.success("Updated Successfully")
        action === "increment"
        ? setQuantity((pre)=>pre+1)
        : setQuantity((pre)=>pre-1)
      }
    } catch (error) {
      console.error("Failed to update quantity:");
    }
  };

  const commonProps = {
    ProductName,
    type,
    size,
    Image,
    ProductID,
    FinalCartID,
    ProductAttributeID,
    regularPrice,
    TempCartID,
    CategoryName,
    Stock,
    Qty,
    ItemTotal,
    SellingPrice,
    ProductPrice,
    mode,
    onQuantityChange,
    onDelete,
    quantity,
    userEmail,
    handleDelete,
    handleUpdateQuantity
  };

  if (mode === "desktop") {
    return <DesktopView {...commonProps} />;
  }
  return <MobileView {...commonProps} />;
}

