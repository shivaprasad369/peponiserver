export function CartSkeleton() {
  return (
    <tr className="animate-pulse h-[180px]">
      <td>
        <div className="user-img">
          <div className="bg-gray-200 w-[120px] h-[120px] rounded"></div>
        </div>
      </td>
      <td>
        <div className="flex flex-col gap-2">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          <div className="h-3 bg-gray-200 rounded w-1/3"></div>
          <div className="flex gap-2">
            <div className="h-3 bg-gray-200 rounded w-16"></div>
            <div className="h-3 bg-gray-200 rounded w-16"></div>
          </div>
        </div>
      </td>
      <td>
        <div className="h-4 bg-gray-200 rounded w-16"></div>
      </td>
      <td>
        <div className="flex items-center gap-2">
          <div className="h-8 bg-gray-200 rounded w-8"></div>
          <div className="h-8 bg-gray-200 rounded w-12"></div>
          <div className="h-8 bg-gray-200 rounded w-8"></div>
        </div>
      </td>
      <td>
        <div className="h-4 bg-gray-200 rounded w-16"></div>
      </td>
      <td>
        <div className="h-8 bg-gray-200 rounded w-20"></div>
      </td>
    </tr>
  );
}
