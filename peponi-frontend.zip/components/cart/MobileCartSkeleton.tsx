"use client"
export function MobileCartSkeleton() {
  return (
    <div className="w-full bg-white rounded-lg shadow-sm p-4 mb-4 border border-gray-200 animate-pulse space-y-4">
      {/* Image placeholder */}
      <div className="w-24 h-24 bg-gray-200 rounded"></div>
      {/* Title and details */}
      <div className="space-y-2">
        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      </div>
      {/* Quantity Controls */}
      <div className="flex justify-between items-center">
        <div className="h-4 bg-gray-200 rounded w-1/3"></div>
        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
      </div>
      {/* Total */}
      <div className="flex justify-between">
        <div className="h-4 bg-gray-200 rounded w-1/3"></div>
        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
      </div>
    </div>
  );
}
