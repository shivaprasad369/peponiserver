"use client"

import { useState } from "react"

export default function CheckoutForm() {
  const [sameAsBilling, setSameAsBilling] = useState(false)

  return (
    <div className="contact-form checkout-form">
      <form>
        <div className="row">
          <div className="col-lg-6">
            <div className="form-group">
              <input type="text" id="firstName" placeholder="Enter Your First Name*" required />
            </div>
          </div>
          <div className="col-lg-6">
            <div className="form-group">
              <input type="text" id="lastName" placeholder="Enter Your Last Name*" required />
            </div>
          </div>
          <div className="col-lg-12">
            <div className="form-group">
              <textarea placeholder="Enter Your Address*" required></textarea>
            </div>
          </div>
          {/* Add more form fields here */}
          <div className="billing-address">
            <input
              type="checkbox"
              id="sameAsBilling"
              checked={sameAsBilling}
              onChange={(e) => setSameAsBilling(e.target.checked)}
            />
            <label htmlFor="sameAsBilling">Shipping address same as billing address</label>
          </div>
          {!sameAsBilling && <>{/* Add shipping address fields here */}</>}
        </div>
      </form>
    </div>
  )
}

