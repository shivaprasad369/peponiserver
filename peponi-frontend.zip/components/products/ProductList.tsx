"use client"

import { useEffect, useState } from "react"
import ProductSkeleton from "@components/products/ProductSkeleton";
import Link from "next/link";

export default function ProductList({ initialProducts,isLoading }: { initialProducts: any[]; isLoading:boolean }) {
  const [products, setProducts] = useState(initialProducts)
 useEffect(()=>
    setProducts(initialProducts),[initialProducts])
 if(isLoading){
    return <ProductSkeleton/> 
 }
  return (
    <div className="flex flex-wrap -mx-4">
      <div className="w-full px-4">
        <div className="flex flex-wrap -mx-4">
      { !isLoading && products.length>0?products.map((product) => (
            <div key={product.ProductID} className="w-full md:w-1/2 lg:w-1/3 px-4 mb-8">
              <Link  href={`/details/${product?.url}`}>
              <div className="card-box">
               
                  <img src={`${process.env.NEXT_PUBLIC_API_URL}/${product.Image}`} alt={product.ProductName} />
             
                <div className="card-content">
                  <p>Le flaneur</p>
                  <h6>
                    <span>{product.ProductName}</span>
                  </h6>
                  {/* <p className="size">
                    {product.attributeValues[0]?.AttributeName} - {product.attributeValues[0]?.attributeValue}
                  </p> */}
                  <div className="price-wrapper">
                    <span className="regular-price">${product.ProductPrice}</span>
                    <span className="sell-price">${product.CashPrice}</span>
                  </div>
                </div>
              </div>
              </Link>
            </div>
          )):<p className="text-xl text-center items-center justify-center w-[100%] flex h-[100%]">No Product Found</p>}
        </div>
      </div>
    </div>
  )
}

