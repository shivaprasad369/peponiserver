import axios from 'axios'
import React, { useEffect, useState } from 'react'

export default function GetPrice({ setPriceRange }:{
    setPriceRange: (range: [number, number]) => void,
}) {
    const [maxPrice, setMaxPrice] = useState(0)
    const [minPrice, setMinPrice] = useState(0)

    useEffect(() => {
        const getMaxMinPrice = async () => {
            try {
                const res = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/category-products/price`)

                if (res.status === 200 && res.data.length > 0) {
                    const max = Number(res.data[0].maxPrice)
                    const min = Number(res.data[0].minPrice)

                    setMaxPrice(max)
                    setMinPrice(min)
                    setPriceRange([min, max])  // Set price range properly
                }
            } catch (error) {
                console.error("Error fetching price range:", error)
            }
        }

        getMaxMinPrice()
    }, [setPriceRange]) // Runs on mount

    return (
        <>
        </>
    )
}
