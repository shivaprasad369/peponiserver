"use client"

import { useEffect, useState, useCallback, Suspense } from "react"
import axios from "axios"
import { ChevronDown, ChevronUp, SlidersHorizontal, X } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import ProductSkeleton from "@/components/products/ProductSkeleton"
import ProductList from "@/components/products/ProductList"
import { useQuery } from "@tanstack/react-query"
import { debounce } from "lodash";

const fetchProducts = async ({ queryKey }:any) => {
  const [, { selectedCategories, selectedSubcategories, selectedAttribute, priceRange, sort }] = queryKey;
  const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/category-products/search`, {
    categories: selectedCategories,
    subcategories: selectedSubcategories,
    attributes: selectedAttribute,
    priceRange: priceRange,
    sortField: sort.field,
    sortOrder: sort.action,
  });
  return response.data;
};


interface FilterSection {
  id: string
  title: string
  isOpen: boolean
}

interface ProductFilterProps {
  allAttributes: Record<string, string[]>
  categoriesData: any[]
  initialProducts: any[]
  fieldName: string
  action: string
  attr:any[]
}

export default function ProductFilter({
  allAttributes,
  categoriesData,
  initialProducts,
  fieldName,
  action,
  attr,
}: ProductFilterProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [priceRange, setPriceRange] = useState<number[]>([
    initialProducts[0]?.overallMinCashPrice ?? 0,
    initialProducts[0]?.overallMaxCashPrice ?? 1000,
  ])
  const [price,setPrice]=useState([0,1000])
  const [expandedSections, setExpandedSections] = useState<FilterSection[]>([])
  const [selectedCategories, setSelectedCategories] = useState<number[]>([])
  const [selectedSubcategories, setSelectedSubcategories] = useState<Record<number, number[]>>({})
  const [selectedAttribute, setSelectedAttribute] = useState<Record<string, string[]>>({})
  const [filteredAttributes, setFilteredAttributes] = useState<Record<string, string[]>>({})
  const [sort, setSort] = useState({
    field: "CashPrice",
    action: "asc",
  })
  const [debouncedFilters, setDebouncedFilters] = useState({
    selectedCategories: selectedCategories.map(String), // Ensure correct type
    selectedSubcategories: Object.fromEntries(
      Object.entries(selectedSubcategories).map(([key, value]) => [String(key), value.map(String)])
    ),
    selectedAttribute,
    priceRange: [price[0], price[1]] as [number, number], // Ensure it's a tuple
    sort,
  });
  const debouncedUpdate = useCallback(
    debounce((filters: any) => {
      setDebouncedFilters(filters);
    }, 300),
    []
  );
  useEffect(() => {
    debouncedUpdate({ selectedCategories, selectedSubcategories, selectedAttribute, priceRange, sort });
    return () => debouncedUpdate.cancel();
  }, [selectedCategories, selectedSubcategories, selectedAttribute, priceRange, sort, debouncedUpdate]);

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ["search",debouncedFilters],
    queryFn: fetchProducts,
    enabled: !!debouncedFilters.selectedCategories.length || !!debouncedFilters.selectedSubcategories, // Avoid unnecessary requests
  });
  const toggleSection = (sectionId: string) => {
    setExpandedSections((sections) =>
      sections.map((section) => (section.id === sectionId ? { ...section, isOpen: !section.isOpen } : section)),
    )
  }

  useEffect(() => {
    if (allAttributes && typeof allAttributes === "object") {
      setFilteredAttributes(allAttributes)
    } else {
      console.log("allAttributes is not an object or is undefined")
    }
  }, [allAttributes])

  useEffect(() => {
    const initialSections: FilterSection[] = [
      { id: "categories", title: "Categories", isOpen: true },
      { id: "subcategories", title: "Subcategories", isOpen: true },
    ]
    if (attr) {
     attr.forEach((attr) => {
        initialSections.push({
          id: attr.attributeName,
          title: attr.attributeName,
          isOpen: false,
        })
      })
    }
   
    setExpandedSections(initialSections)
  }, [categoriesData, attr])


  const handleCategoryChange = (categoryId: number) => {
    setSelectedCategories((prevCategories) => {
      if (prevCategories.includes(categoryId)) {
        setSelectedSubcategories((prevSubcategories) => {
          const updatedSubcategories = { ...prevSubcategories }
          delete updatedSubcategories[categoryId]
          return updatedSubcategories
        })
        return prevCategories.filter((id) => id !== categoryId)
      } else {
        return [...prevCategories, categoryId]
      }
    })
  }

  const handleSubcategoryChange = (categoryId: number, subcategoryId: number) => {
    setSelectedSubcategories((prevSubcategories) => {
      const updatedSubcategories = { ...prevSubcategories };
      if (!updatedSubcategories[categoryId]) {
        updatedSubcategories[categoryId] = [];
      }
      const index = updatedSubcategories[categoryId].indexOf(subcategoryId);
      if (index === -1) {
        updatedSubcategories[categoryId] = [...updatedSubcategories[categoryId], subcategoryId];
      } else {
        updatedSubcategories[categoryId] = updatedSubcategories[categoryId].filter((id) => id !== subcategoryId);
      }
      if (updatedSubcategories[categoryId].length === 0) {
        delete updatedSubcategories[categoryId];
      }
      return updatedSubcategories;
    });
  };
  const handleAttributeChange = (attributeName: string, value: string) => {
    setSelectedAttribute((prevAttributes) => {
      const updatedAttributes = { ...prevAttributes }
      if (!updatedAttributes[attributeName]) {
        updatedAttributes[attributeName] = []
      }
      const index = updatedAttributes[attributeName].indexOf(value)
      if (index === -1) {
        updatedAttributes[attributeName] = [...updatedAttributes[attributeName], value]
      } else {
        updatedAttributes[attributeName] = updatedAttributes[attributeName].filter((v) => v !== value)
      }
      if (updatedAttributes[attributeName].length === 0) {
        delete updatedAttributes[attributeName]
      }
      return updatedAttributes
    })
  }
  

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  const handleSort = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value
    const newFieldName =
      value === "high" || value === "low" ? "CashPrice" : value === "old" || value === "new" ? "CreatedDate" : value
    const newAction = value === "high" || value === "old" ? "desc" : value === "low" || value === "new" ? "asc" : "desc"
    setSort({ field: newFieldName, action: newAction })
  }
  useEffect(() => {
    if (selectedCategories.length > 0) {
      const allFilteredAttributes: Record<string, Set<string>> = {}
      selectedCategories.forEach((categoryId) => {
        const category = categoriesData.find((category) => category.CategoryID === categoryId)
        if (category) {
          category.Subcategories.forEach((subcategory: any) => {
            if (selectedSubcategories[categoryId]?.includes(subcategory.SubcategoryID)) {
              subcategory.Attributes.forEach((attribute: any) => {
                if (!allFilteredAttributes[attribute.AttributeName]) {
                  allFilteredAttributes[attribute.AttributeName] = new Set()
                }

                attribute.AttributeValues.forEach((value: any) => {
                  const normalizedValue = value.Value.trim().toLowerCase()
                  allFilteredAttributes[attribute.AttributeName].add(normalizedValue)
                })
              })
            }
          })
        }
      })
      const uniqueAttributes = Object.keys(allFilteredAttributes).reduce((acc: any, attributeName: string) => {
        acc[attributeName] = Array.from(allFilteredAttributes[attributeName])
        return acc
      }, {})
      setFilteredAttributes(uniqueAttributes)
    } else {
      setFilteredAttributes({})
    }
  }, [selectedCategories, selectedSubcategories, categoriesData])
  return (
    <div className="relative pb-16 lg:pb-0"> {/* Add padding bottom for mobile */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-semibold">Products</h3>
        {/* Hide on mobile, show on desktop */}
        <div className="hidden lg:flex items-center gap-3">
          <h6 className="text-sm font-medium">Sort By:</h6>
          <select onChange={handleSort} className="border rounded-md py-1 px-3">
            <option value="price">Price</option>
            <option value="high">High to Low</option>
            <option value="low">Low to High</option>
            <option value="old">Old to New</option>
            <option value="new">New to Old</option>
          </select>
        </div>
      </div>

      {/* Rest of the existing layout */}
      <div className="lg:grid lg:grid-cols-[300px_1fr] gap-8">
        <div className="lg:hidden">
          {/* <GetPrice setPriceRange={setPri</div>ceRange}/> */}
            <Button variant="outline" className="hidden lg:flex items-center gap-2" onClick={() => setIsOpen(true)}>
            <SlidersHorizontal className="h-4 w-4" />
            Filters
            </Button>
        </div>
        <div
          className={`fixed inset-0 max-lg:overflow-y-scroll lg:z-10 z-50 lg:h-fit lg:p-3 lg:border-[1px] border-[#252525] lg:rounded-lg lg:relative lg:block ${
            isOpen ? "block" : "hidden"
          }`}
        >
          <div className="fixed inset-0 bg-black/30 lg:hidden" onClick={() => setIsOpen(false)} />
          <div
            className={`fixed left-0 bg-white h-full max-lg:w-[300px] p-6 shadow-lg lg:static lg:p-0 lg:shadow-none ${
              isOpen ? "translate-x-0" : "translate-x-full"
            } transition-transform lg:translate-x-0 max-lg:overflow-y-auto`}
          >
            <div className="flex items-center justify-between lg:hidden">
              <h2 className="text-lg font-semibold">Filters</h2>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-4 space-y-6 sticky top-[300px]">
              <div className=" sticky top-[100px]w-[100%] border-b-[1px] border-[#ffeb3b] lg:flex hidden items-center justify-between">
                <h3 className="mb-2 font-medium">Filters</h3>
                <div   onClick={() => {
                  window.location.reload();
                  }} className="flex items-center font-medium px-3 text-gray-500  cursor-pointer border-gray-200">
                  Clear All
                </div>
              </div>
              <div>
                <h6 className="mb-4 text-md">Price</h6>
                <div className="space-y-4 border-b-[1px] border-[#ffeb3b] pb-3">
                  <Slider
                    max={1000}
                    step={10}
                    value={priceRange}
                    onValueChange={setPriceRange}
                  />
                  <div className="flex justify-between text-sm">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>
              </div>
              <div className="border-b-[1px] pb-2 border-[#ffeb3b]">
                <button
                  className="flex w-full items-center justify-between py-2"
                  onClick={() => toggleSection("categories")}
                >
                  <span className="font-medium">Categories</span>
                  {expandedSections.find((sec) => sec.id === "categories")?.isOpen ? (
                    <ChevronUp className="h-4 w-4 font-bold text-[#cc9e3a]" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
                {expandedSections.find((sec) => sec.id === "categories")?.isOpen && (
                  <div className="mt-2 space-y-2">
                    {categoriesData.map((category) => (
                      <label key={category.CategoryID} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          className="rounded"
                          checked={selectedCategories.includes(category.CategoryID)}
                          onChange={() => handleCategoryChange(category.CategoryID)}
                        />
                        {category.CategoryName}
                      </label>
                    ))}
                  </div>
                )}
              </div>
              {selectedCategories.length > 0 && (
                <div className="border-b-[1px] pb-2 border-[#ffeb3b]">
                  <button
                    className="flex w-full items-center justify-between py-2"
                    onClick={() => toggleSection("subcategories")}
                  >
                    <span className="font-medium">Subcategories</span>
                    {expandedSections.find((sec) => sec.id === "subcategories")?.isOpen ? (
                      <ChevronUp className="h-4 w-4 font-bold text-[#cc9e3a]" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </button>
                  {expandedSections.find((sec) => sec.id === "subcategories")?.isOpen && (
                    <div className="mt-2 space-y-4">
                      {selectedCategories.map((categoryId) => {
                        const category = categoriesData.find((cat) => cat.CategoryID === categoryId)
                        return (
                          <div key={categoryId}>
                            <div className="space-y-2 ml-0">
                              {category?.Subcategories.map((subcategory: any) => (
                                <label key={subcategory.SubcategoryID} className="flex items-center gap-2">
                                  <input
                                    type="checkbox"
                                    className="rounded"
                                    checked={
                                      selectedSubcategories[categoryId]?.includes(subcategory.SubcategoryID) || false
                                    }
                                    onChange={() => handleSubcategoryChange(categoryId, subcategory.SubcategoryID)}
                                  />
                                  {subcategory.SubcategoryName}
                                </label>
                              ))}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )}
              {attr.map((att) => (
                  <div key={att.attributeName} className="border-b-[1px] pb-2 border-[#ffeb3b]">
                    <button
                      className="flex w-full items-center justify-between py-2"
                      onClick={() => toggleSection(att.attributeName)}
                    >
                      <span className="font-medium">
                        {att.attributeName !== "" ? att.attributeName : "Attribute not present"}
                      </span>
                      {expandedSections.find((sec) => sec.id === att.attributeName)?.isOpen ? (
                        <ChevronUp className="h-4 w-4 font-bold text-[#cc9e3a]" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </button>
                    {expandedSections.find((sec) => sec.id === att.attributeName)?.isOpen && (
                      <div className="mt-2 space-y-2">
                        {att.values?.map((value: any, index: any) => (
                          <label key={index} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="rounded"
                              checked={selectedAttribute[att.attributeName]?.includes(value.value) || false}
                              onChange={() => handleAttributeChange(att.attributeName, value.value)}
                            />
                            {value.value}
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                ))
              }
            </div>
          </div>
        </div>
          <Suspense fallback={<ProductSkeleton />}>
            {isLoading? <ProductSkeleton/>:<ProductList isLoading={isLoading}
             initialProducts={searchResults&& searchResults} />}
          </Suspense>
      </div>

      {/* Mobile Bottom Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-4px_6px_-1px_rgb(0,0,0,0.1)] px-4 py-3 z-50">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <Button 
            variant="ghost" 
            className="flex-1 flex items-center justify-center gap-2 hover:bg-transparent focus:bg-transparent" 
            onClick={() => setIsOpen(true)}
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </Button>
          <div className="w-[1px] h-8 bg-gray-200"></div>
          <div className="flex-1">
            <select 
              onChange={handleSort} 
              className="w-full py-2 px-3 bg-transparent text-center border-none focus:ring-0 text-sm appearance-none"
            >
              <option value="price">Sort</option>
              <option value="high">High to Low</option>
              <option value="low">Low to High</option>
              <option value="old">Old to New</option>
              <option value="new">New to Old</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  )
}