"use client"

import { useState } from "react"

export default function SortDropdown() {
  const handleSort = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSort(e.target.value)
    if(sort==='high'){

      localStorage.setItem('sort','price-desc')
      localStorage.setItem('action','desc')
    }
    if(sort==='low'){

      localStorage.setItem('sort','price-asc')
      localStorage.setItem('action','asc')
    }
    if(sort==='old'){
      localStorage.setItem('sort','create-desc')
      localStorage.setItem('action','desc')
    }
    if(sort==='new'){
      localStorage.setItem('sort','create-asc')
      localStorage.setItem('action','asc')
    }
  }

 const [sort,setSort]=useState<string>('')
  return (
    <div className="flex items-center gap-3">
      <h6 className="text-sm font-medium">Sort By:</h6>
      <select onChange={handleSort} className="border rounded-md py-1 px-3">
        <option value="price">Price</option>
        <option value="high">High to Low</option>
        <option value="low">Low to High</option>
        <option value="old">Old to New</option>
        <option value="new">New to Old</option>
      </select>
    </div>
  )
}

