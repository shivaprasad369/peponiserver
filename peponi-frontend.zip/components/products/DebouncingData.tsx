"use client"

import axios from "axios"
import { useCallback, useState } from "react"

// Debounce function with proper typing
function debounce<T extends (...args: any[]) => void>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null
  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

interface DebouncingDataProps {
  selectedCategories: number[]
  selectedSubcategories: Record<number, number[]>
  selectedAttribute: Record<string, string[]>
  priceRange: [number, number]
  sort: { field: string; action: string }
}

export default function DebouncingData({
  selectedCategories,
  selectedSubcategories,
  selectedAttribute,
  priceRange,
  sort,
}: DebouncingDataProps) {
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(false)

  // Debounced search function with proper typing
  const debouncedSearch = useCallback(
    debounce(
      async (
        categories: number[],
        subcategories: Record<number, number[]>,
        attributes: Record<string, string[]>,
        price: [number, number],
        sortOptions: { field: string; action: string },
      ) => {
        setIsLoading(true)
        try {
          const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/category-products/search`, {
            categories,
            subcategories,
            attributes,
            priceRange: price,
            sortField: sortOptions.field,
            sortOrder: sortOptions.action,
          })
          setSearchResults(response.data)
        } catch (error) {
          console.log("Failed to fetch search results:", error)
        } finally {
          setIsLoading(false)
        }
      },
      500,
    ),
    [],
  )

  return {
    searchResults,
    isLoading,
    debouncedSearch,
    setSearchResults,
  }
}

