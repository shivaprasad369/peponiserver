export default function ProductSkeleton() {
    return (
      <div className="flex flex-wrap -mx-4">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="w-full md:w-1/2 lg:w-1/3 px-4 mb-8 animate-pulse">
            <div className="bg-gray-300 h-64 rounded-lg mb-4"></div>
            <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-1/2 mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-1/4"></div>
          </div>
        ))}
      </div>
    )
  }
  
  