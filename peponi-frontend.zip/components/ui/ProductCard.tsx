import Image from "next/image";
import lastWord from "@/assets/images/last-word.png"
export default () => {
    return (
        <div>
            <div className="w-[290px] h-[312px]  ">
                        <div className="card-box">
                            <a href="#">
                                <Image alt={'peponi'} src={lastWord} /></a>
                            <span className="like-box active">
                                <i className="fa-solid fa-heart"></i>
                            </span>
                            <div className="card-content">
                                <p>Le flaneur</p>
                                <h6><a href="#">Last word</a></h6>
                                <p className="size">Size - 115 x 115 cm</p>
                                <div className="price-wrapper">
                                    <span className="regular-price">$975</span>
                                    <span className="sell-price">$800</span>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    );
}