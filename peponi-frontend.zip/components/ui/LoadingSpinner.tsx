import Image from 'next/image'
import logo from "@/assets/images/site-logo.png"

export default function LoadingSpinner() {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center">
            <div className="mb-4">
            </div>
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FFA216]"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
        </div>
    )
}
