import React from 'react'

export default function OrderDetailSkelton() {
  return (
    <div>
      Loading..
    </div>
  )
}
