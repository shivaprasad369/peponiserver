'use client';

import { usePathname } from 'next/navigation';

interface ShareButtonsProps {
  title: string;
  description?: string;
}

export default function ShareButtons({ title, description }: ShareButtonsProps) {
  const pathname = usePathname();
  const fullUrl = `${window.location.origin}${pathname}`;

  const shareToX = () => {
    const text = encodeURIComponent(`${title}\n${description || ''}`);
    const shareUrl = encodeURIComponent(fullUrl);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${shareUrl}`, '_blank', 'noopener,noreferrer');
  };

  const shareToFacebook = () => {
    // Attempt a basic Facebook share
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(fullUrl)}`, '_blank', 'noopener,noreferrer');
  };

  const shareToLinkedin = () => {
    const shareUrl = encodeURIComponent(fullUrl);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="flex items-center gap-4">
      <button
        onClick={shareToX}
        className="w-12 h-12 flex items-center justify-center border hover:bg-[#FFA216] hover:text-white transition-colors"
        aria-label="Share on X (Twitter)"
      >
        <i className="fa-brands fa-twitter text-xl"></i>
      </button>
      <button
        onClick={shareToFacebook}
        className="w-12 h-12 flex items-center justify-center border hover:bg-[#FFA216] hover:text-white transition-colors"
        aria-label="Share on Facebook"
      >
        <i className="fa-brands fa-facebook text-xl"></i>
      </button>
      <button
        onClick={shareToLinkedin}
        className="w-12 h-12 flex items-center justify-center border hover:bg-[#FFA216] hover:text-white transition-colors"
        aria-label="Share on LinkedIn"
      >
        <i className="fa-brands fa-linkedin text-xl"></i>
      </button>
    </div>
  );
}
