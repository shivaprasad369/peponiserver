import Link from "next/link";

interface AttributeValue {
  AttributeName: string;
  attributeValue: string;
  aid: number;
  attributeValuesId: number;
}

interface Product {
  ProductID: number;
  ProductName: string;
  CategoryName: string;
  Image: string;
  ProductPrice: number;
  CashPrice: number;
  CategoryID: string;
  SubCategoryIDone: number;
  attributeValues: AttributeValue[];
}

export default function ProductSidebar({ products }: { products: Product[] }) {
  return (
    <aside className="hidden lg:block lg:w-1/3">
      <div className="-mt-6">
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">Featured Products</h2>
          <div className="space-y-6">
            {products?.slice(0, 3).map((product) => (
              <Link  key={product.ProductID} href={`/details/${product.ProductID}`}>
                <div className="card-box mt-6 hover:border-[#FFA216] transition-colors cursor-pointer">
                  <img
                    src={`${process.env.NEXT_PUBLIC_API_URL}/${product.Image}`}
                    alt={product.ProductName}
                    className="w-full h-64 object-cover"
                  />
                  <div className="card-content -ml-2">
                    <p className="text-sm text-gray-900">Le flaneur</p>
                    <h6 className="font-semibold text-lg mb-2">
                      {product.ProductName}
                    </h6>
                    {product.attributeValues?.[0] && (
                      <p className="size text-sm text-gray-600 mb-2">
                        {product.attributeValues[0].AttributeName} - {product.attributeValues[0].attributeValue}
                      </p>
                    )}
                    <div className="price-wrapper flex items-center gap-3">
                      <span className="regular-price text-gray-500 line-through text-sm">
                        ${product.ProductPrice}
                      </span>
                      <span className="sell-price text-[#FFA216] font-bold">
                        ${product.CashPrice}
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}
