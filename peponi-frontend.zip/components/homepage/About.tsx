import Image from "next/image"
import Link from "next/link"
import arrow from "@/assets/images/arrow-right.png"

async function getAboutContent() {
  try {
    const url = `${process.env.NEXT_PUBLIC_API_URL}/home?head=About`

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      next: { revalidate: 3600 }, // Revalidate every hour
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data[0][0]
  } catch (error) {
    console.error("Failed to fetch about content:", error)
    return null
  }
}

export default async function About() {
  const data = await getAboutContent()

  if (!data) {
    return (
      <div className="about-us-title-sec">
        <div className="sm-container flex flex-col gap-3">
          <div className="about-us-content animate-pulse bg-gray-300 h-[1rem]"></div>
          <div className="about-us-content animate-pulse bg-gray-300 h-[1rem]"></div>
          <div className="about-us-content animate-pulse bg-gray-300 h-[1rem]"></div>
          <div className="about-us-content animate-pulse bg-gray-300 h-[1rem]"></div>
          <div className="about-us-content animate-pulse bg-gray-300 h-[1rem]"></div>
        </div>
      </div>
    )
  }

  return (
    <section className="about-us-title-sec">
      <div className="sm-container">
        <div className="about-us-content">
          <div dangerouslySetInnerHTML={{ __html: data.content }} />
          <Link href="/about-us" className="secondary-btn">
            About Us <Image src={arrow || "/placeholder.svg"} alt="Right arrow" width={24} height={24} />
          </Link>
        </div>
      </div>
    </section>
  )
}

