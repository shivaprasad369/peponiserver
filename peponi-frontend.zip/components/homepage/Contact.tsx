"use client"
import store from "@/assets/images/store-img.png"
import call from "@/assets/images/call-us.png"
import email from "@/assets/images/email.png"
import Image from 'next/image'
// import "bootstrap/dist/css/bootstrap.min.css";
export default function Contact() {
  return (
   <>
    <section className="contact-us-sec">
    <div className={'container'}>
        <h2>Contact Us</h2>
        <p className="title">Whether you're an art enthusiast, collector, or simply curious about our collection, we’d love to hear from you!</p>
        <div className="max-xl:grid max-sm:grid-cols-1 max-xl:grid-cols-2 xl:flex xl:flex-wrap w-fit gap-3 lg:gap-10 xl:items-center">
            <div className="xl:w-[30%]">
                <div className="two-btn">
                    <a href="#" className="active">Get in touch</a>
                   <input type="text" placeholder="Enter you phone number" className="outline-none px-2 h-[100%]" />
                </div>
            </div>
         

            <div className=" xl:w-[25%]  ">
                <Image src={store} alt="store"/>
                <h5>Peponi gallery Store</h5>
                <p>Discover our curated selection of artworks in person. [Gallery Address]</p>
            </div>
            <div className="xl:w-[20%] items-start">
                <div className="call-us">
                    <Image src={call} alt="call"/>
                    <h5>Call us:</h5>
                    <a href="tel:0256 026 6552">+81 0256 026 6552</a>
                </div>
            </div>
            <div className=" xl:w-1/1 ">
                <Image src={email} alt="email"/>
                <h5>Email us:</h5>
                <a href="mailto:peponigallery@gmail.com">peponigallery@gmail.com</a>
            </div>
       
        </div>
    </div>
</section>
</>
  );
}
