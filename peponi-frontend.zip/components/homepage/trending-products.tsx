"use client"

import { useState } from "react"
import Image from "next/image"

type Product = {
  ProductID: string
  url:string
  Image: string
  ProductName: string
  attributeValues: Array<{ AttributeName: string; attributeValue: string }>
  ProductPrice: number
  CashPrice: number
}

type TrendingProductsProps = {
  products: Product[]
}

export default function TrendingProducts({ products }: TrendingProductsProps) {
  const [likedProducts, setLikedProducts] = useState<Set<string>>(new Set())

  const toggleLike = (productId: string) => {
    setLikedProducts((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(productId)) {
        newSet.delete(productId)
      } else {
        newSet.add(productId)
      }
      return newSet
    })
  }
  
  return (
    <div className="flex flex-wrap -mx-4">
      {products && products.map((data: Product) => (
        <div key={data.ProductID} className="w-full md:w-1/3 lg:w-1/4 px-4 mb-8">
          <div className="card-box  hover:border-[#FFA216] transition-colors">
            <a href={`/details/${data.url}`} className="relative block">
       
          
              <img
                alt={data.ProductName}
                src={`${process.env.NEXT_PUBLIC_API_URL}/${data.Image}`}
                className="w-full"
              />
              <div className="card-content">
                <p className="pt-6">Le flaneur</p>
                <h6>{data.ProductName}</h6>
                <p className="size">
                  {data.attributeValues[0].AttributeName} - {data.attributeValues[0].attributeValue}
                </p>
                <div className="price-wrapper">
                  <span className="regular-price">${data.ProductPrice}</span>
                  <span className="sell-price">${data.CashPrice}</span>
                </div>
              </div>
           
            <span
              className={`like-box ${likedProducts.has(data.ProductID) ? "active" : ""}`}
              onClick={() => toggleLike(data.ProductID)}
            >
              <i className={`fa-${likedProducts.has(data.ProductID) ? "solid" : "regular"} fa-heart`}></i>
            </span>
       </a>
       
        </div>
        </div>
      ))}
    </div>
    
  )
}

