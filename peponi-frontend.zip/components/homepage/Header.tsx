"use client"
import React, { useState, useEffect, useMemo, useCallback } from "react"
import { Search, User, LayoutDashboard, LogOutIcon } from "lucide-react"
import { auth } from "@/lib/firebase/firebase-config"
import { onAuthStateChanged } from "firebase/auth"
import "@assets/css/style.css"
import logo from "@assets/images/site-logo.png"
import img1 from "@/assets/images/sculptures.png"
import img2 from "@/assets/images/Painting.png"
import img3 from "@/assets/images/photography.png"
import img4 from "@/assets/images/drawings.png"
import img5 from "@/assets/images/Painting.png"
import Image from "next/image"
import Link from "next/link"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"
import LogoutDialog from "@/components/dashboard/LogoutDialog"
import Cookies from "js-cookie"
import axios from "axios"
import { isEmpty } from "lodash"
import { useQuery, useQueryClient } from "@tanstack/react-query"
export default function Header() {
  const router = useRouter()
  const [menuActive, setMenuActive] = useState(false)
  const [submenuActive, setSubmenuActive] = useState(null)
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [showRecommendations, setShowRecommendations] = useState(false)
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
 
  const queryClient = useQueryClient();

  // Retrieve cartNumber from cookies
  const cartNumber = Cookies.get("userId") || "0";

  // Handle user authentication state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUserEmail(user?.email || "");
    });

    return () => unsubscribe();
  }, []);

  // Construct API URL based on user state
  const apiUrl = useMemo(() => {
    return `${process.env.NEXT_PUBLIC_API_URL}/home/quantity?email=${userEmail || ""}&cartNumber=${cartNumber}`;
  }, [userEmail, cartNumber]);

  // Fetch cart quantity data
  const { data, isLoading } = useQuery({
    queryKey: ["Qty", userEmail, cartNumber],
    queryFn: async () => {
      try {
        const { data } = await axios.get(apiUrl);
        return data;
      } catch (error) {
        console.error("Error fetching quantity data:", error);
        return null;
      }
    },
    enabled: !!userEmail || !!cartNumber,
    refetchOnWindowFocus: false,
  });

  // Handle search results with debounce
  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (searchQuery.trim() !== "") {
        fetchSearchResults(searchQuery);
      } else {
        setResults([]);
      }
    }, 500);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  const fetchSearchResults = useCallback(async (query:any) => {
    setLoading(true);
    try {
      const { data } = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/home/search?query=${query}`
      );
      setResults(data);
    } catch (error) {
      console.error("Error fetching search results", error);
    }
    setLoading(false);
  }, []);

  // Handle scrolling behavior
  useEffect(() => {
    const controlHeader = () => {
      setIsVisible(window.scrollY < lastScrollY);
      setLastScrollY(window.scrollY);
    };

    window.addEventListener("scroll", controlHeader);
    return () => window.removeEventListener("scroll", controlHeader);
  }, [lastScrollY]);

  // Toggle menu visibility
  const toggleMenu = () => setMenuActive((prev) => !prev);

  // Handle logout
  const handleLogout = () => setShowLogoutConfirm(true);

  const confirmLogout = async () => {
    try {
      await auth.signOut();
      router.push("/login");
      Cookies.remove("userId");
      queryClient.invalidateQueries({queryKey:["Qty"]});
    } catch (error) {
      console.error("Error logging out:", error);
    }
    setShowLogoutConfirm(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/details/${searchQuery}`);
    setShowRecommendations(false);
    setSearchQuery("");
  };
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setShowRecommendations(e.target.value.length > 0);
  
  };
  
  const handleRecommendationClick = (recommendation:any) => {
    setSearchQuery(recommendation.ProductName);
    setShowRecommendations(false);
    router.push(`/details/${recommendation?.ProductUrl}`);
    setSearchQuery("");
  };

// console.log(!isLoading && data.result[0].total)
  return (
    <>
      <header
        id="header-sec"
        className={`${menuActive ? "active" : ""} 
       md:fixed  md:top-0 md:left-0 md:right-0 md:z-50 md:transition-transform max-md:mb-[-150px] md:duration-300 md:bg-white
        ${isVisible ? "md:translate-y-0" : "-md:translate-y-full"}
          `}
      >
        <div className="bg-white container mx-auto px-4">
          <div className="flex flex-row items-center">
            <div className="w-1/6 md:w-2/12">
              <div className="site-logo">
                <Link href="/">
                  <Image src={logo || "/placeholder.svg"} alt="Site Logo" />
                </Link>
              </div>
            </div>
            <div className="w-5/6 md:w-10/12">
              <div id="navbar-btn" onClick={toggleMenu}>
                <span className="hamburger-icon block md:hidden">
                  <i className="fa-solid fa-bars"></i>
                </span>
                <span className="close-icon hidden md:block">
                  <i className="fa-solid fa-xmark"></i>
                </span>
              </div>
              <div className="menu-wrapper">
                <div className="nav-menu">
                  <ul className="flex flex-col md:flex-row space-y-4 md:space-y-0">
                    <li className="md:mr-6">
                      <Link href="/">Home</Link>
                    </li>
                    <li className="relative group">
                      <Link href="/products/artworks" className="flex items-center">
                        Artworks
                      </Link>
         
                      {submenuActive === 1 && (
                        <div className="absolute left-0 hidden group-hover:block mt-2 bg-white shadow-lg p-4">
                          {/* Submenu content for Portraits */}
                        </div>
                      )}
                    </li>
                    <li className="relative group">
                      <Link href="/products/Portaits" className="flex items-center">
                       Portraits
                      </Link>
            
                      {submenuActive === 2 && (
                        <div className="absolute left-0 hidden group-hover:block mt-2 bg-white shadow-lg p-4">
                          {/* Submenu content for Art Prints */}
                        </div>
                      )}
                    </li>
                    <li className=" group">
                      <a href="/artwork" className="flex items-center">
                        More Categories
                      </a>
                      <i className="fa-solid fa-caret-down ml-2"></i>
                      <div className="sub-menu">
                        <span>Artworks</span>
                        <ul>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img1 || "/placeholder.svg"} alt="Painting" />
                              Paintings
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img2 || "/placeholder.svg"} alt="Sculptures" />
                              Sculptures
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img3 || "/placeholder.svg"} alt="Drawings" />
                              Drawings
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img4 || "/placeholder.svg"} alt="Photography" />
                              Photography
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img5 || "/placeholder.svg"} alt="Installations" />
                              Installations
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img2 || "/placeholder.svg"} alt="Digital Art" />
                              Digital Art
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img3 || "/placeholder.svg"} alt="Mixed Media" />
                              Mixed Media
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img4 || "/placeholder.svg"} alt="Printmaking" />
                              Printmaking
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img1 || "/placeholder.svg"} alt="Calligraphy" />
                              Calligraphy
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img2 || "/placeholder.svg"} alt="Collage" />
                              Collage
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img3 || "/placeholder.svg"} alt="Ceramics" />
                              Ceramics
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img4 || "/placeholder.svg"} alt="Textile Art" />
                              Textile Art
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img1 || "/placeholder.svg"} alt="Graffiti/Street Art" />
                              Graffiti/Street Art
                            </a>
                          </li>
                          <li>
                            <a href="#" className="flex items-center">
                              <Image src={img2 || "/placeholder.svg"} alt="Performance Art" />
                              Performance Art
                            </a>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
                <div className="search-bar flex justify-center mt-4 md:mt-0 relative">
                  <form onSubmit={handleSearch} className="w-full relative">
                    <input
                      name="search"
                      value={searchQuery}
                      onChange={handleInputChange}
                      className="p-2 border border-gray-300 rounded-lg w-full"
                      placeholder="Search"
                    />
                    <button type="submit" className="absolute right-2 top-1/2 transform -translate-y-1/2">
                      <Search className="h-5 w-5 text-gray-400" />
                    </button>
                  </form>
                  {showRecommendations && (
                    <div className="absolute top-full left-0 w-full bg-white border border-gray-300 rounded-b-lg shadow-lg z-10">
                      {isEmpty(results)? <p className="text-sm text-center p-2">No Product Found</p>: 
                      results?.map((recommendation:any, index) => (
                        <div
                          key={recommendation.ProductID}
                          className="p-2 hover:bg-gray-100 cursor-pointer"
                          onClick={() => handleRecommendationClick(recommendation)}
                        >
                          {recommendation.ProductName}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="search-toggle hidden md:block" id="search-btn">
                  <i className="fa-solid fa-magnifying-glass"></i>
                </div>
                <div className="header-left flex items-center space-x-4 ml-4">
                  {auth.currentUser ? (
                    <div className="relative">
                      <DropdownMenu modal={false}>
                        <DropdownMenuTrigger asChild>
                          <button className="flex items-center gap-2 px-3 py-2 rounded-full hover:bg-gray-100 transition-colors duration-200 focus:outline-none">
                            <User className="h-5 w-5 text-black" fill="currentColor" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56" align="end">
                          <DropdownMenuLabel className="flex items-center gap-2">
                            <User className="h-4 w-4 text-gray-500" />
                            <span className="text-sm font-medium truncate">{userEmail}</span>
                          </DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Link href="/dashboard" className="w-full flex items-center gap-1 ">
                              <LayoutDashboard className="h-4 w-4 text-gray-900" />
                              Dashboard
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <button onClick={handleLogout} className="w-full flex items-center gap-1 text-left">
                              <LogOutIcon className="h-4 w-4 text-red-600" />
                              Logout
                            </button>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  ) : (
                    <div className="sing-up">
                      <span>
                       <Link href="/login"> <i id="user-icon" className="fa-solid fa-user"></i></Link>
                      </span>
                      <Link href="/login">Log In</Link>
                      <Link href="/register">Register</Link>
                    </div>
                  )}
                  <div className="cart-icon relative">
                    <Link href="/cart">
                      <i className="fa-solid fa-cart-shopping"></i>
                    </Link>
                   
                      <span className="absolute -top-[0.3rem] -right-2 text-xs text-black font-medium bg-[#ffa216] rounded-full px-1">
                      {!isLoading && data && data.result[0].total}
                      </span>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <LogoutDialog isOpen={showLogoutConfirm} onClose={() => setShowLogoutConfirm(false)} onConfirm={confirmLogout} />
    </>
  )
}

