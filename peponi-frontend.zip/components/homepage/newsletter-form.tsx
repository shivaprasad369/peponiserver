"use client"

import { useState } from "react"
import { toast, Toaster } from "react-hot-toast"

async function subscribeNewsletter(email: string) {
  
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/newletter`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email }),
    })

    if (!response.ok) {
      return { success: false, message: "Failed to subscribe or Email already exists" }
    }

    const data = await response.json()
    return { success: true, data }
  } catch (error) {
    console.error("Newsletter subscription error:", error)
    return { success: false, message: "An error occurred while subscribing" }
  }
}

export default function NewsletterForm() {
  const [email, setEmail] = useState("")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!email || !email.includes("@")) {
      toast.error("Please enter a valid email address")
      return
    }

    try {
      const result = await subscribeNewsletter(email)
      if (result.success) {
        setEmail("")
        toast.success("Subscribed Successfully")
      } else {
        toast.error(result.message || "Failed to subscribe")
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.")
    }
  }

  return (
    <div className="footer-newsletter">
      <Toaster />
      <span className="text-lg font-medium">Subscribe Newsletter</span>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter Your Email Address"
          className="border p-2 mt-2 w-full md:w-auto"
        />
        <button type="submit" className="subscribe-btn mt-2 px-6 py-2 bg-blue-500 text-white hover:bg-blue-600">
          Subscribe
        </button>
      </form>
    </div>
  )
}

