import york from "@/assets/images/york-more.png"
import Image from 'next/image';

export default function Success() {
  return (
    <section className="success-sec">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-7/12">
            <Image src={york} alt=""/>
          </div>
          <div className="md:w-5/12 ml-6 ">
            <h2>Exhibit In Big Record Of Success.</h2>
            <p className="content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            <ul className="success-project grid grid-cols-1 sm:grid-cols-3 w-full gap-6 text-center py-4">
              <li className="flex flex-col items-center">
                <h4 className="text-2xl font-bold">450</h4>
                <p className="text-sm">Exhibitions Has Been</p>
              </li>
              <li className="flex flex-col items-center">
                <h4 className="text-2xl font-bold">3K</h4>
                <p className="text-sm">Visitors In Last Year</p>
              </li>
              <li className="flex flex-col items-center">
                <h4 className="text-2xl font-bold">100</h4>
                <p className="text-sm">Awards Have Received</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}