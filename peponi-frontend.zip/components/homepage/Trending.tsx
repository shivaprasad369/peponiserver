import TrendingProducts from "./trending-products"

async function getTrendingProducts() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/collection?collection=4`, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      cache:'no-store' // Revalidate every hour
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Failed to fetch trending products:", error)
    return null
  }
}

export default async function Trending() {
  const trendingProducts = await getTrendingProducts()

  if (!trendingProducts) {
    return (
      <section className="trending-product-sec">
        <div className="container mx-auto px-4">
          <h2>Trending Products</h2>
          <p className="text">Beloved Pieces by Art Enthusiasts</p>
          <div className="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 gap-10">
            {[1, 2, 3, 4].map((_, index) => (
              <div key={index} className="animate-pulse space-y-4 bg-gray-300 h-[20rem] lg:h-[25rem] w-[100%]" />
            ))}
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="trending-product-sec">
      <div className="container mx-auto px-4">
        <h2>Trending Products</h2>
        <p className="text">Beloved Pieces by Art Enthusiasts</p>
        <TrendingProducts products={trendingProducts} />
      </div>
    </section>
  )
}

