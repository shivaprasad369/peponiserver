import Image from "next/image"
import Link from "next/link"
import arrow from "@/assets/images/arrow-right.png"
import CollectionTabs from "./collection-tabs"

async function getInitialCollectionData() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/collection?collection=1`, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Failed to fetch initial collection data:", error)
    return null
  }
}

export default async function Collection() {
  const initialProducts = await getInitialCollectionData()

  return (
    <section className="explore-collection-sec">
      <div className="container">
        <h2>Explore the Collection</h2>
        <CollectionTabs initialProducts={initialProducts} />
      </div>
    </section>
  )
}

