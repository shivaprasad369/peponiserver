import Image from "next/image"
import arrow from "@/assets/images/arrow-right.png"
import Link from "next/link"

async function getBlogs() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/frontend-blog`, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      cache:'no-store' // Revalidate every hour

    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.result
  } catch (error) {
    console.error("Failed to fetch blogs:", error)
    return null
  }
}

export default async function Blogs() {
  const blogs = await getBlogs()

  return (
    <section className="our-blog-sec py-10">
      <div className="container">
        <div className="blog-title flex justify-between items-center mb-6">
          <h2 className="">Latest From Our Blogs</h2>
          <Link href="/blog" className="secondary-btn flex items-center text-blue-500">
            View more
            <Image src={arrow || "/placeholder.svg"} alt="arrow" width={20} height={20} className="ml-2" />
          </Link>
        </div>
        <div className="row grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {blogs
            ? blogs.map((blog: any) => (
                <div key={blog.id} className="col-lg-3 col-md-6">
                  <Link href={`/blog/${blog.slug}`} className="block">
                    <div className="blog-card  overflow-hidden h-[400px] flex flex-col hover:border-[#FFA216] transition-colors">
                      <div className="block h-[250px]">
                        <img
                          alt={blog.title}
                          className="w-full h-full object-cover"
                          src={`${process.env.NEXT_PUBLIC_API_URL}/${blog.image}`}
                        />
                      </div>
                      <div className="blog-content p-4 flex-1 flex flex-col">
                        <span className="date text-gray-500 text-sm">
                          {new Date(blog.created_at).toLocaleDateString("en-US", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </span>
                        <h3 className="font-semibold line-clamp-2">
                          {blog.title}
                        </h3>
                        <p className="text-gray-700 mt-2 text-sm line-clamp-3">{blog.shortdesc}</p>
                      </div>
                    </div>
                  </Link>
                </div>
              ))
            : [1, 2, 3, 4].map((_, index) => (
                <div key={index} className="col-lg-3 col-md-6">
                  <div className="blog-card border overflow-hidden h-[400px] flex flex-col">
                    <div className="w-full h-[200px] bg-gray-300" />
                    <div className="blog-content p-4 flex-1">
                      <span className="date text-gray-500 text-sm h-4 w-16 bg-gray-300 block"></span>
                      <div className="h-4 w-3/4 bg-gray-300 mt-2"></div>
                      <div className="h-4 w-1/2 bg-gray-300 mt-2"></div>
                    </div>
                  </div>
                </div>
              ))}
        </div>
      </div>
    </section>
  )
}

