import Image from "next/image"
import logo from "@/assets/images/site-logo.png"
import payment from "@/assets/images/payment-card.png"
import NewsletterForm from "./newsletter-form"
import Link from "next/link"

export default function Footer() {
  return (
    <footer className="footer-sec">
      <div className="container px-4 py-10">
        <div className="flex md:flex-wrap max-md:flex-col md:gap-10 gap-8 w-full">
          <div className="flex justify-start w-full md:w-auto">
            <Image src={logo || "/placeholder.svg"} alt="site-logo" className="w-[100px] h-fit" />
          </div>

          <div className="flex-1 col-md-6 w-full md:w-auto">
            <h5 className="text-lg font-medium">Follow Peponi Gallery</h5>
            <ul className="social-icon flex gap-3">
              <li>
                <a href="#" className="text-gray-600">
                  <i className="fa-brands fa-twitter"></i>
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  <i className="fa-brands fa-facebook"></i>
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  <i className="fa-brands fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  <i className="fa-brands fa-instagram"></i>
                </a>
              </li>
            </ul>
            <div className="footer-reviews mt-4">
              <h6 className="font-medium">Verified Reviews</h6>
              <div className="star-wrapper flex items-center">
                <span className="mr-2">9 / 10 </span>
                <ul className="flex">
                  <li>
                    <i className="fa-solid fa-star text-yellow-400"></i>
                  </li>
                  <li>
                    <i className="fa-solid fa-star text-yellow-400"></i>
                  </li>
                  <li>
                    <i className="fa-solid fa-star text-yellow-400"></i>
                  </li>
                  <li>
                    <i className="fa-solid fa-star text-yellow-400"></i>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex-1 col-md-6 w-full md:w-auto">
            <h5 className="text-lg font-medium">Who we are?</h5>
            <ul className="space-y-1">
              <li>
                <a href="#" className="text-gray-600">
                  About Peponi Gallery
                </a>
              </li>
              <li>
                <a href="/blog" className="text-gray-600">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  FAQ
                </a>
              </li>
              <li>
                <a href="/contact-us" className="text-gray-600">
                  Contact us
                </a>
              </li>
            </ul>
          </div>

          <div className="flex-1 col-md-6 w-full md:w-auto">
            <h5 className="text-lg font-medium">Our services</h5>
            <ul className="space-y-1">
              <li>
                <a href="artworks.html" className="text-gray-600">
                  Artworks
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  Painting
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  Sculpture
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  Photography
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  Print
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600">
                  Fine Art Drawings
                </a>
              </li>
            </ul>
          </div>

          <div className="flex-1 col-md-6 w-full md:w-auto">
            <NewsletterForm />
          </div>
        </div>

        <div className="copy-right w-full mt-10">
          <div className="flex flex-wrap md:justify-between w-full">
            <div className="flex">
              <ul className="flex justify-center md:justify-start">
                <li>
                  <a href="#" className="text-gray-600">
                    Terms and Conditions of Use
                  </a>
                </li>

                <li>
                  <a href="#" className="text-gray-600">
                    Privacy and cookie policy
                  </a>
                </li>
              </ul>
            </div>
            <div className="flex items-center justify-center max-lg:w-full mt-4 md:mt-0">
              <div className="footer-card flex lg:flex-col max-lg:w-full items-center justify-between">
                <a href="#" className="copyright-text text-gray-600">
                  @2024 Peponi Gallery
                </a>
                <Image src={payment || "/placeholder.svg"} alt="payment-card" className="h-auto" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

