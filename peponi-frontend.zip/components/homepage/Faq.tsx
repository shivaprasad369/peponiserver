import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

async function getFaqData() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/faq`, {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      cache: 'force-cache'
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data.result;
  } catch (error) {
    console.error("Failed to fetch FAQ data:", error);
    return null;
  }
}

export default async function Faq() {
  const data = await getFaqData();

  return (
    <section className="faq-sec ">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold mb-8">FAQ</h2>
        <Accordion type="single" collapsible className="w-full">
          {data ? data.map((item: any, index: number) => (
            <AccordionItem value={`item-${index+1}`} key={item.id}>
              <AccordionTrigger className="text-lg font-medium text-left">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-black text-left">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          )) : [1,2,3,4].map((_, index) => (
            <AccordionItem value={`item-${index+1}`} key={index}>
              <AccordionTrigger className="text-lg font-medium text-left">
                <div className="animate-pulse bg-gray-300 h-[1rem]"></div>
              </AccordionTrigger>
              <AccordionContent className="text-black text-left">
                <div className="animate-pulse bg-gray-300 h-[1rem]"></div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}