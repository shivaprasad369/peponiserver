"use client"

import Image from "next/image"
import Link from "next/link"
import { useState, useEffect } from "react"
import arrow from "@/assets/images/arrow-right.png"
type Product = {
  ProductID: string
  Image: string
  url:string
  ProductName: string
  attributeValues: Array<{ AttributeName: string; attributeValue: string }>
  ProductPrice: number
  CashPrice: number
}

type CollectionTabsProps = {
  initialProducts: Product[]
}

export default function CollectionTabs({ initialProducts }: CollectionTabsProps) {
  const [collection, setCollection] = useState<number>(1)
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState<boolean>(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/collection?collection=${collection}`, {
          next:{
            revalidate: 3600, 
          }
        })
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`)
        }
        const data = await response.json()
        setProducts(data)
      } catch (error) {
        console.error("Failed to fetch collection:", error)
      } finally {
        setLoading(false)
      }
    }

    if(collection!==1)
    {
      fetchData()

    }
    else{
      setProducts(initialProducts)
    }
    
  }, [collection])
  const renderProducts = () => {
    if (loading || products.length<1) {
      return (
        <div className="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((_, index) => (
            <div key={index} className="border rounded-xl shadow-sm p-4 animate-pulse">
              {/* Image Placeholder */}
              <div className="bg-gray-300 h-48 w-full rounded-md mb-4"></div>
  
              {/* Title Placeholder */}
              <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
  
              {/* Description Placeholder */}
              <div className="h-4 bg-gray-300 rounded w-1/2 mb-2"></div>
  
              {/* Price Placeholder */}
              <div className="flex justify-between items-center mt-4">
                <div className="h-4 bg-gray-300 rounded w-1/4"></div>
                <div className="h-4 bg-gray-300 rounded w-1/4"></div>
              </div>
            </div>
          ))}
        </div>
      );
    }
    console.log(products)
    return (
        <>
      <div className="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 gap-10">
        {products?.map((data: Product) => (
          <div key={data.ProductID}>
            <Link href={`/details/${data.url}`}>
              <div className="card-box transition-all duration-300 hover:border-[#FFA216]">
                <img alt={data.ProductName} src={`${process.env.NEXT_PUBLIC_API_URL}/${data.Image}`} />
                <span className="like-box">
                  <i className="fa-regular fa-heart"></i>
                </span>
                <div className="card-content">
                  <p>Le flaneur</p>
                  <h6>{data.ProductName}</h6>
                  <p className="size">
                    {data.attributeValues[0].AttributeName} - {data.attributeValues[0].attributeValue}
                  </p>
                  <div className="price-wrapper">
                    <span className="regular-price">${data.ProductPrice}</span>
                    <span className="sell-price">${data.CashPrice}</span>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
      <div className="view-btn mt-3">
      <Link href={`/products/${collection===1 ? 'Artworks':collection===2?'Portaits':'Art Prints'}`} className="secondary-btn flex items-center gap-2">
      <Image alt={"arrow"} src={arrow || "/placeholder.svg"} width={20} height={20} />
        <span>View More</span>
        </Link>
      </div>
      </>
    )
  }

  return (
    <>
      <ul
        className="nav nav-pills flex flex-wrap w-full items-center justify-center gap-5"
        id="pills-tab"
        role="tablist"
      >
        <li className="nav-item" role="presentation" onClick={() => setCollection(1)}>
          <button className={`rounded-md nav-link ${collection === 1 && "active"}`}>Artworks</button>
        </li>
        <li className="nav-item" role="presentation" onClick={() => setCollection(2)}>
          <button className={`rounded-md nav-link ${collection === 2 && "active"}`}>Portraits</button>
        </li>
        <li className="nav-item" role="presentation" onClick={() => setCollection(3)}>
          <button className={`rounded-md nav-link ${collection === 3 && "active"}`}>Art Prints</button>
        </li>
      </ul>
      <div className="tab-content" id="pills-tabContent">
        <div
          className={`tab-pane duration-300 fade transition-all gap-10 flex flex-col`}
          id="tab-one"
          role="tabpanel"
          aria-labelledby="pills-tab-one"
        >
          {renderProducts()}
        </div>
      </div>
    </>
  )
}

