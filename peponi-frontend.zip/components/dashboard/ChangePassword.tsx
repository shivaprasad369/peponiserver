'use client'
import { FC, FormEvent, useState, useRef } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { auth } from '@/lib/firebase/firebase-config';
import { updatePassword, signInWithEmailAndPassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { toast, Toaster } from 'react-hot-toast';

const ChangePassword: FC = () => {
    const formRef = useRef<HTMLFormElement>(null);
    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsLoading(true);

        const formData = new FormData(e.currentTarget);
        const currentPassword = formData.get('currentPassword') as string;
        const newPassword = formData.get('newPassword') as string;
        const confirmPassword = formData.get('confirmPassword') as string;

        try {
            // Validate passwords
            if (newPassword !== confirmPassword) {
                toast.error('New passwords do not match');
                return;
            }

            if (newPassword.length < 6) {
                toast.error('New password should be at least 6 characters');
                return;
            }

            const user = auth.currentUser;
            if (!user || !user.email) {
                toast.error('No user is currently signed in');
                return;
            }

            // Reauthenticate user
            const credential = EmailAuthProvider.credential(
                user.email,
                currentPassword
            );
            await reauthenticateWithCredential(user, credential);

            // Update password
            await updatePassword(user, newPassword);
            
            toast.success('Password updated successfully');
            if (formRef.current) {
                formRef.current.reset();
            }
        } catch (error: any) {
            if (error.code === 'auth/wrong-password') {
                toast.error('Current password is incorrect');
            } else {
                toast.error('Failed to update password');
            }
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <>
            <Toaster position="top-center" />
            <div className="w-full px-4">
                <div className="change-password-form bg-white border border-gray-200 rounded-sm mt-4 py-4 px-4 shadow-sm">
                    <h6 className="text-xl font-semibold mb-6 text-black">Change Password</h6>
                    <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                        <div className="flex flex-wrap -mx-4">
                            <div className="w-full px-4 mb-4">
                                <div className="form-group">
                                    <label 
                                        htmlFor="currentPassword" 
                                        className="block text-m font-medium text-black mb-2"
                                    >
                                        Current Password
                                    </label>
                                    <div className="relative">
                                        <input 
                                            type={showCurrentPassword ? "text" : "password"}
                                            id="currentPassword" 
                                            name="currentPassword" 
                                            placeholder="Enter Your Current Password*"
                                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-1 focus:ring-gray-400 focus:border-gray-400 outline-none transition duration-300"
                                        />
                                        <button 
                                            type="button"
                                            onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                                        >
                                            {showCurrentPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="w-full px-4 mb-4">
                                <div className="form-group">
                                    <label 
                                        htmlFor="newPassword"
                                        className="block text-m font-medium text-black mb-2"
                                    >
                                        New Password
                                    </label>
                                    <div className="relative">
                                        <input 
                                            type={showNewPassword ? "text" : "password"}
                                            id="newPassword" 
                                            name="newPassword" 
                                            placeholder="Enter Your New Password*"
                                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-1 focus:ring-gray-400 focus:border-gray-400 outline-none transition duration-300"
                                        />
                                        <button 
                                            type="button"
                                            onClick={() => setShowNewPassword(!showNewPassword)}
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                                        >
                                            {showNewPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="w-full px-4 mb-4">
                                <div className="form-group">
                                    <label 
                                        htmlFor="confirmPassword"
                                        className="block text-m font-medium text-black mb-2"
                                    >
                                        Confirm New Password
                                    </label>
                                    <div className="relative">
                                        <input 
                                            type={showConfirmPassword ? "text" : "password"}
                                            id="confirmPassword" 
                                            name="confirmPassword" 
                                            placeholder="Confirm Your New Password*"
                                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-1 focus:ring-gray-400 focus:border-gray-400 outline-none transition duration-300"
                                        />
                                        <button 
                                            type="button"
                                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                                        >
                                            {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="w-full px-4 mt-2">
                                <button 
                                    type="submit" 
                                    className="primary-btn"
                                    disabled={isLoading}
                                >
                                    {isLoading ? 'Updating...' : 'Update'}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
};

export default ChangePassword;
