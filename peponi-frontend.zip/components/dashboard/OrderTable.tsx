import Image from 'next/image';
import { FC, useEffect, useState } from 'react';
import img8 from "@/assets/images/gettyimages.png";
import img9 from "@/assets/images/view.png";
import img10 from "@/assets/images/bin.png";
import { useRouter } from 'next/navigation';

const getStatusText = (status: number) => {
    switch (status) {
        case 0:
            return "Order Placed";
        case 1:
            return "Order Delivered";
        case 2:
            return "Order Cancelled";
        default:
            return "Unknown Status";
    }
};

const OrderTable: FC<{ email: any }> = ({ email }) => {
    const [orders, setOrders] = useState<any[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
const router =useRouter()
    useEffect(() => {
        const fetchOrders = async () => {
            if (email) {
                try {
                    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/home/dashboard?email=${email}`);
                    const data = await response.json();
                    setOrders(data.result);
                    setLoading(false);
                } catch (error) {
                    console.error("Error fetching orders:", error);
                    setLoading(false);
                }
            }
        };

        fetchOrders();
    }, [email]);

    const getStatusClassName = (status: string) => {
        switch (status) {
            case "Order Delivered":
                return "order-delivered";
            case "Order Placed":
                return "order-placed";
            case "Order Cancelled":
                return "order-cancelled";
            default:
                return "";
        }
    };

    if (loading) {
        return (
            <div className="w-full -mt-4 px-4">
                <div className="inner-two-sec py-4">
                    <div className="dashboard-details">
                        {/* Desktop Skeleton Loader */}
                        <div className="hidden md:block overflow-x-auto">
                            <table className="w-full table border-collapse">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="p-4"></th>
                                        <th className="p-4 text-left">Order No</th>
                                        <th className="p-4 text-left">Amount($)</th>
                                        <th className="p-4 text-left">Order Date</th>
                                        <th className="p-4 text-left">Status</th>
                                        <th className="p-4 text-center">View</th>
                                        <th className="p-4 text-center">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {[...Array(5)].map((_, index) => (
                                        <tr key={index} className="border-b">
                                            <td className="p-4">
                                                <div className="skeleton-circle w-10 h-10"></div>
                                            </td>
                                            <td className="p-4">
                                                <div className="skeleton-text w-32 h-4"></div>
                                            </td>
                                            <td className="p-4">
                                                <div className="skeleton-text w-24 h-4"></div>
                                            </td>
                                            <td className="p-4">
                                                <div className="skeleton-text w-24 h-4"></div>
                                            </td>
                                            <td className="p-4">
                                                <div className="skeleton-text w-32 h-4"></div>
                                            </td>
                                            <td className="p-4 text-center">
                                                <div className="skeleton-circle w-6 h-6 mx-auto"></div>
                                            </td>
                                            <td className="p-4 text-center">
                                                <div className="skeleton-circle w-6 h-6 mx-auto"></div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Mobile Skeleton Loader */}
                        <div className="md:hidden space-y-4">
                            {[...Array(3)].map((_, index) => (
                                <div key={index} className="bg-white p-4 rounded-lg shadow">
                                    <div className="flex items-center space-x-3 mb-3">
                                        <div className="skeleton-circle w-10 h-10"></div>
                                        <div className="skeleton-text w-24 h-4"></div>
                                    </div>

                                    <div className="space-y-2">
                                        <div className="flex justify-between">
                                            <div className="skeleton-text w-20 h-4"></div>
                                            <div className="skeleton-text w-20 h-4"></div>
                                        </div>

                                        <div className="flex justify-between">
                                            <div className="skeleton-text w-20 h-4"></div>
                                            <div className="skeleton-text w-20 h-4"></div>
                                        </div>

                                        <div className="flex justify-between items-center">
                                            <div className="skeleton-text w-20 h-4"></div>
                                            <div className="skeleton-text w-20 h-4"></div>
                                        </div>
                                    </div>

                                    <div className="flex justify-end space-x-4 mt-4">
                                        <div className="skeleton-circle w-6 h-6"></div>
                                        <div className="skeleton-circle w-6 h-6"></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
const handleMove=(id:any)=>{
    router.push('dashboard/'+id)
}
    return (
        <div className="w-full -mt-4 px-4">
            <div className="inner-two-sec py-4">
                <div className="dashboard-details">
                    {/* Desktop Table View */}
                    <div className="hidden md:block overflow-x-auto">
                        <table className="w-full table border-collapse">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="p-4"></th>
                                    <th className="p-4 text-left">Order No</th>
                                    <th className="p-4 text-left">Amount($)</th>
                                    <th className="p-4 text-left">Order Date</th>
                                    <th className="p-4 text-left">Status</th>
                                    <th className="p-4 text-center">View</th>
                                    <th className="p-4 text-center">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                {orders.map((order) => (
                                    <tr key={order.OrderNumber} className="border-b hover:bg-gray-50">
                                        <td className="p-4">
                                            <div className="user-img w-10 h-10">
                                                <img
                                                    src={`${process.env.NEXT_PUBLIC_API_URL}/${order?.Products[0]?.ProductImages}`}
                                                    alt="User"
                                                    width={40}
                                                    height={40}
                                                    className="rounded-full"
                                                />
                                            </div>
                                        </td>
                                        <td className="p-4">
                                            <p className="text-gray-900">{order.OrderNumber}</p>
                                        </td>
                                        <td className="p-4">
                                            <p className="text-gray-900">${parseInt(order.Total).toFixed(0)}</p>
                                        </td>
                                        <td className="p-4">
                                            <p className="text-gray-600">{new Date(order.OrderDate).toLocaleDateString()}</p>
                                        </td>
                                        <td className="p-4">
                                            <p className={`${getStatusClassName(getStatusText(order.OrderStatus))} px-3 py-1 rounded-full text-center`}>
                                                {getStatusText(order.OrderStatus)}
                                            </p>
                                        </td>
                                        <td className="p-4 text-center">
                                            <div onClick={()=>handleMove(order.OrderNumber)} className="flex items-center justify-center cursor-pointer">
                                                <Image src={img9} alt="View" width={20} height={20} />
                                            </div>
                                        </td>
                                        <td className="p-4 text-center">
                                            <div className="flex items-center justify-center cursor-pointer">
                                                <Image src={img10} alt="Delete" width={20} height={20} />
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Mobile Card View */}
                    <div className="md:hidden space-y-4">
                        {orders.map((order) => (
                            <div key={order.OrderNumber} className="bg-white p-4 rounded-lg shadow">
                                <div className="flex items-center space-x-3 mb-3">
                                    <div className="user-img w-10 h-10">
                                        <img
                                         src={`${process.env.NEXT_PUBLIC_API_URL}/${order?.Products[0]?.ProductImages}`}
                                            alt="User"
                                            width={40}
                                            height={40}
                                            className="rounded-full"
                                        />
                                    </div>
                                    <p className="text-gray-900 font-medium">{order.OrderNumber}</p>
                                </div>
                                
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Amount</span>
                                        <span className="text-gray-900">${parseInt(order.Total).toFixed(0)}</span>
                                    </div>
                                    
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Order Date</span>
                                        <span className="text-gray-900">{new Date(order.OrderDate).toLocaleDateString()}</span>
                                    </div>
                                    
                                    <div className="flex justify-between items-center">
                                        <span className="text-gray-600">Status</span>
                                        <span className={`${getStatusClassName(getStatusText(order.OrderStatus))} px-3 py-1 rounded-full text-center`}>
                                            {getStatusText(order.OrderStatus)}
                                        </span>
                                    </div>
                                </div>

                                <div className="flex justify-end space-x-4 mt-4">
                                    <div className="cursor-pointer">
                                        <Image src={img9} alt="View" width={20} height={20} />
                                    </div>
                                    <div className="cursor-pointer">
                                        <Image src={img10} alt="Delete" width={20} height={20} />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OrderTable;
