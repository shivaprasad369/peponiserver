'use client'
import { FC, FormEvent } from 'react';
import Image from 'next/image';
import img11 from "@/assets/images/cloud-computing.png";

interface FormData {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    message: string;
    profilePicture?: File;
}

const MyProfile: FC = () => {
    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        // Handle form submission here
        console.log(Object.fromEntries(formData));
    };

    return (
        <div className="my-profile-form border border-gray-200 rounded mt-4 p-4 mx-3">
            <h6>My Profile</h6>
            <form onSubmit={handleSubmit}>
                <div className="flex flex-wrap -mx-4">
                    <div className="w-full lg:w-1/2 px-4 mb-4">
                        <div className="form-group">
                            <label htmlFor="firstName">First Name</label>
                            <input type="text" id="firstName" name="firstName" placeholder="Enter Your First Name*"/>
                        </div>
                    </div>
                    <div className="w-full lg:w-1/2 px-4 mb-4">
                        <div className="form-group">
                            <label htmlFor="lastName">Last Name</label>
                            <input type="text" id="lastName" name="lastName" placeholder="Enter Your Last Name*"/>
                        </div>
                    </div>
                    <div className="w-full lg:w-1/2 px-4 mb-4">
                        <div className="form-group">
                            <label htmlFor="email">Email Address</label>
                            <input type="email" id="email" name="email" placeholder="Enter Your Email Address*"/>
                        </div>
                    </div>
                    <div className="w-full lg:w-1/2 px-4 mb-4">
                        <div className="form-group">
                            <label htmlFor="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" placeholder="Enter Your Phone Number*"/>
                        </div>
                    </div>
                    <div className="w-full px-4 mb-4">
                        <div className="form-group">
                            <label htmlFor="message">Message</label>
                            <textarea id="message" name="message" placeholder="Type a message *"></textarea>
                        </div>
                    </div>
                    <div className="w-full px-4">
                        <div className="file-upload ">
                            <div className="file-upload__label flex flex-col items-center justify-center">
                                <Image className='mx-auto' src={img11} alt="Upload" width={40} height={40}/>
                                <p className="mt-2">Upload a Profile Picture*</p>
                            </div>
                            <input 
                                id="profilePicture" 
                                name="profilePicture"
                                className="file-upload__input" 
                                type="file" 
                                accept="image/*"
                            />
                        </div>
                    </div>
                    <div className="w-full mt-6 px-4">
                        <button type="submit" className="primary-btn">Update</button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default MyProfile;