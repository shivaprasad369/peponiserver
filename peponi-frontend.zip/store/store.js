
import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./slices/filter"; // Example slice

export const store = configureStore({
  reducer: {
    counter: counterReducer,
  },
});

// Create a custom hook to use dispatch
export const makeStore = () => store;
export default store;
